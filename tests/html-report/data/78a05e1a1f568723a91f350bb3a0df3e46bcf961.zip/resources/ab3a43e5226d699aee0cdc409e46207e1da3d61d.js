import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SubmitPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f7470b49"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/pages/SubmitPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f7470b49"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=f7470b49";
import {
  Badge,
  Button,
  DatePicker,
  EmptyState,
  Input,
  Loading,
  Modal,
  Select,
  Table,
  TBody,
  Td,
  Th,
  THead,
  Tr,
  useToast
} from "/src/components/ui/index.js";
import {
  getEmployees,
  getPhases,
  saveLsppt,
  createEmployee,
  updateEmployee,
  deleteEmployee,
  getEmployeeTaskCount
} from "/src/api/lsppt.js?t=1787821474189";
const CLICKUP_ID_PATTERN = /\/([a-z0-9]+)\/?$/i;
const EMPTY_TASK_FORM = {
  title: "",
  clickupUrl: "",
  clickupTaskId: "",
  phase: "",
  status: ""
};
let taskSeq = 0;
function extractClickUpId(url) {
  const match = url.match(CLICKUP_ID_PATTERN);
  return match ? match[1] : null;
}
function statusBadgeVariant(status) {
  const s = status.toLowerCase();
  if (s.startsWith("completed")) return "success";
  if (s.includes("progress") || s.includes("testing") || s.includes("documentation")) return "info";
  if (s.includes("hold") || s.includes("feedback")) return "warning";
  return "neutral";
}
export default function SubmitPage() {
  _s();
  const { showToast } = useToast();
  const [employees, setEmployees] = useState([]);
  const [phases, setPhases] = useState({});
  const [metaLoading, setMetaLoading] = useState(true);
  const [employeeId, setEmployeeId] = useState("");
  const [date, setDate] = useState("");
  const [formErrors, setFormErrors] = useState({});
  const [taskForm, setTaskForm] = useState(EMPTY_TASK_FORM);
  const [rowErrors, setRowErrors] = useState({});
  const [tasks, setTasks] = useState([]);
  const [saving, setSaving] = useState(false);
  const [empModalOpen, setEmpModalOpen] = useState(false);
  const [empView, setEmpView] = useState("list");
  const [empEditId, setEmpEditId] = useState(null);
  const [empName, setEmpName] = useState("");
  const [empSaving, setEmpSaving] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleteTaskCount, setDeleteTaskCount] = useState(0);
  const [deleteLoading, setDeleteLoading] = useState(false);
  useEffect(() => {
    let cancelled = false;
    Promise.all([getEmployees(), getPhases()]).then(([empRes, phaseRes]) => {
      if (cancelled) return;
      setEmployees(empRes.data);
      setPhases(phaseRes.data);
    }).catch((err) => {
      if (cancelled) return;
      showToast({
        type: "error",
        title: "Gagal memuat data",
        message: err.response?.data?.message || err.message
      });
    }).finally(() => {
      if (!cancelled) setMetaLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [showToast]);
  const loadEmployees = () => {
    getEmployees().then((res) => setEmployees(res.data)).catch(() => {
    });
  };
  const openEmpModal = () => {
    setEmpView("list");
    setEmpEditId(null);
    setEmpName("");
    setEmpModalOpen(true);
  };
  const handleEmpCreate = async () => {
    if (!empName.trim()) return;
    setEmpSaving(true);
    try {
      await createEmployee(empName.trim());
      showToast({ type: "success", title: "Berhasil", message: "Karyawan ditambahkan" });
      loadEmployees();
      setEmpView("list");
      setEmpName("");
    } catch (err) {
      showToast({ type: "error", title: "Gagal", message: err.message });
    } finally {
      setEmpSaving(false);
    }
  };
  const handleEmpUpdate = async () => {
    if (!empName.trim() || !empEditId) return;
    setEmpSaving(true);
    try {
      await updateEmployee(empEditId, empName.trim());
      showToast({ type: "success", title: "Berhasil", message: "Karyawan diperbarui" });
      loadEmployees();
      setEmpView("list");
      setEmpEditId(null);
      setEmpName("");
    } catch (err) {
      showToast({ type: "error", title: "Gagal", message: err.message });
    } finally {
      setEmpSaving(false);
    }
  };
  const handleEmpDelete = async () => {
    if (!empEditId) return;
    try {
      const res = await getEmployeeTaskCount(empEditId);
      setDeleteTarget({ id: empEditId, name: empName });
      setDeleteTaskCount(res.count);
      setDeleteConfirmOpen(true);
    } catch (err) {
      showToast({ type: "error", title: "Gagal", message: err.message });
    }
  };
  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setDeleteLoading(true);
    try {
      await deleteEmployee(deleteTarget.id);
      showToast({ type: "success", title: "Berhasil", message: "Karyawan dihapus" });
      loadEmployees();
      setEmpView("list");
      setEmpEditId(null);
      setEmpName("");
      setDeleteConfirmOpen(false);
      setDeleteTarget(null);
    } catch (err) {
      showToast({ type: "error", title: "Gagal menghapus", message: err.message });
    } finally {
      setDeleteLoading(false);
    }
  };
  const phaseOptions = Object.keys(phases);
  const statusOptions = taskForm.phase ? phases[taskForm.phase] ?? [] : [];
  const handleTaskFormChange = (field) => (e) => {
    const { value } = e.target;
    if (field === "phase") {
      setTaskForm((prev) => ({ ...prev, phase: value, status: "" }));
      setRowErrors((prev) => ({ ...prev, phase: void 0, status: void 0 }));
      return;
    }
    if (field === "clickupUrl") {
      const extracted = extractClickUpId(value);
      setTaskForm((prev) => ({
        ...prev,
        clickupUrl: value,
        ...extracted ? { clickupTaskId: extracted } : {}
      }));
      setRowErrors(
        (prev) => extracted ? { ...prev, clickupUrl: void 0, clickupTaskId: void 0 } : { ...prev, clickupUrl: void 0 }
      );
      return;
    }
    setTaskForm((prev) => ({ ...prev, [field]: value }));
    setRowErrors((prev) => ({ ...prev, [field]: void 0 }));
  };
  const validateTaskForm = () => {
    const errs = {};
    if (!employeeId) errs.employeeId = "Pilih karyawan";
    if (!date) errs.date = "Pilih tanggal";
    if (!taskForm.title.trim()) errs.title = "Judul tugas wajib diisi";
    if (!taskForm.clickupUrl.trim()) errs.clickupUrl = "ClickUp URL wajib diisi";
    else if (!extractClickUpId(taskForm.clickupUrl.trim()))
      errs.clickupUrl = "Format URL tidak valid (contoh: https://app.clickup.com/t/9003006723/86d41c8ur)";
    if (!taskForm.clickupTaskId.trim()) errs.clickupTaskId = "ClickUp Task ID wajib diisi";
    else if (tasks.some(
      (t) => t.clickup_task_id.toLowerCase() === taskForm.clickupTaskId.trim().toLowerCase()
    ))
      errs.clickupTaskId = "Task ID sudah ada di daftar";
    if (!taskForm.phase) errs.phase = "Pilih phase";
    if (!taskForm.status) errs.status = "Pilih status";
    return errs;
  };
  const handleAddTask = () => {
    const errs = validateTaskForm();
    setRowErrors(errs);
    setFormErrors({ employeeId: errs.employeeId, date: errs.date });
    if (Object.keys(errs).length > 0) return;
    setTasks(
      (prev) => [
        ...prev,
        {
          uid: ++taskSeq,
          title: taskForm.title.trim(),
          clickup_url: taskForm.clickupUrl.trim(),
          clickup_task_id: taskForm.clickupTaskId.trim(),
          phase: taskForm.phase,
          status: taskForm.status
        }
      ]
    );
    setTaskForm(EMPTY_TASK_FORM);
  };
  const handleRemoveTask = (uid) => {
    setTasks((prev) => prev.filter((t) => t.uid !== uid));
  };
  const handleSave = async () => {
    const errs = {};
    if (!employeeId) errs.employeeId = "Pilih karyawan";
    if (!date) errs.date = "Pilih tanggal";
    if (tasks.length === 0) errs.tasks = "Tambahkan minimal satu task sebelum menyimpan";
    setFormErrors(errs);
    if (Object.keys(errs).length > 0) {
      showToast({
        type: "error",
        title: "Form belum lengkap",
        message: "Lengkapi karyawan, tanggal, dan tambahkan minimal satu task."
      });
      return;
    }
    const payload = {
      employee_id: Number(employeeId),
      date,
      tasks: tasks.map(({ title, clickup_url, clickup_task_id, phase, status }) => ({
        title,
        clickup_url,
        clickup_task_id,
        phase,
        status
      }))
    };
    setSaving(true);
    try {
      const res = await saveLsppt(payload);
      showToast({
        type: "success",
        title: "Berhasil",
        message: res.message || "LSPPT saved successfully"
      });
      setTasks([]);
      setTaskForm(EMPTY_TASK_FORM);
    } catch (err) {
      const message = err.response?.data?.message || err.message;
      showToast({
        type: "error",
        title: err.status === 409 ? "Task duplikat" : "Gagal menyimpan LSPPT",
        message
      });
    } finally {
      setSaving(false);
    }
  };
  if (metaLoading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen items-center justify-center bg-slate-50", children: /* @__PURE__ */ jsxDEV(Loading, { size: "lg" }, void 0, false, {
      fileName: "/app/src/pages/SubmitPage.jsx",
      lineNumber: 334,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/SubmitPage.jsx",
      lineNumber: 333,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-slate-50 p-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto max-w-7xl space-y-6", children: [
      /* @__PURE__ */ jsxDEV("header", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-slate-800", children: "LSPPT Tracker" }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 344,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-slate-500", children: "Laporan Status Progress Pekerjaan Karyawan" }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 345,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 343,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/history",
            className: "text-sm font-medium text-blue-600 hover:text-blue-700 hover:underline",
            children: "Lihat History →"
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 349,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/pages/SubmitPage.jsx",
        lineNumber: 342,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "rounded-lg border border-slate-200 bg-white p-5 shadow-sm", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "mb-4 text-sm font-semibold uppercase tracking-wide text-slate-600", children: "Informasi Umum" }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 358,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-2", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                label: "Employee",
                placeholder: "Pilih karyawan",
                options: employees.map((emp) => ({ value: emp.id, label: emp.name })),
                value: employeeId,
                onChange: (e) => setEmployeeId(e.target.value),
                error: formErrors.employeeId
              },
              void 0,
              false,
              {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 363,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: openEmpModal,
                className: "mt-1 text-xs text-slate-500 hover:text-blue-600 hover:underline",
                children: "⚙ Kelola Karyawan"
              },
              void 0,
              false,
              {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 371,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 362,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            DatePicker,
            {
              label: "Tanggal",
              value: date,
              onChange: (e) => {
                setDate(e.target.value);
                setFormErrors((prev) => ({ ...prev, date: void 0 }));
              },
              error: formErrors.date
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 379,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 361,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/SubmitPage.jsx",
        lineNumber: 357,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "rounded-lg border border-slate-200 bg-white p-5 shadow-sm", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "mb-4 text-sm font-semibold uppercase tracking-wide text-slate-600", children: "Tambah Task" }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 389,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: "Task Title",
              placeholder: "Contoh: CTMS - Issue List Report",
              value: taskForm.title,
              onChange: handleTaskFormChange("title"),
              error: rowErrors.title
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 394,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 393,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: "ClickUp URL",
              type: "url",
              placeholder: "https://app.clickup.com/t/9003006723/86d41c8ur",
              value: taskForm.clickupUrl,
              onChange: handleTaskFormChange("clickupUrl"),
              error: rowErrors.clickupUrl
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 402,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: "ClickUp Task ID",
              placeholder: "Otomatis terisi dari URL",
              value: taskForm.clickupTaskId,
              onChange: handleTaskFormChange("clickupTaskId"),
              error: rowErrors.clickupTaskId
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 410,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              label: "Phase",
              placeholder: "Pilih phase",
              options: phaseOptions.map((p) => ({ value: p, label: p })),
              value: taskForm.phase,
              onChange: handleTaskFormChange("phase"),
              error: rowErrors.phase
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 417,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              label: "Status",
              placeholder: taskForm.phase ? "Pilih status" : "Pilih phase terlebih dahulu",
              options: statusOptions.map((s) => ({ value: s, label: s })),
              value: taskForm.status,
              onChange: handleTaskFormChange("status"),
              disabled: !taskForm.phase,
              error: rowErrors.status
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 425,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 392,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex justify-end", children: /* @__PURE__ */ jsxDEV(Button, { type: "button", onClick: handleAddTask, children: "+ Add Task" }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 436,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 435,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/SubmitPage.jsx",
        lineNumber: 388,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "rounded-lg border border-slate-200 bg-white shadow-sm", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-5 pt-5 pb-3", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold uppercase tracking-wide text-slate-600", children: [
            "Daftar Task (",
            tasks.length,
            ")"
          ] }, void 0, true, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 444,
            columnNumber: 13
          }, this),
          formErrors.tasks && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-red-600", children: formErrors.tasks }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 447,
            columnNumber: 34
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 443,
          columnNumber: 11
        }, this),
        tasks.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "px-5 pb-5", children: /* @__PURE__ */ jsxDEV(
          EmptyState,
          {
            title: "Belum ada task",
            description: "Isi form di atas lalu klik “+ Add Task” untuk menambahkan task ke daftar.",
            className: "border-0 py-8"
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 452,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 451,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Table, { children: [
          /* @__PURE__ */ jsxDEV(THead, { children: /* @__PURE__ */ jsxDEV(Tr, { children: [
            /* @__PURE__ */ jsxDEV(Th, { className: "w-12", children: "No" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 462,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Task" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 463,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "ClickUp ID" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 464,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Phase" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 465,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Status" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 466,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { className: "w-24 text-right", children: "Aksi" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 467,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 461,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 460,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TBody, { children: tasks.map(
            (task, index) => /* @__PURE__ */ jsxDEV(Tr, { children: [
              /* @__PURE__ */ jsxDEV(Td, { children: index + 1 }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 473,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "font-medium text-slate-800", children: task.title }, void 0, false, {
                  fileName: "/app/src/pages/SubmitPage.jsx",
                  lineNumber: 475,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "a",
                  {
                    href: task.clickup_url,
                    target: "_blank",
                    rel: "noreferrer",
                    className: "text-xs text-blue-600 hover:underline",
                    children: task.clickup_url
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/pages/SubmitPage.jsx",
                    lineNumber: 476,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 474,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV("code", { className: "rounded bg-slate-100 px-1.5 py-0.5 text-xs", children: task.clickup_task_id }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 486,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 485,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: task.phase }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 490,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV(Badge, { variant: statusBadgeVariant(task.status), children: task.status }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 492,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 491,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { className: "text-right", children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "button",
                  variant: "outline",
                  size: "sm",
                  onClick: () => handleRemoveTask(task.uid),
                  children: "Hapus"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/pages/SubmitPage.jsx",
                  lineNumber: 495,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 494,
                columnNumber: 21
              }, this)
            ] }, task.uid, true, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 472,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 470,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 459,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-t border-slate-100 px-5 py-4", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: tasks.length > 0 ? `${tasks.length} task siap disimpan untuk ${date || "tanggal terpilih"}` : "Belum ada task yang ditambahkan." }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 511,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { type: "button", size: "lg", loading: saving, onClick: handleSave, children: "Save LSPPT" }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 516,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 510,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/SubmitPage.jsx",
        lineNumber: 442,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/SubmitPage.jsx",
      lineNumber: 341,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: empModalOpen,
        onClose: () => setEmpModalOpen(false),
        title: empView === "list" ? "Kelola Karyawan" : empView === "add" ? "Tambah Karyawan" : "Edit Karyawan",
        size: "sm",
        footer: empView === "list" ? /* @__PURE__ */ jsxDEV(Button, { type: "button", onClick: () => {
          setEmpView("add");
          setEmpName("");
        }, children: "+ Tambah Karyawan" }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 536,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          empView === "edit" && /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              variant: "danger",
              loading: empSaving,
              onClick: handleEmpDelete,
              children: "Hapus Karyawan"
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 542,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              variant: "outline",
              onClick: () => setEmpView("list"),
              children: "Batal"
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 551,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              loading: empSaving,
              onClick: empView === "add" ? handleEmpCreate : handleEmpUpdate,
              children: "Simpan"
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 558,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 540,
          columnNumber: 9
        }, this),
        children: empView === "list" ? /* @__PURE__ */ jsxDEV(Table, { children: [
          /* @__PURE__ */ jsxDEV(THead, { children: /* @__PURE__ */ jsxDEV(Tr, { children: [
            /* @__PURE__ */ jsxDEV(Th, { className: "w-10", children: "#" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 573,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Nama" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 574,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { className: "w-20" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 575,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 572,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 571,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(TBody, { children: employees.map(
            (emp, i) => /* @__PURE__ */ jsxDEV(Tr, { children: [
              /* @__PURE__ */ jsxDEV(Td, { children: i + 1 }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 581,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: emp.name }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 582,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "button",
                  variant: "outline",
                  size: "sm",
                  onClick: () => {
                    setEmpView("edit");
                    setEmpEditId(emp.id);
                    setEmpName(emp.name);
                  },
                  children: "Edit"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/pages/SubmitPage.jsx",
                  lineNumber: 584,
                  columnNumber: 21
                },
                this
              ) }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 583,
                columnNumber: 19
              }, this)
            ] }, emp.id, true, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 580,
              columnNumber: 13
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 578,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 570,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(
          Input,
          {
            label: "Nama Karyawan",
            placeholder: "Masukkan nama",
            value: empName,
            onChange: (e) => setEmpName(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 602,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "/app/src/pages/SubmitPage.jsx",
        lineNumber: 523,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: deleteConfirmOpen,
        onClose: () => {
          setDeleteConfirmOpen(false);
          setDeleteTarget(null);
        },
        title: "Hapus Karyawan",
        size: "sm",
        footer: /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: () => {
            setDeleteConfirmOpen(false);
            setDeleteTarget(null);
          }, children: "Batal" }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 618,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "danger", loading: deleteLoading, onClick: handleConfirmDelete, children: "Hapus" }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 621,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 617,
          columnNumber: 9
        }, this),
        children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-700", children: [
            "Yakin ingin menghapus ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: deleteTarget?.name }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 628,
              columnNumber: 33
            }, this),
            "?"
          ] }, void 0, true, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 627,
            columnNumber: 9
          }, this),
          deleteTaskCount > 0 && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 rounded-md bg-red-50 p-3 text-sm text-red-700", children: [
            "Karyawan ini memiliki ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: [
              deleteTaskCount,
              " task"
            ] }, void 0, true, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 632,
              columnNumber: 35
            }, this),
            ". Semua task dan progress-nya juga akan dihapus secara permanen."
          ] }, void 0, true, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 631,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/app/src/pages/SubmitPage.jsx",
        lineNumber: 611,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/pages/SubmitPage.jsx",
    lineNumber: 340,
    columnNumber: 5
  }, this);
}
_s(SubmitPage, "2MkhY+YvdJEKxuhhYlgWITOv/Dk=", false, function() {
  return [useToast];
});
_c = SubmitPage;
var _c;
$RefreshReg$(_c, "SubmitPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/pages/SubmitPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/pages/SubmitPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMFRRLFNBOE1JLFVBOU1KOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFUUixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsWUFBWTtBQUNyQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxNQUFNQyxxQkFBcUI7QUFFM0IsTUFBTUMsa0JBQWtCO0FBQUEsRUFDdEJDLE9BQU87QUFBQSxFQUNQQyxZQUFZO0FBQUEsRUFDWkMsZUFBZTtBQUFBLEVBQ2ZDLE9BQU87QUFBQSxFQUNQQyxRQUFRO0FBQ1Y7QUFFQSxJQUFJQyxVQUFVO0FBRWQsU0FBU0MsaUJBQWlCQyxLQUFLO0FBQzdCLFFBQU1DLFFBQVFELElBQUlDLE1BQU1WLGtCQUFrQjtBQUMxQyxTQUFPVSxRQUFRQSxNQUFNLENBQUMsSUFBSTtBQUM1QjtBQUVBLFNBQVNDLG1CQUFtQkwsUUFBUTtBQUNsQyxRQUFNTSxJQUFJTixPQUFPTyxZQUFZO0FBQzdCLE1BQUlELEVBQUVFLFdBQVcsV0FBVyxFQUFHLFFBQU87QUFDdEMsTUFBSUYsRUFBRUcsU0FBUyxVQUFVLEtBQUtILEVBQUVHLFNBQVMsU0FBUyxLQUFLSCxFQUFFRyxTQUFTLGVBQWUsRUFBRyxRQUFPO0FBQzNGLE1BQUlILEVBQUVHLFNBQVMsTUFBTSxLQUFLSCxFQUFFRyxTQUFTLFVBQVUsRUFBRyxRQUFPO0FBQ3pELFNBQU87QUFDVDtBQUVBLHdCQUF3QkMsYUFBYTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sRUFBRUMsVUFBVSxJQUFJMUIsU0FBUztBQUUvQixRQUFNLENBQUMyQixXQUFXQyxZQUFZLElBQUk1QyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDNkMsUUFBUUMsU0FBUyxJQUFJOUMsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDK0MsYUFBYUMsY0FBYyxJQUFJaEQsU0FBUyxJQUFJO0FBRW5ELFFBQU0sQ0FBQ2lELFlBQVlDLGFBQWEsSUFBSWxELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNtRCxNQUFNQyxPQUFPLElBQUlwRCxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDcUQsWUFBWUMsYUFBYSxJQUFJdEQsU0FBUyxDQUFDLENBQUM7QUFFL0MsUUFBTSxDQUFDdUQsVUFBVUMsV0FBVyxJQUFJeEQsU0FBU3lCLGVBQWU7QUFDeEQsUUFBTSxDQUFDZ0MsV0FBV0MsWUFBWSxJQUFJMUQsU0FBUyxDQUFDLENBQUM7QUFDN0MsUUFBTSxDQUFDMkQsT0FBT0MsUUFBUSxJQUFJNUQsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzZELFFBQVFDLFNBQVMsSUFBSTlELFNBQVMsS0FBSztBQUUxQyxRQUFNLENBQUMrRCxjQUFjQyxlQUFlLElBQUloRSxTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDaUUsU0FBU0MsVUFBVSxJQUFJbEUsU0FBUyxNQUFNO0FBQzdDLFFBQU0sQ0FBQ21FLFdBQVdDLFlBQVksSUFBSXBFLFNBQVMsSUFBSTtBQUMvQyxRQUFNLENBQUNxRSxTQUFTQyxVQUFVLElBQUl0RSxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDdUUsV0FBV0MsWUFBWSxJQUFJeEUsU0FBUyxLQUFLO0FBRWhELFFBQU0sQ0FBQ3lFLG1CQUFtQkMsb0JBQW9CLElBQUkxRSxTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDMkUsY0FBY0MsZUFBZSxJQUFJNUUsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQzZFLGlCQUFpQkMsa0JBQWtCLElBQUk5RSxTQUFTLENBQUM7QUFDeEQsUUFBTSxDQUFDK0UsZUFBZUMsZ0JBQWdCLElBQUloRixTQUFTLEtBQUs7QUFFeERELFlBQVUsTUFBTTtBQUNkLFFBQUlrRixZQUFZO0FBQ2hCQyxZQUFRQyxJQUFJLENBQUNsRSxhQUFhLEdBQUdDLFVBQVUsQ0FBQyxDQUFDLEVBQ3RDa0UsS0FBSyxDQUFDLENBQUNDLFFBQVFDLFFBQVEsTUFBTTtBQUM1QixVQUFJTCxVQUFXO0FBQ2ZyQyxtQkFBYXlDLE9BQU9FLElBQUk7QUFDeEJ6QyxnQkFBVXdDLFNBQVNDLElBQUk7QUFBQSxJQUN6QixDQUFDLEVBQ0FDLE1BQU0sQ0FBQ0MsUUFBUTtBQUNkLFVBQUlSLFVBQVc7QUFDZnZDLGdCQUFVO0FBQUEsUUFDUmdELE1BQU07QUFBQSxRQUNOaEUsT0FBTztBQUFBLFFBQ1BpRSxTQUFTRixJQUFJRyxVQUFVTCxNQUFNSSxXQUFXRixJQUFJRTtBQUFBQSxNQUM5QyxDQUFDO0FBQUEsSUFDSCxDQUFDLEVBQ0FFLFFBQVEsTUFBTTtBQUNiLFVBQUksQ0FBQ1osVUFBV2pDLGdCQUFlLEtBQUs7QUFBQSxJQUN0QyxDQUFDO0FBQ0gsV0FBTyxNQUFNO0FBQ1hpQyxrQkFBWTtBQUFBLElBQ2Q7QUFBQSxFQUNGLEdBQUcsQ0FBQ3ZDLFNBQVMsQ0FBQztBQUVkLFFBQU1vRCxnQkFBZ0JBLE1BQU07QUFDMUI3RSxpQkFBYSxFQUNWbUUsS0FBSyxDQUFDVyxRQUFRbkQsYUFBYW1ELElBQUlSLElBQUksQ0FBQyxFQUNwQ0MsTUFBTSxNQUFNO0FBQUEsSUFBQyxDQUFDO0FBQUEsRUFDbkI7QUFFQSxRQUFNUSxlQUFlQSxNQUFNO0FBQ3pCOUIsZUFBVyxNQUFNO0FBQ2pCRSxpQkFBYSxJQUFJO0FBQ2pCRSxlQUFXLEVBQUU7QUFDYk4sb0JBQWdCLElBQUk7QUFBQSxFQUN0QjtBQUVBLFFBQU1pQyxrQkFBa0IsWUFBWTtBQUNsQyxRQUFJLENBQUM1QixRQUFRNkIsS0FBSyxFQUFHO0FBQ3JCMUIsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTXBELGVBQWVpRCxRQUFRNkIsS0FBSyxDQUFDO0FBQ25DeEQsZ0JBQVUsRUFBRWdELE1BQU0sV0FBV2hFLE9BQU8sWUFBWWlFLFNBQVMsdUJBQXVCLENBQUM7QUFDakZHLG9CQUFjO0FBQ2Q1QixpQkFBVyxNQUFNO0FBQ2pCSSxpQkFBVyxFQUFFO0FBQUEsSUFDZixTQUFTbUIsS0FBSztBQUNaL0MsZ0JBQVUsRUFBRWdELE1BQU0sU0FBU2hFLE9BQU8sU0FBU2lFLFNBQVNGLElBQUlFLFFBQVEsQ0FBQztBQUFBLElBQ25FLFVBQUM7QUFDQ25CLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNMkIsa0JBQWtCLFlBQVk7QUFDbEMsUUFBSSxDQUFDOUIsUUFBUTZCLEtBQUssS0FBSyxDQUFDL0IsVUFBVztBQUNuQ0ssaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTW5ELGVBQWU4QyxXQUFXRSxRQUFRNkIsS0FBSyxDQUFDO0FBQzlDeEQsZ0JBQVUsRUFBRWdELE1BQU0sV0FBV2hFLE9BQU8sWUFBWWlFLFNBQVMsc0JBQXNCLENBQUM7QUFDaEZHLG9CQUFjO0FBQ2Q1QixpQkFBVyxNQUFNO0FBQ2pCRSxtQkFBYSxJQUFJO0FBQ2pCRSxpQkFBVyxFQUFFO0FBQUEsSUFDZixTQUFTbUIsS0FBSztBQUNaL0MsZ0JBQVUsRUFBRWdELE1BQU0sU0FBU2hFLE9BQU8sU0FBU2lFLFNBQVNGLElBQUlFLFFBQVEsQ0FBQztBQUFBLElBQ25FLFVBQUM7QUFDQ25CLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEIsa0JBQWtCLFlBQVk7QUFDbEMsUUFBSSxDQUFDakMsVUFBVztBQUNoQixRQUFJO0FBQ0YsWUFBTTRCLE1BQU0sTUFBTXhFLHFCQUFxQjRDLFNBQVM7QUFDaERTLHNCQUFnQixFQUFFeUIsSUFBSWxDLFdBQVdtQyxNQUFNakMsUUFBUSxDQUFDO0FBQ2hEUyx5QkFBbUJpQixJQUFJUSxLQUFLO0FBQzVCN0IsMkJBQXFCLElBQUk7QUFBQSxJQUMzQixTQUFTZSxLQUFLO0FBQ1ovQyxnQkFBVSxFQUFFZ0QsTUFBTSxTQUFTaEUsT0FBTyxTQUFTaUUsU0FBU0YsSUFBSUUsUUFBUSxDQUFDO0FBQUEsSUFDbkU7QUFBQSxFQUNGO0FBRUEsUUFBTWEsc0JBQXNCLFlBQVk7QUFDdEMsUUFBSSxDQUFDN0IsYUFBYztBQUNuQksscUJBQWlCLElBQUk7QUFDckIsUUFBSTtBQUNGLFlBQU0xRCxlQUFlcUQsYUFBYTBCLEVBQUU7QUFDcEMzRCxnQkFBVSxFQUFFZ0QsTUFBTSxXQUFXaEUsT0FBTyxZQUFZaUUsU0FBUyxtQkFBbUIsQ0FBQztBQUM3RUcsb0JBQWM7QUFDZDVCLGlCQUFXLE1BQU07QUFDakJFLG1CQUFhLElBQUk7QUFDakJFLGlCQUFXLEVBQUU7QUFDYkksMkJBQXFCLEtBQUs7QUFDMUJFLHNCQUFnQixJQUFJO0FBQUEsSUFDdEIsU0FBU2EsS0FBSztBQUNaL0MsZ0JBQVUsRUFBRWdELE1BQU0sU0FBU2hFLE9BQU8sbUJBQW1CaUUsU0FBU0YsSUFBSUUsUUFBUSxDQUFDO0FBQUEsSUFDN0UsVUFBQztBQUNDWCx1QkFBaUIsS0FBSztBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUVBLFFBQU15QixlQUFlQyxPQUFPQyxLQUFLOUQsTUFBTTtBQUN2QyxRQUFNK0QsZ0JBQWdCckQsU0FBUzFCLFFBQVFnQixPQUFPVSxTQUFTMUIsS0FBSyxLQUFLLEtBQUs7QUFFdEUsUUFBTWdGLHVCQUF1QkEsQ0FBQ0MsVUFBVSxDQUFDQyxNQUFNO0FBQzdDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUVwQixRQUFJSCxVQUFVLFNBQVM7QUFDckJ0RCxrQkFBWSxDQUFDMEQsVUFBVSxFQUFFLEdBQUdBLE1BQU1yRixPQUFPbUYsT0FBT2xGLFFBQVEsR0FBRyxFQUFFO0FBQzdENEIsbUJBQWEsQ0FBQ3dELFVBQVUsRUFBRSxHQUFHQSxNQUFNckYsT0FBT3NGLFFBQVdyRixRQUFRcUYsT0FBVSxFQUFFO0FBQ3pFO0FBQUEsSUFDRjtBQUVBLFFBQUlMLFVBQVUsY0FBYztBQUMxQixZQUFNTSxZQUFZcEYsaUJBQWlCZ0YsS0FBSztBQUN4Q3hELGtCQUFZLENBQUMwRCxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSHZGLFlBQVlxRjtBQUFBQSxRQUNaLEdBQUlJLFlBQVksRUFBRXhGLGVBQWV3RixVQUFVLElBQUksQ0FBQztBQUFBLE1BQ2xELEVBQUU7QUFDRjFEO0FBQUFBLFFBQWEsQ0FBQ3dELFNBQ1pFLFlBQ0ksRUFBRSxHQUFHRixNQUFNdkYsWUFBWXdGLFFBQVd2RixlQUFldUYsT0FBVSxJQUMzRCxFQUFFLEdBQUdELE1BQU12RixZQUFZd0YsT0FBVTtBQUFBLE1BQ3ZDO0FBQ0E7QUFBQSxJQUNGO0FBRUEzRCxnQkFBWSxDQUFDMEQsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0osS0FBSyxHQUFHRSxNQUFNLEVBQUU7QUFDbkR0RCxpQkFBYSxDQUFDd0QsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0osS0FBSyxHQUFHSyxPQUFVLEVBQUU7QUFBQSxFQUMxRDtBQUVBLFFBQU1FLG1CQUFtQkEsTUFBTTtBQUM3QixVQUFNQyxPQUFPLENBQUM7QUFDZCxRQUFJLENBQUNyRSxXQUFZcUUsTUFBS3JFLGFBQWE7QUFDbkMsUUFBSSxDQUFDRSxLQUFNbUUsTUFBS25FLE9BQU87QUFDdkIsUUFBSSxDQUFDSSxTQUFTN0IsTUFBTXdFLEtBQUssRUFBR29CLE1BQUs1RixRQUFRO0FBRXpDLFFBQUksQ0FBQzZCLFNBQVM1QixXQUFXdUUsS0FBSyxFQUFHb0IsTUFBSzNGLGFBQWE7QUFBQSxhQUMxQyxDQUFDSyxpQkFBaUJ1QixTQUFTNUIsV0FBV3VFLEtBQUssQ0FBQztBQUNuRG9CLFdBQUszRixhQUFhO0FBRXBCLFFBQUksQ0FBQzRCLFNBQVMzQixjQUFjc0UsS0FBSyxFQUFHb0IsTUFBSzFGLGdCQUFnQjtBQUFBLGFBRXZEK0IsTUFBTTREO0FBQUFBLE1BQ0osQ0FBQ0MsTUFBTUEsRUFBRUMsZ0JBQWdCcEYsWUFBWSxNQUFNa0IsU0FBUzNCLGNBQWNzRSxLQUFLLEVBQUU3RCxZQUFZO0FBQUEsSUFDdkY7QUFFQWlGLFdBQUsxRixnQkFBZ0I7QUFFdkIsUUFBSSxDQUFDMkIsU0FBUzFCLE1BQU95RixNQUFLekYsUUFBUTtBQUNsQyxRQUFJLENBQUMwQixTQUFTekIsT0FBUXdGLE1BQUt4RixTQUFTO0FBRXBDLFdBQU93RjtBQUFBQSxFQUNUO0FBRUEsUUFBTUksZ0JBQWdCQSxNQUFNO0FBQzFCLFVBQU1KLE9BQU9ELGlCQUFpQjtBQUM5QjNELGlCQUFhNEQsSUFBSTtBQUNqQmhFLGtCQUFjLEVBQUVMLFlBQVlxRSxLQUFLckUsWUFBWUUsTUFBTW1FLEtBQUtuRSxLQUFLLENBQUM7QUFDOUQsUUFBSXVELE9BQU9DLEtBQUtXLElBQUksRUFBRUssU0FBUyxFQUFHO0FBRWxDL0Q7QUFBQUEsTUFBUyxDQUFDc0QsU0FBUztBQUFBLFFBQ2pCLEdBQUdBO0FBQUFBLFFBQ0g7QUFBQSxVQUNFVSxLQUFLLEVBQUU3RjtBQUFBQSxVQUNQTCxPQUFPNkIsU0FBUzdCLE1BQU13RSxLQUFLO0FBQUEsVUFDM0IyQixhQUFhdEUsU0FBUzVCLFdBQVd1RSxLQUFLO0FBQUEsVUFDdEN1QixpQkFBaUJsRSxTQUFTM0IsY0FBY3NFLEtBQUs7QUFBQSxVQUM3Q3JFLE9BQU8wQixTQUFTMUI7QUFBQUEsVUFDaEJDLFFBQVF5QixTQUFTekI7QUFBQUEsUUFDbkI7QUFBQSxNQUFDO0FBQUEsSUFDRjtBQUNEMEIsZ0JBQVkvQixlQUFlO0FBQUEsRUFDN0I7QUFFQSxRQUFNcUcsbUJBQW1CQSxDQUFDRixRQUFRO0FBQ2hDaEUsYUFBUyxDQUFDc0QsU0FBU0EsS0FBS2EsT0FBTyxDQUFDUCxNQUFNQSxFQUFFSSxRQUFRQSxHQUFHLENBQUM7QUFBQSxFQUN0RDtBQUVBLFFBQU1JLGFBQWEsWUFBWTtBQUM3QixVQUFNVixPQUFPLENBQUM7QUFDZCxRQUFJLENBQUNyRSxXQUFZcUUsTUFBS3JFLGFBQWE7QUFDbkMsUUFBSSxDQUFDRSxLQUFNbUUsTUFBS25FLE9BQU87QUFDdkIsUUFBSVEsTUFBTWdFLFdBQVcsRUFBR0wsTUFBSzNELFFBQVE7QUFDckNMLGtCQUFjZ0UsSUFBSTtBQUVsQixRQUFJWixPQUFPQyxLQUFLVyxJQUFJLEVBQUVLLFNBQVMsR0FBRztBQUNoQ2pGLGdCQUFVO0FBQUEsUUFDUmdELE1BQU07QUFBQSxRQUNOaEUsT0FBTztBQUFBLFFBQ1BpRSxTQUFTO0FBQUEsTUFDWCxDQUFDO0FBQ0Q7QUFBQSxJQUNGO0FBRUEsVUFBTXNDLFVBQVU7QUFBQSxNQUNkQyxhQUFhQyxPQUFPbEYsVUFBVTtBQUFBLE1BQzlCRTtBQUFBQSxNQUNBUSxPQUFPQSxNQUFNeUUsSUFBSSxDQUFDLEVBQUUxRyxPQUFPbUcsYUFBYUosaUJBQWlCNUYsT0FBT0MsT0FBTyxPQUFPO0FBQUEsUUFDNUVKO0FBQUFBLFFBQ0FtRztBQUFBQSxRQUNBSjtBQUFBQSxRQUNBNUY7QUFBQUEsUUFDQUM7QUFBQUEsTUFDRixFQUFFO0FBQUEsSUFDSjtBQUVBZ0MsY0FBVSxJQUFJO0FBQ2QsUUFBSTtBQUNGLFlBQU1pQyxNQUFNLE1BQU01RSxVQUFVOEcsT0FBTztBQUNuQ3ZGLGdCQUFVO0FBQUEsUUFDUmdELE1BQU07QUFBQSxRQUNOaEUsT0FBTztBQUFBLFFBQ1BpRSxTQUFTSSxJQUFJSixXQUFXO0FBQUEsTUFDMUIsQ0FBQztBQUNEL0IsZUFBUyxFQUFFO0FBQ1hKLGtCQUFZL0IsZUFBZTtBQUFBLElBQzdCLFNBQVNnRSxLQUFLO0FBQ1osWUFBTUUsVUFBVUYsSUFBSUcsVUFBVUwsTUFBTUksV0FBV0YsSUFBSUU7QUFDbkRqRCxnQkFBVTtBQUFBLFFBQ1JnRCxNQUFNO0FBQUEsUUFDTmhFLE9BQU8rRCxJQUFJM0QsV0FBVyxNQUFNLGtCQUFrQjtBQUFBLFFBQzlDNkQ7QUFBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0M3QixnQkFBVSxLQUFLO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsTUFBSWYsYUFBYTtBQUNmLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLDZEQUNiLGlDQUFDLFdBQVEsTUFBSyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0IsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsNkJBQUMsWUFBTyxXQUFVLHFDQUNoQjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxRQUFHLFdBQVUscUNBQW9DLDZCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRDtBQUFBLFVBQy9ELHVCQUFDLE9BQUUsV0FBVSwrQkFBOEIsMERBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUc7QUFBQSxZQUNILFdBQVU7QUFBQSxZQUF1RTtBQUFBO0FBQUEsVUFGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BRUEsdUJBQUMsYUFBUSxXQUFVLDZEQUNqQjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxRUFBb0UsOEJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLGFBQVk7QUFBQSxnQkFDWixTQUFTSixVQUFVeUYsSUFBSSxDQUFDQyxTQUFTLEVBQUVyQixPQUFPcUIsSUFBSWhDLElBQUlpQyxPQUFPRCxJQUFJL0IsS0FBSyxFQUFFO0FBQUEsZ0JBQ3BFLE9BQU9yRDtBQUFBQSxnQkFDUCxVQUFVLENBQUM4RCxNQUFNN0QsY0FBYzZELEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxnQkFDN0MsT0FBTzNELFdBQVdKO0FBQUFBO0FBQUFBLGNBTnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU0rQjtBQUFBLFlBRS9CO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMrQztBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQWlFO0FBQUE7QUFBQSxjQUg3RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPN0M7QUFBQUEsY0FDUCxVQUFVLENBQUM0RCxNQUFNO0FBQUUzRCx3QkFBUTJELEVBQUVFLE9BQU9ELEtBQUs7QUFBRzFELDhCQUFjLENBQUM0RCxVQUFVLEVBQUUsR0FBR0EsTUFBTS9ELE1BQU1nRSxPQUFVLEVBQUU7QUFBQSxjQUFHO0FBQUEsY0FDckcsT0FBTzlELFdBQVdGO0FBQUFBO0FBQUFBLFlBSnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl5QjtBQUFBLGFBdEIzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsV0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZCQTtBQUFBLE1BRUEsdUJBQUMsYUFBUSxXQUFVLDZEQUNqQjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxRUFBb0UsMkJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixhQUFZO0FBQUEsY0FDWixPQUFPSSxTQUFTN0I7QUFBQUEsY0FDaEIsVUFBVW1GLHFCQUFxQixPQUFPO0FBQUEsY0FDdEMsT0FBT3BELFVBQVUvQjtBQUFBQTtBQUFBQSxZQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLeUIsS0FOM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE1BQUs7QUFBQSxjQUNMLGFBQVk7QUFBQSxjQUNaLE9BQU82QixTQUFTNUI7QUFBQUEsY0FDaEIsVUFBVWtGLHFCQUFxQixZQUFZO0FBQUEsY0FDM0MsT0FBT3BELFVBQVU5QjtBQUFBQTtBQUFBQSxZQU5uQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNOEI7QUFBQSxVQUU5QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sYUFBWTtBQUFBLGNBQ1osT0FBTzRCLFNBQVMzQjtBQUFBQSxjQUNoQixVQUFVaUYscUJBQXFCLGVBQWU7QUFBQSxjQUM5QyxPQUFPcEQsVUFBVTdCO0FBQUFBO0FBQUFBLFlBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtpQztBQUFBLFVBRWpDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixhQUFZO0FBQUEsY0FDWixTQUFTNkUsYUFBYTJCLElBQUksQ0FBQ0csT0FBTyxFQUFFdkIsT0FBT3VCLEdBQUdELE9BQU9DLEVBQUUsRUFBRTtBQUFBLGNBQ3pELE9BQU9oRixTQUFTMUI7QUFBQUEsY0FDaEIsVUFBVWdGLHFCQUFxQixPQUFPO0FBQUEsY0FDdEMsT0FBT3BELFVBQVU1QjtBQUFBQTtBQUFBQSxZQU5uQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNeUI7QUFBQSxVQUV6QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sYUFBYTBCLFNBQVMxQixRQUFRLGlCQUFpQjtBQUFBLGNBQy9DLFNBQVMrRSxjQUFjd0IsSUFBSSxDQUFDaEcsT0FBTyxFQUFFNEUsT0FBTzVFLEdBQUdrRyxPQUFPbEcsRUFBRSxFQUFFO0FBQUEsY0FDMUQsT0FBT21CLFNBQVN6QjtBQUFBQSxjQUNoQixVQUFVK0UscUJBQXFCLFFBQVE7QUFBQSxjQUN2QyxVQUFVLENBQUN0RCxTQUFTMUI7QUFBQUEsY0FDcEIsT0FBTzRCLFVBQVUzQjtBQUFBQTtBQUFBQSxZQVBuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPMEI7QUFBQSxhQXhDNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBDQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiLGlDQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVM0RixlQUFlLDBCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0RBO0FBQUEsTUFFQSx1QkFBQyxhQUFRLFdBQVUseURBQ2pCO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGdFQUErRDtBQUFBO0FBQUEsWUFDN0QvRCxNQUFNZ0U7QUFBQUEsWUFBTztBQUFBLGVBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDdEUsV0FBV00sU0FBUyx1QkFBQyxPQUFFLFdBQVUsd0JBQXdCTixxQkFBV00sU0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Q7QUFBQSxhQUo3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUVDQSxNQUFNZ0UsV0FBVyxJQUNoQix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sYUFBWTtBQUFBLFlBQ1osV0FBVTtBQUFBO0FBQUEsVUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHMkIsS0FKN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLElBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFNBQ0MsaUNBQUMsTUFDQztBQUFBLG1DQUFDLE1BQUcsV0FBVSxRQUFPLGtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QjtBQUFBLFlBQ3ZCLHVCQUFDLE1BQUcsb0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUTtBQUFBLFlBQ1IsdUJBQUMsTUFBRywwQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFjO0FBQUEsWUFDZCx1QkFBQyxNQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVM7QUFBQSxZQUNULHVCQUFDLE1BQUcsc0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBVTtBQUFBLFlBQ1YsdUJBQUMsTUFBRyxXQUFVLG1CQUFrQixvQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0M7QUFBQSxlQU50QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBQ0EsdUJBQUMsU0FDRWhFLGdCQUFNeUU7QUFBQUEsWUFBSSxDQUFDSSxNQUFNQyxVQUNoQix1QkFBQyxNQUNDO0FBQUEscUNBQUMsTUFBSUEsa0JBQVEsS0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlO0FBQUEsY0FDZix1QkFBQyxNQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLDhCQUE4QkQsZUFBSzlHLFNBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNEO0FBQUEsZ0JBQ3REO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQU04RyxLQUFLWDtBQUFBQSxvQkFDWCxRQUFPO0FBQUEsb0JBQ1AsS0FBSTtBQUFBLG9CQUNKLFdBQVU7QUFBQSxvQkFFVFcsZUFBS1g7QUFBQUE7QUFBQUEsa0JBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBQ0EsdUJBQUMsTUFDQyxpQ0FBQyxVQUFLLFdBQVUsOENBQ2JXLGVBQUtmLG1CQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxNQUFJZSxlQUFLM0csU0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQjtBQUFBLGNBQ2hCLHVCQUFDLE1BQ0MsaUNBQUMsU0FBTSxTQUFTTSxtQkFBbUJxRyxLQUFLMUcsTUFBTSxHQUFJMEcsZUFBSzFHLFVBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThELEtBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE1BQUcsV0FBVSxjQUNaO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFRO0FBQUEsa0JBQ1IsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTWdHLGlCQUFpQlUsS0FBS1osR0FBRztBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsaUJBL0JPWSxLQUFLWixLQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0NBO0FBQUEsVUFDRCxLQW5DSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9DQTtBQUFBLGFBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnREE7QUFBQSxRQUdGLHVCQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSwwQkFDVmpFLGdCQUFNZ0UsU0FBUyxJQUNaLEdBQUdoRSxNQUFNZ0UsTUFBTSw2QkFBNkJ4RSxRQUFRLGtCQUFrQixLQUN0RSxzQ0FITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLE1BQUssVUFBUyxNQUFLLE1BQUssU0FBU1UsUUFBUSxTQUFTbUUsWUFBWSwwQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0E3RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThFQTtBQUFBLFNBbkxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvTEE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNakU7QUFBQUEsUUFDTixTQUFTLE1BQU1DLGdCQUFnQixLQUFLO0FBQUEsUUFDcEMsT0FDRUMsWUFBWSxTQUNSLG9CQUNBQSxZQUFZLFFBQ1Ysb0JBQ0E7QUFBQSxRQUVSLE1BQUs7QUFBQSxRQUNMLFFBQ0VBLFlBQVksU0FDVix1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFTLE1BQU07QUFBRUMscUJBQVcsS0FBSztBQUFHSSxxQkFBVyxFQUFFO0FBQUEsUUFBRyxHQUFHLGlDQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQSxtQ0FDR0w7QUFBQUEsc0JBQVksVUFDWDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUTtBQUFBLGNBQ1IsU0FBU007QUFBQUEsY0FDVCxTQUFTNkI7QUFBQUEsY0FBZ0I7QUFBQTtBQUFBLFlBSjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFFRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUTtBQUFBLGNBQ1IsU0FBUyxNQUFNbEMsV0FBVyxNQUFNO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFIcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTSztBQUFBQSxjQUNULFNBQVNOLFlBQVksUUFBUWdDLGtCQUFrQkU7QUFBQUEsY0FBZ0I7QUFBQTtBQUFBLFlBSGpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFFBSUhsQyxzQkFBWSxTQUNYLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUNDLGlDQUFDLE1BQ0M7QUFBQSxtQ0FBQyxNQUFHLFdBQVUsUUFBTyxpQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0I7QUFBQSxZQUN0Qix1QkFBQyxNQUFHLG9CQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVE7QUFBQSxZQUNSLHVCQUFDLE1BQUcsV0FBVSxVQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFCO0FBQUEsZUFIdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0V0QixvQkFBVXlGO0FBQUFBLFlBQUksQ0FBQ0MsS0FBS0ssTUFDbkIsdUJBQUMsTUFDQztBQUFBLHFDQUFDLE1BQUlBLGNBQUksS0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFXO0FBQUEsY0FDWCx1QkFBQyxNQUFJTCxjQUFJL0IsUUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFjO0FBQUEsY0FDZCx1QkFBQyxNQUNDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFRO0FBQUEsa0JBQ1IsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTTtBQUNicEMsK0JBQVcsTUFBTTtBQUNqQkUsaUNBQWFpRSxJQUFJaEMsRUFBRTtBQUNuQi9CLCtCQUFXK0QsSUFBSS9CLElBQUk7QUFBQSxrQkFDckI7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsaUJBaEJPK0IsSUFBSWhDLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxVQUNELEtBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsYUE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThCQSxJQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixhQUFZO0FBQUEsWUFDWixPQUFPaEM7QUFBQUEsWUFDUCxVQUFVLENBQUMwQyxNQUFNekMsV0FBV3lDLEVBQUVFLE9BQU9ELEtBQUs7QUFBQTtBQUFBLFVBSjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk4QztBQUFBO0FBQUEsTUFuRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXNGQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU12QztBQUFBQSxRQUNOLFNBQVMsTUFBTTtBQUFFQywrQkFBcUIsS0FBSztBQUFHRSwwQkFBZ0IsSUFBSTtBQUFBLFFBQUc7QUFBQSxRQUNyRSxPQUFNO0FBQUEsUUFDTixNQUFLO0FBQUEsUUFDTCxRQUNFLG1DQUNFO0FBQUEsaUNBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUyxNQUFNO0FBQUVGLGlDQUFxQixLQUFLO0FBQUdFLDRCQUFnQixJQUFJO0FBQUEsVUFBRyxHQUFHLHFCQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLFNBQVEsVUFBUyxTQUFTRyxlQUFlLFNBQVN5QixxQkFBcUIscUJBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBR0Y7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsMEJBQXlCO0FBQUE7QUFBQSxZQUNkLHVCQUFDLFVBQUssV0FBVSxpQkFBaUI3Qix3QkFBYzJCLFFBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9EO0FBQUEsWUFBTztBQUFBLGVBRG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDekIsa0JBQWtCLEtBQ2pCLHVCQUFDLE9BQUUsV0FBVSxzREFBcUQ7QUFBQTtBQUFBLFlBQzFDLHVCQUFDLFVBQUssV0FBVSxpQkFBaUJBO0FBQUFBO0FBQUFBLGNBQWdCO0FBQUEsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsWUFBTztBQUFBLGVBRHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBO0FBQUEsTUF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBd0JBO0FBQUEsT0F2U0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdTQTtBQUVKO0FBQUNwQyxHQXBqQnVCRCxZQUFVO0FBQUEsVUFDVnhCLFFBQVE7QUFBQTtBQUFBLEtBRFJ3QjtBQUFVLElBQUFtRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkxpbmsiLCJCYWRnZSIsIkJ1dHRvbiIsIkRhdGVQaWNrZXIiLCJFbXB0eVN0YXRlIiwiSW5wdXQiLCJMb2FkaW5nIiwiTW9kYWwiLCJTZWxlY3QiLCJUYWJsZSIsIlRCb2R5IiwiVGQiLCJUaCIsIlRIZWFkIiwiVHIiLCJ1c2VUb2FzdCIsImdldEVtcGxveWVlcyIsImdldFBoYXNlcyIsInNhdmVMc3BwdCIsImNyZWF0ZUVtcGxveWVlIiwidXBkYXRlRW1wbG95ZWUiLCJkZWxldGVFbXBsb3llZSIsImdldEVtcGxveWVlVGFza0NvdW50IiwiQ0xJQ0tVUF9JRF9QQVRURVJOIiwiRU1QVFlfVEFTS19GT1JNIiwidGl0bGUiLCJjbGlja3VwVXJsIiwiY2xpY2t1cFRhc2tJZCIsInBoYXNlIiwic3RhdHVzIiwidGFza1NlcSIsImV4dHJhY3RDbGlja1VwSWQiLCJ1cmwiLCJtYXRjaCIsInN0YXR1c0JhZGdlVmFyaWFudCIsInMiLCJ0b0xvd2VyQ2FzZSIsInN0YXJ0c1dpdGgiLCJpbmNsdWRlcyIsIlN1Ym1pdFBhZ2UiLCJfcyIsInNob3dUb2FzdCIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsInBoYXNlcyIsInNldFBoYXNlcyIsIm1ldGFMb2FkaW5nIiwic2V0TWV0YUxvYWRpbmciLCJlbXBsb3llZUlkIiwic2V0RW1wbG95ZWVJZCIsImRhdGUiLCJzZXREYXRlIiwiZm9ybUVycm9ycyIsInNldEZvcm1FcnJvcnMiLCJ0YXNrRm9ybSIsInNldFRhc2tGb3JtIiwicm93RXJyb3JzIiwic2V0Um93RXJyb3JzIiwidGFza3MiLCJzZXRUYXNrcyIsInNhdmluZyIsInNldFNhdmluZyIsImVtcE1vZGFsT3BlbiIsInNldEVtcE1vZGFsT3BlbiIsImVtcFZpZXciLCJzZXRFbXBWaWV3IiwiZW1wRWRpdElkIiwic2V0RW1wRWRpdElkIiwiZW1wTmFtZSIsInNldEVtcE5hbWUiLCJlbXBTYXZpbmciLCJzZXRFbXBTYXZpbmciLCJkZWxldGVDb25maXJtT3BlbiIsInNldERlbGV0ZUNvbmZpcm1PcGVuIiwiZGVsZXRlVGFyZ2V0Iiwic2V0RGVsZXRlVGFyZ2V0IiwiZGVsZXRlVGFza0NvdW50Iiwic2V0RGVsZXRlVGFza0NvdW50IiwiZGVsZXRlTG9hZGluZyIsInNldERlbGV0ZUxvYWRpbmciLCJjYW5jZWxsZWQiLCJQcm9taXNlIiwiYWxsIiwidGhlbiIsImVtcFJlcyIsInBoYXNlUmVzIiwiZGF0YSIsImNhdGNoIiwiZXJyIiwidHlwZSIsIm1lc3NhZ2UiLCJyZXNwb25zZSIsImZpbmFsbHkiLCJsb2FkRW1wbG95ZWVzIiwicmVzIiwib3BlbkVtcE1vZGFsIiwiaGFuZGxlRW1wQ3JlYXRlIiwidHJpbSIsImhhbmRsZUVtcFVwZGF0ZSIsImhhbmRsZUVtcERlbGV0ZSIsImlkIiwibmFtZSIsImNvdW50IiwiaGFuZGxlQ29uZmlybURlbGV0ZSIsInBoYXNlT3B0aW9ucyIsIk9iamVjdCIsImtleXMiLCJzdGF0dXNPcHRpb25zIiwiaGFuZGxlVGFza0Zvcm1DaGFuZ2UiLCJmaWVsZCIsImUiLCJ2YWx1ZSIsInRhcmdldCIsInByZXYiLCJ1bmRlZmluZWQiLCJleHRyYWN0ZWQiLCJ2YWxpZGF0ZVRhc2tGb3JtIiwiZXJycyIsInNvbWUiLCJ0IiwiY2xpY2t1cF90YXNrX2lkIiwiaGFuZGxlQWRkVGFzayIsImxlbmd0aCIsInVpZCIsImNsaWNrdXBfdXJsIiwiaGFuZGxlUmVtb3ZlVGFzayIsImZpbHRlciIsImhhbmRsZVNhdmUiLCJwYXlsb2FkIiwiZW1wbG95ZWVfaWQiLCJOdW1iZXIiLCJtYXAiLCJlbXAiLCJsYWJlbCIsInAiLCJ0YXNrIiwiaW5kZXgiLCJpIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU3VibWl0UGFnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQge1xyXG4gIEJhZGdlLFxyXG4gIEJ1dHRvbixcclxuICBEYXRlUGlja2VyLFxyXG4gIEVtcHR5U3RhdGUsXHJcbiAgSW5wdXQsXHJcbiAgTG9hZGluZyxcclxuICBNb2RhbCxcclxuICBTZWxlY3QsXHJcbiAgVGFibGUsXHJcbiAgVEJvZHksXHJcbiAgVGQsXHJcbiAgVGgsXHJcbiAgVEhlYWQsXHJcbiAgVHIsXHJcbiAgdXNlVG9hc3QsXHJcbn0gZnJvbSAnLi4vY29tcG9uZW50cy91aSc7XHJcbmltcG9ydCB7XHJcbiAgZ2V0RW1wbG95ZWVzLFxyXG4gIGdldFBoYXNlcyxcclxuICBzYXZlTHNwcHQsXHJcbiAgY3JlYXRlRW1wbG95ZWUsXHJcbiAgdXBkYXRlRW1wbG95ZWUsXHJcbiAgZGVsZXRlRW1wbG95ZWUsXHJcbiAgZ2V0RW1wbG95ZWVUYXNrQ291bnQsXHJcbn0gZnJvbSAnLi4vYXBpL2xzcHB0LmpzJztcclxuXHJcbmNvbnN0IENMSUNLVVBfSURfUEFUVEVSTiA9IC9cXC8oW2EtejAtOV0rKVxcLz8kL2k7XHJcblxyXG5jb25zdCBFTVBUWV9UQVNLX0ZPUk0gPSB7XHJcbiAgdGl0bGU6ICcnLFxyXG4gIGNsaWNrdXBVcmw6ICcnLFxyXG4gIGNsaWNrdXBUYXNrSWQ6ICcnLFxyXG4gIHBoYXNlOiAnJyxcclxuICBzdGF0dXM6ICcnLFxyXG59O1xyXG5cclxubGV0IHRhc2tTZXEgPSAwO1xyXG5cclxuZnVuY3Rpb24gZXh0cmFjdENsaWNrVXBJZCh1cmwpIHtcclxuICBjb25zdCBtYXRjaCA9IHVybC5tYXRjaChDTElDS1VQX0lEX1BBVFRFUk4pO1xyXG4gIHJldHVybiBtYXRjaCA/IG1hdGNoWzFdIDogbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gc3RhdHVzQmFkZ2VWYXJpYW50KHN0YXR1cykge1xyXG4gIGNvbnN0IHMgPSBzdGF0dXMudG9Mb3dlckNhc2UoKTtcclxuICBpZiAocy5zdGFydHNXaXRoKCdjb21wbGV0ZWQnKSkgcmV0dXJuICdzdWNjZXNzJztcclxuICBpZiAocy5pbmNsdWRlcygncHJvZ3Jlc3MnKSB8fCBzLmluY2x1ZGVzKCd0ZXN0aW5nJykgfHwgcy5pbmNsdWRlcygnZG9jdW1lbnRhdGlvbicpKSByZXR1cm4gJ2luZm8nO1xyXG4gIGlmIChzLmluY2x1ZGVzKCdob2xkJykgfHwgcy5pbmNsdWRlcygnZmVlZGJhY2snKSkgcmV0dXJuICd3YXJuaW5nJztcclxuICByZXR1cm4gJ25ldXRyYWwnO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTdWJtaXRQYWdlKCkge1xyXG4gIGNvbnN0IHsgc2hvd1RvYXN0IH0gPSB1c2VUb2FzdCgpO1xyXG5cclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwaGFzZXMsIHNldFBoYXNlc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW21ldGFMb2FkaW5nLCBzZXRNZXRhTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuXHJcbiAgY29uc3QgW2VtcGxveWVlSWQsIHNldEVtcGxveWVlSWRdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtkYXRlLCBzZXREYXRlXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbZm9ybUVycm9ycywgc2V0Rm9ybUVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcblxyXG4gIGNvbnN0IFt0YXNrRm9ybSwgc2V0VGFza0Zvcm1dID0gdXNlU3RhdGUoRU1QVFlfVEFTS19GT1JNKTtcclxuICBjb25zdCBbcm93RXJyb3JzLCBzZXRSb3dFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFt0YXNrcywgc2V0VGFza3NdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFtlbXBNb2RhbE9wZW4sIHNldEVtcE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2VtcFZpZXcsIHNldEVtcFZpZXddID0gdXNlU3RhdGUoJ2xpc3QnKTtcclxuICBjb25zdCBbZW1wRWRpdElkLCBzZXRFbXBFZGl0SWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2VtcE5hbWUsIHNldEVtcE5hbWVdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtlbXBTYXZpbmcsIHNldEVtcFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFtkZWxldGVDb25maXJtT3Blbiwgc2V0RGVsZXRlQ29uZmlybU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtkZWxldGVUYXJnZXQsIHNldERlbGV0ZVRhcmdldF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZGVsZXRlVGFza0NvdW50LCBzZXREZWxldGVUYXNrQ291bnRdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2RlbGV0ZUxvYWRpbmcsIHNldERlbGV0ZUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xyXG4gICAgUHJvbWlzZS5hbGwoW2dldEVtcGxveWVlcygpLCBnZXRQaGFzZXMoKV0pXHJcbiAgICAgIC50aGVuKChbZW1wUmVzLCBwaGFzZVJlc10pID0+IHtcclxuICAgICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm47XHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKGVtcFJlcy5kYXRhKTtcclxuICAgICAgICBzZXRQaGFzZXMocGhhc2VSZXMuZGF0YSk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuO1xyXG4gICAgICAgIHNob3dUb2FzdCh7XHJcbiAgICAgICAgICB0eXBlOiAnZXJyb3InLFxyXG4gICAgICAgICAgdGl0bGU6ICdHYWdhbCBtZW11YXQgZGF0YScsXHJcbiAgICAgICAgICBtZXNzYWdlOiBlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgZXJyLm1lc3NhZ2UsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5maW5hbGx5KCgpID0+IHtcclxuICAgICAgICBpZiAoIWNhbmNlbGxlZCkgc2V0TWV0YUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9KTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNhbmNlbGxlZCA9IHRydWU7XHJcbiAgICB9O1xyXG4gIH0sIFtzaG93VG9hc3RdKTtcclxuXHJcbiAgY29uc3QgbG9hZEVtcGxveWVlcyA9ICgpID0+IHtcclxuICAgIGdldEVtcGxveWVlcygpXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHNldEVtcGxveWVlcyhyZXMuZGF0YSkpXHJcbiAgICAgIC5jYXRjaCgoKSA9PiB7fSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3BlbkVtcE1vZGFsID0gKCkgPT4ge1xyXG4gICAgc2V0RW1wVmlldygnbGlzdCcpO1xyXG4gICAgc2V0RW1wRWRpdElkKG51bGwpO1xyXG4gICAgc2V0RW1wTmFtZSgnJyk7XHJcbiAgICBzZXRFbXBNb2RhbE9wZW4odHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRW1wQ3JlYXRlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFlbXBOYW1lLnRyaW0oKSkgcmV0dXJuO1xyXG4gICAgc2V0RW1wU2F2aW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgY3JlYXRlRW1wbG95ZWUoZW1wTmFtZS50cmltKCkpO1xyXG4gICAgICBzaG93VG9hc3QoeyB0eXBlOiAnc3VjY2VzcycsIHRpdGxlOiAnQmVyaGFzaWwnLCBtZXNzYWdlOiAnS2FyeWF3YW4gZGl0YW1iYWhrYW4nIH0pO1xyXG4gICAgICBsb2FkRW1wbG95ZWVzKCk7XHJcbiAgICAgIHNldEVtcFZpZXcoJ2xpc3QnKTtcclxuICAgICAgc2V0RW1wTmFtZSgnJyk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2hvd1RvYXN0KHsgdHlwZTogJ2Vycm9yJywgdGl0bGU6ICdHYWdhbCcsIG1lc3NhZ2U6IGVyci5tZXNzYWdlIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0RW1wU2F2aW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFbXBVcGRhdGUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWVtcE5hbWUudHJpbSgpIHx8ICFlbXBFZGl0SWQpIHJldHVybjtcclxuICAgIHNldEVtcFNhdmluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IHVwZGF0ZUVtcGxveWVlKGVtcEVkaXRJZCwgZW1wTmFtZS50cmltKCkpO1xyXG4gICAgICBzaG93VG9hc3QoeyB0eXBlOiAnc3VjY2VzcycsIHRpdGxlOiAnQmVyaGFzaWwnLCBtZXNzYWdlOiAnS2FyeWF3YW4gZGlwZXJiYXJ1aScgfSk7XHJcbiAgICAgIGxvYWRFbXBsb3llZXMoKTtcclxuICAgICAgc2V0RW1wVmlldygnbGlzdCcpO1xyXG4gICAgICBzZXRFbXBFZGl0SWQobnVsbCk7XHJcbiAgICAgIHNldEVtcE5hbWUoJycpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNob3dUb2FzdCh7IHR5cGU6ICdlcnJvcicsIHRpdGxlOiAnR2FnYWwnLCBtZXNzYWdlOiBlcnIubWVzc2FnZSB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldEVtcFNhdmluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRW1wRGVsZXRlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFlbXBFZGl0SWQpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGdldEVtcGxveWVlVGFza0NvdW50KGVtcEVkaXRJZCk7XHJcbiAgICAgIHNldERlbGV0ZVRhcmdldCh7IGlkOiBlbXBFZGl0SWQsIG5hbWU6IGVtcE5hbWUgfSk7XHJcbiAgICAgIHNldERlbGV0ZVRhc2tDb3VudChyZXMuY291bnQpO1xyXG4gICAgICBzZXREZWxldGVDb25maXJtT3Blbih0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzaG93VG9hc3QoeyB0eXBlOiAnZXJyb3InLCB0aXRsZTogJ0dhZ2FsJywgbWVzc2FnZTogZXJyLm1lc3NhZ2UgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29uZmlybURlbGV0ZSA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghZGVsZXRlVGFyZ2V0KSByZXR1cm47XHJcbiAgICBzZXREZWxldGVMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgZGVsZXRlRW1wbG95ZWUoZGVsZXRlVGFyZ2V0LmlkKTtcclxuICAgICAgc2hvd1RvYXN0KHsgdHlwZTogJ3N1Y2Nlc3MnLCB0aXRsZTogJ0Jlcmhhc2lsJywgbWVzc2FnZTogJ0thcnlhd2FuIGRpaGFwdXMnIH0pO1xyXG4gICAgICBsb2FkRW1wbG95ZWVzKCk7XHJcbiAgICAgIHNldEVtcFZpZXcoJ2xpc3QnKTtcclxuICAgICAgc2V0RW1wRWRpdElkKG51bGwpO1xyXG4gICAgICBzZXRFbXBOYW1lKCcnKTtcclxuICAgICAgc2V0RGVsZXRlQ29uZmlybU9wZW4oZmFsc2UpO1xyXG4gICAgICBzZXREZWxldGVUYXJnZXQobnVsbCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2hvd1RvYXN0KHsgdHlwZTogJ2Vycm9yJywgdGl0bGU6ICdHYWdhbCBtZW5naGFwdXMnLCBtZXNzYWdlOiBlcnIubWVzc2FnZSB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldERlbGV0ZUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHBoYXNlT3B0aW9ucyA9IE9iamVjdC5rZXlzKHBoYXNlcyk7XHJcbiAgY29uc3Qgc3RhdHVzT3B0aW9ucyA9IHRhc2tGb3JtLnBoYXNlID8gcGhhc2VzW3Rhc2tGb3JtLnBoYXNlXSA/PyBbXSA6IFtdO1xyXG5cclxuICBjb25zdCBoYW5kbGVUYXNrRm9ybUNoYW5nZSA9IChmaWVsZCkgPT4gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG5cclxuICAgIGlmIChmaWVsZCA9PT0gJ3BoYXNlJykge1xyXG4gICAgICBzZXRUYXNrRm9ybSgocHJldikgPT4gKHsgLi4ucHJldiwgcGhhc2U6IHZhbHVlLCBzdGF0dXM6ICcnIH0pKTtcclxuICAgICAgc2V0Um93RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBwaGFzZTogdW5kZWZpbmVkLCBzdGF0dXM6IHVuZGVmaW5lZCB9KSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoZmllbGQgPT09ICdjbGlja3VwVXJsJykge1xyXG4gICAgICBjb25zdCBleHRyYWN0ZWQgPSBleHRyYWN0Q2xpY2tVcElkKHZhbHVlKTtcclxuICAgICAgc2V0VGFza0Zvcm0oKHByZXYpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICBjbGlja3VwVXJsOiB2YWx1ZSxcclxuICAgICAgICAuLi4oZXh0cmFjdGVkID8geyBjbGlja3VwVGFza0lkOiBleHRyYWN0ZWQgfSA6IHt9KSxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRSb3dFcnJvcnMoKHByZXYpID0+XHJcbiAgICAgICAgZXh0cmFjdGVkXHJcbiAgICAgICAgICA/IHsgLi4ucHJldiwgY2xpY2t1cFVybDogdW5kZWZpbmVkLCBjbGlja3VwVGFza0lkOiB1bmRlZmluZWQgfVxyXG4gICAgICAgICAgOiB7IC4uLnByZXYsIGNsaWNrdXBVcmw6IHVuZGVmaW5lZCB9XHJcbiAgICAgICk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRUYXNrRm9ybSgocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfSkpO1xyXG4gICAgc2V0Um93RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiB1bmRlZmluZWQgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlVGFza0Zvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBlcnJzID0ge307XHJcbiAgICBpZiAoIWVtcGxveWVlSWQpIGVycnMuZW1wbG95ZWVJZCA9ICdQaWxpaCBrYXJ5YXdhbic7XHJcbiAgICBpZiAoIWRhdGUpIGVycnMuZGF0ZSA9ICdQaWxpaCB0YW5nZ2FsJztcclxuICAgIGlmICghdGFza0Zvcm0udGl0bGUudHJpbSgpKSBlcnJzLnRpdGxlID0gJ0p1ZHVsIHR1Z2FzIHdhamliIGRpaXNpJztcclxuXHJcbiAgICBpZiAoIXRhc2tGb3JtLmNsaWNrdXBVcmwudHJpbSgpKSBlcnJzLmNsaWNrdXBVcmwgPSAnQ2xpY2tVcCBVUkwgd2FqaWIgZGlpc2knO1xyXG4gICAgZWxzZSBpZiAoIWV4dHJhY3RDbGlja1VwSWQodGFza0Zvcm0uY2xpY2t1cFVybC50cmltKCkpKVxyXG4gICAgICBlcnJzLmNsaWNrdXBVcmwgPSAnRm9ybWF0IFVSTCB0aWRhayB2YWxpZCAoY29udG9oOiBodHRwczovL2FwcC5jbGlja3VwLmNvbS90LzkwMDMwMDY3MjMvODZkNDFjOHVyKSc7XHJcblxyXG4gICAgaWYgKCF0YXNrRm9ybS5jbGlja3VwVGFza0lkLnRyaW0oKSkgZXJycy5jbGlja3VwVGFza0lkID0gJ0NsaWNrVXAgVGFzayBJRCB3YWppYiBkaWlzaSc7XHJcbiAgICBlbHNlIGlmIChcclxuICAgICAgdGFza3Muc29tZShcclxuICAgICAgICAodCkgPT4gdC5jbGlja3VwX3Rhc2tfaWQudG9Mb3dlckNhc2UoKSA9PT0gdGFza0Zvcm0uY2xpY2t1cFRhc2tJZC50cmltKCkudG9Mb3dlckNhc2UoKVxyXG4gICAgICApXHJcbiAgICApXHJcbiAgICAgIGVycnMuY2xpY2t1cFRhc2tJZCA9ICdUYXNrIElEIHN1ZGFoIGFkYSBkaSBkYWZ0YXInO1xyXG5cclxuICAgIGlmICghdGFza0Zvcm0ucGhhc2UpIGVycnMucGhhc2UgPSAnUGlsaWggcGhhc2UnO1xyXG4gICAgaWYgKCF0YXNrRm9ybS5zdGF0dXMpIGVycnMuc3RhdHVzID0gJ1BpbGloIHN0YXR1cyc7XHJcblxyXG4gICAgcmV0dXJuIGVycnM7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQWRkVGFzayA9ICgpID0+IHtcclxuICAgIGNvbnN0IGVycnMgPSB2YWxpZGF0ZVRhc2tGb3JtKCk7XHJcbiAgICBzZXRSb3dFcnJvcnMoZXJycyk7XHJcbiAgICBzZXRGb3JtRXJyb3JzKHsgZW1wbG95ZWVJZDogZXJycy5lbXBsb3llZUlkLCBkYXRlOiBlcnJzLmRhdGUgfSk7XHJcbiAgICBpZiAoT2JqZWN0LmtleXMoZXJycykubGVuZ3RoID4gMCkgcmV0dXJuO1xyXG5cclxuICAgIHNldFRhc2tzKChwcmV2KSA9PiBbXHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIHtcclxuICAgICAgICB1aWQ6ICsrdGFza1NlcSxcclxuICAgICAgICB0aXRsZTogdGFza0Zvcm0udGl0bGUudHJpbSgpLFxyXG4gICAgICAgIGNsaWNrdXBfdXJsOiB0YXNrRm9ybS5jbGlja3VwVXJsLnRyaW0oKSxcclxuICAgICAgICBjbGlja3VwX3Rhc2tfaWQ6IHRhc2tGb3JtLmNsaWNrdXBUYXNrSWQudHJpbSgpLFxyXG4gICAgICAgIHBoYXNlOiB0YXNrRm9ybS5waGFzZSxcclxuICAgICAgICBzdGF0dXM6IHRhc2tGb3JtLnN0YXR1cyxcclxuICAgICAgfSxcclxuICAgIF0pO1xyXG4gICAgc2V0VGFza0Zvcm0oRU1QVFlfVEFTS19GT1JNKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVSZW1vdmVUYXNrID0gKHVpZCkgPT4ge1xyXG4gICAgc2V0VGFza3MoKHByZXYpID0+IHByZXYuZmlsdGVyKCh0KSA9PiB0LnVpZCAhPT0gdWlkKSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IGVycnMgPSB7fTtcclxuICAgIGlmICghZW1wbG95ZWVJZCkgZXJycy5lbXBsb3llZUlkID0gJ1BpbGloIGthcnlhd2FuJztcclxuICAgIGlmICghZGF0ZSkgZXJycy5kYXRlID0gJ1BpbGloIHRhbmdnYWwnO1xyXG4gICAgaWYgKHRhc2tzLmxlbmd0aCA9PT0gMCkgZXJycy50YXNrcyA9ICdUYW1iYWhrYW4gbWluaW1hbCBzYXR1IHRhc2sgc2ViZWx1bSBtZW55aW1wYW4nO1xyXG4gICAgc2V0Rm9ybUVycm9ycyhlcnJzKTtcclxuXHJcbiAgICBpZiAoT2JqZWN0LmtleXMoZXJycykubGVuZ3RoID4gMCkge1xyXG4gICAgICBzaG93VG9hc3Qoe1xyXG4gICAgICAgIHR5cGU6ICdlcnJvcicsXHJcbiAgICAgICAgdGl0bGU6ICdGb3JtIGJlbHVtIGxlbmdrYXAnLFxyXG4gICAgICAgIG1lc3NhZ2U6ICdMZW5na2FwaSBrYXJ5YXdhbiwgdGFuZ2dhbCwgZGFuIHRhbWJhaGthbiBtaW5pbWFsIHNhdHUgdGFzay4nLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgIGVtcGxveWVlX2lkOiBOdW1iZXIoZW1wbG95ZWVJZCksXHJcbiAgICAgIGRhdGUsXHJcbiAgICAgIHRhc2tzOiB0YXNrcy5tYXAoKHsgdGl0bGUsIGNsaWNrdXBfdXJsLCBjbGlja3VwX3Rhc2tfaWQsIHBoYXNlLCBzdGF0dXMgfSkgPT4gKHtcclxuICAgICAgICB0aXRsZSxcclxuICAgICAgICBjbGlja3VwX3VybCxcclxuICAgICAgICBjbGlja3VwX3Rhc2tfaWQsXHJcbiAgICAgICAgcGhhc2UsXHJcbiAgICAgICAgc3RhdHVzLFxyXG4gICAgICB9KSksXHJcbiAgICB9O1xyXG5cclxuICAgIHNldFNhdmluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHNhdmVMc3BwdChwYXlsb2FkKTtcclxuICAgICAgc2hvd1RvYXN0KHtcclxuICAgICAgICB0eXBlOiAnc3VjY2VzcycsXHJcbiAgICAgICAgdGl0bGU6ICdCZXJoYXNpbCcsXHJcbiAgICAgICAgbWVzc2FnZTogcmVzLm1lc3NhZ2UgfHwgJ0xTUFBUIHNhdmVkIHN1Y2Nlc3NmdWxseScsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRUYXNrcyhbXSk7XHJcbiAgICAgIHNldFRhc2tGb3JtKEVNUFRZX1RBU0tfRk9STSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc3QgbWVzc2FnZSA9IGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBlcnIubWVzc2FnZTtcclxuICAgICAgc2hvd1RvYXN0KHtcclxuICAgICAgICB0eXBlOiAnZXJyb3InLFxyXG4gICAgICAgIHRpdGxlOiBlcnIuc3RhdHVzID09PSA0MDkgPyAnVGFzayBkdXBsaWthdCcgOiAnR2FnYWwgbWVueWltcGFuIExTUFBUJyxcclxuICAgICAgICBtZXNzYWdlLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFNhdmluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgaWYgKG1ldGFMb2FkaW5nKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1zbGF0ZS01MFwiPlxyXG4gICAgICAgIDxMb2FkaW5nIHNpemU9XCJsZ1wiIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS01MCBwLThcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTd4bCBzcGFjZS15LTZcIj5cclxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPkxTUFBUIFRyYWNrZXI8L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICBMYXBvcmFuIFN0YXR1cyBQcm9ncmVzcyBQZWtlcmphYW4gS2FyeWF3YW5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICB0bz1cIi9oaXN0b3J5XCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWJsdWUtNjAwIGhvdmVyOnRleHQtYmx1ZS03MDAgaG92ZXI6dW5kZXJsaW5lXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgTGloYXQgSGlzdG9yeSDihpJcclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1zbGF0ZS02MDBcIj5cclxuICAgICAgICAgICAgSW5mb3JtYXNpIFVtdW1cclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTQgbWQ6Z3JpZC1jb2xzLTJcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUGlsaWgga2FyeWF3YW5cIlxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoeyB2YWx1ZTogZW1wLmlkLCBsYWJlbDogZW1wLm5hbWUgfSkpfVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2VtcGxveWVlSWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVtcGxveWVlSWQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgZXJyb3I9e2Zvcm1FcnJvcnMuZW1wbG95ZWVJZH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17b3BlbkVtcE1vZGFsfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtYmx1ZS02MDAgaG92ZXI6dW5kZXJsaW5lXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICDimpkgS2Vsb2xhIEthcnlhd2FuXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiVGFuZ2dhbFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2RhdGV9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7IHNldERhdGUoZS50YXJnZXQudmFsdWUpOyBzZXRGb3JtRXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBkYXRlOiB1bmRlZmluZWQgfSkpOyB9fVxyXG4gICAgICAgICAgICAgIGVycm9yPXtmb3JtRXJyb3JzLmRhdGV9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1zbSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtc2xhdGUtNjAwXCI+XHJcbiAgICAgICAgICAgIFRhbWJhaCBUYXNrXHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC00IG1kOmdyaWQtY29scy0yXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJUYXNrIFRpdGxlXCJcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ29udG9oOiBDVE1TIC0gSXNzdWUgTGlzdCBSZXBvcnRcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3Rhc2tGb3JtLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVRhc2tGb3JtQ2hhbmdlKCd0aXRsZScpfVxyXG4gICAgICAgICAgICAgICAgZXJyb3I9e3Jvd0Vycm9ycy50aXRsZX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJDbGlja1VwIFVSTFwiXHJcbiAgICAgICAgICAgICAgdHlwZT1cInVybFwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL2FwcC5jbGlja3VwLmNvbS90LzkwMDMwMDY3MjMvODZkNDFjOHVyXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17dGFza0Zvcm0uY2xpY2t1cFVybH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVGFza0Zvcm1DaGFuZ2UoJ2NsaWNrdXBVcmwnKX1cclxuICAgICAgICAgICAgICBlcnJvcj17cm93RXJyb3JzLmNsaWNrdXBVcmx9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiQ2xpY2tVcCBUYXNrIElEXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk90b21hdGlzIHRlcmlzaSBkYXJpIFVSTFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3Rhc2tGb3JtLmNsaWNrdXBUYXNrSWR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVRhc2tGb3JtQ2hhbmdlKCdjbGlja3VwVGFza0lkJyl9XHJcbiAgICAgICAgICAgICAgZXJyb3I9e3Jvd0Vycm9ycy5jbGlja3VwVGFza0lkfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJQaGFzZVwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQaWxpaCBwaGFzZVwiXHJcbiAgICAgICAgICAgICAgb3B0aW9ucz17cGhhc2VPcHRpb25zLm1hcCgocCkgPT4gKHsgdmFsdWU6IHAsIGxhYmVsOiBwIH0pKX1cclxuICAgICAgICAgICAgICB2YWx1ZT17dGFza0Zvcm0ucGhhc2V9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVRhc2tGb3JtQ2hhbmdlKCdwaGFzZScpfVxyXG4gICAgICAgICAgICAgIGVycm9yPXtyb3dFcnJvcnMucGhhc2V9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICBsYWJlbD1cIlN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3Rhc2tGb3JtLnBoYXNlID8gJ1BpbGloIHN0YXR1cycgOiAnUGlsaWggcGhhc2UgdGVybGViaWggZGFodWx1J31cclxuICAgICAgICAgICAgICBvcHRpb25zPXtzdGF0dXNPcHRpb25zLm1hcCgocykgPT4gKHsgdmFsdWU6IHMsIGxhYmVsOiBzIH0pKX1cclxuICAgICAgICAgICAgICB2YWx1ZT17dGFza0Zvcm0uc3RhdHVzfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVUYXNrRm9ybUNoYW5nZSgnc3RhdHVzJyl9XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9eyF0YXNrRm9ybS5waGFzZX1cclxuICAgICAgICAgICAgICBlcnJvcj17cm93RXJyb3JzLnN0YXR1c31cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17aGFuZGxlQWRkVGFza30+XHJcbiAgICAgICAgICAgICAgKyBBZGQgVGFza1xyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSBzaGFkb3ctc21cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTUgcHQtNSBwYi0zXCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1zbGF0ZS02MDBcIj5cclxuICAgICAgICAgICAgICBEYWZ0YXIgVGFzayAoe3Rhc2tzLmxlbmd0aH0pXHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgIHtmb3JtRXJyb3JzLnRhc2tzICYmIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1yZWQtNjAwXCI+e2Zvcm1FcnJvcnMudGFza3N9PC9wPn1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHt0YXNrcy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBwYi01XCI+XHJcbiAgICAgICAgICAgICAgPEVtcHR5U3RhdGVcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiQmVsdW0gYWRhIHRhc2tcIlxyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb249XCJJc2kgZm9ybSBkaSBhdGFzIGxhbHUga2xpayDigJwrIEFkZCBUYXNr4oCdIHVudHVrIG1lbmFtYmFoa2FuIHRhc2sga2UgZGFmdGFyLlwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItMCBweS04XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxUYWJsZT5cclxuICAgICAgICAgICAgICA8VEhlYWQ+XHJcbiAgICAgICAgICAgICAgICA8VHI+XHJcbiAgICAgICAgICAgICAgICAgIDxUaCBjbGFzc05hbWU9XCJ3LTEyXCI+Tm88L1RoPlxyXG4gICAgICAgICAgICAgICAgICA8VGg+VGFzazwvVGg+XHJcbiAgICAgICAgICAgICAgICAgIDxUaD5DbGlja1VwIElEPC9UaD5cclxuICAgICAgICAgICAgICAgICAgPFRoPlBoYXNlPC9UaD5cclxuICAgICAgICAgICAgICAgICAgPFRoPlN0YXR1czwvVGg+XHJcbiAgICAgICAgICAgICAgICAgIDxUaCBjbGFzc05hbWU9XCJ3LTI0IHRleHQtcmlnaHRcIj5Ba3NpPC9UaD5cclxuICAgICAgICAgICAgICAgIDwvVHI+XHJcbiAgICAgICAgICAgICAgPC9USGVhZD5cclxuICAgICAgICAgICAgICA8VEJvZHk+XHJcbiAgICAgICAgICAgICAgICB7dGFza3MubWFwKCh0YXNrLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8VHIga2V5PXt0YXNrLnVpZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRkPntpbmRleCArIDF9PC9UZD5cclxuICAgICAgICAgICAgICAgICAgICA8VGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMFwiPnt0YXNrLnRpdGxlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e3Rhc2suY2xpY2t1cF91cmx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vcmVmZXJyZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtYmx1ZS02MDAgaG92ZXI6dW5kZXJsaW5lXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Rhc2suY2xpY2t1cF91cmx9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9UZD5cclxuICAgICAgICAgICAgICAgICAgICA8VGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Y29kZSBjbGFzc05hbWU9XCJyb3VuZGVkIGJnLXNsYXRlLTEwMCBweC0xLjUgcHktMC41IHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Rhc2suY2xpY2t1cF90YXNrX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9jb2RlPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRkPnt0YXNrLnBoYXNlfTwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9e3N0YXR1c0JhZGdlVmFyaWFudCh0YXNrLnN0YXR1cyl9Pnt0YXNrLnN0YXR1c308L0JhZGdlPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRkIGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlVGFzayh0YXNrLnVpZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEhhcHVzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L1RkPlxyXG4gICAgICAgICAgICAgICAgICA8L1RyPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9UQm9keT5cclxuICAgICAgICAgICAgPC9UYWJsZT5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBweC01IHB5LTRcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICAgIHt0YXNrcy5sZW5ndGggPiAwXHJcbiAgICAgICAgICAgICAgICA/IGAke3Rhc2tzLmxlbmd0aH0gdGFzayBzaWFwIGRpc2ltcGFuIHVudHVrICR7ZGF0ZSB8fCAndGFuZ2dhbCB0ZXJwaWxpaCd9YFxyXG4gICAgICAgICAgICAgICAgOiAnQmVsdW0gYWRhIHRhc2sgeWFuZyBkaXRhbWJhaGthbi4nfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIHNpemU9XCJsZ1wiIGxvYWRpbmc9e3NhdmluZ30gb25DbGljaz17aGFuZGxlU2F2ZX0+XHJcbiAgICAgICAgICAgICAgU2F2ZSBMU1BQVFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICBvcGVuPXtlbXBNb2RhbE9wZW59XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0RW1wTW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICBlbXBWaWV3ID09PSAnbGlzdCdcclxuICAgICAgICAgICAgPyAnS2Vsb2xhIEthcnlhd2FuJ1xyXG4gICAgICAgICAgICA6IGVtcFZpZXcgPT09ICdhZGQnXHJcbiAgICAgICAgICAgICAgPyAnVGFtYmFoIEthcnlhd2FuJ1xyXG4gICAgICAgICAgICAgIDogJ0VkaXQgS2FyeWF3YW4nXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgZm9vdGVyPXtcclxuICAgICAgICAgIGVtcFZpZXcgPT09ICdsaXN0JyA/IChcclxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXRFbXBWaWV3KCdhZGQnKTsgc2V0RW1wTmFtZSgnJyk7IH19PlxyXG4gICAgICAgICAgICAgICsgVGFtYmFoIEthcnlhd2FuXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICB7ZW1wVmlldyA9PT0gJ2VkaXQnICYmIChcclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJkYW5nZXJcIlxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtlbXBTYXZpbmd9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUVtcERlbGV0ZX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgSGFwdXMgS2FyeWF3YW5cclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFbXBWaWV3KCdsaXN0Jyl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQmF0YWxcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIGxvYWRpbmc9e2VtcFNhdmluZ31cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2VtcFZpZXcgPT09ICdhZGQnID8gaGFuZGxlRW1wQ3JlYXRlIDogaGFuZGxlRW1wVXBkYXRlfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFNpbXBhblxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgIClcclxuICAgICAgICB9XHJcbiAgICAgID5cclxuICAgICAgICB7ZW1wVmlldyA9PT0gJ2xpc3QnID8gKFxyXG4gICAgICAgICAgPFRhYmxlPlxyXG4gICAgICAgICAgICA8VEhlYWQ+XHJcbiAgICAgICAgICAgICAgPFRyPlxyXG4gICAgICAgICAgICAgICAgPFRoIGNsYXNzTmFtZT1cInctMTBcIj4jPC9UaD5cclxuICAgICAgICAgICAgICAgIDxUaD5OYW1hPC9UaD5cclxuICAgICAgICAgICAgICAgIDxUaCBjbGFzc05hbWU9XCJ3LTIwXCI+PC9UaD5cclxuICAgICAgICAgICAgICA8L1RyPlxyXG4gICAgICAgICAgICA8L1RIZWFkPlxyXG4gICAgICAgICAgICA8VEJvZHk+XHJcbiAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPFRyIGtleT17ZW1wLmlkfT5cclxuICAgICAgICAgICAgICAgICAgPFRkPntpICsgMX08L1RkPlxyXG4gICAgICAgICAgICAgICAgICA8VGQ+e2VtcC5uYW1lfTwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgIDxUZD5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVtcFZpZXcoJ2VkaXQnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RW1wRWRpdElkKGVtcC5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVtcE5hbWUoZW1wLm5hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvVGQ+XHJcbiAgICAgICAgICAgICAgICA8L1RyPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L1RCb2R5PlxyXG4gICAgICAgICAgPC9UYWJsZT5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgIGxhYmVsPVwiTmFtYSBLYXJ5YXdhblwiXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTWFzdWtrYW4gbmFtYVwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtlbXBOYW1lfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVtcE5hbWUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG4gICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgb3Blbj17ZGVsZXRlQ29uZmlybU9wZW59XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4geyBzZXREZWxldGVDb25maXJtT3BlbihmYWxzZSk7IHNldERlbGV0ZVRhcmdldChudWxsKTsgfX1cclxuICAgICAgICB0aXRsZT1cIkhhcHVzIEthcnlhd2FuXCJcclxuICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgIGZvb3Rlcj17XHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17KCkgPT4geyBzZXREZWxldGVDb25maXJtT3BlbihmYWxzZSk7IHNldERlbGV0ZVRhcmdldChudWxsKTsgfX0+XHJcbiAgICAgICAgICAgICAgQmF0YWxcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImRhbmdlclwiIGxvYWRpbmc9e2RlbGV0ZUxvYWRpbmd9IG9uQ2xpY2s9e2hhbmRsZUNvbmZpcm1EZWxldGV9PlxyXG4gICAgICAgICAgICAgIEhhcHVzXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgfVxyXG4gICAgICA+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAgWWFraW4gaW5naW4gbWVuZ2hhcHVzIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57ZGVsZXRlVGFyZ2V0Py5uYW1lfTwvc3Bhbj4/XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIHtkZWxldGVUYXNrQ291bnQgPiAwICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgcm91bmRlZC1tZCBiZy1yZWQtNTAgcC0zIHRleHQtc20gdGV4dC1yZWQtNzAwXCI+XHJcbiAgICAgICAgICAgIEthcnlhd2FuIGluaSBtZW1pbGlraSA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e2RlbGV0ZVRhc2tDb3VudH0gdGFzazwvc3Bhbj4uIFNlbXVhIHRhc2sgZGFuIHByb2dyZXNzLW55YSBqdWdhIGFrYW4gZGloYXB1cyBzZWNhcmEgcGVybWFuZW4uXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9Nb2RhbD5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiIvYXBwL3NyYy9wYWdlcy9TdWJtaXRQYWdlLmpzeCJ9