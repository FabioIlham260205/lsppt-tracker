import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/DatePicker.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6eb1056b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/DatePicker.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6eb1056b"; const useId = __vite__cjsImport3_react["useId"];
import Input from "/src/components/ui/Input.jsx";
export default function DatePicker({ label, error, className = "", ...props }) {
  return /* @__PURE__ */ jsxDEV(
    Input,
    {
      type: "date",
      label,
      error,
      className: `[color-scheme:light] ${className}`,
      ...props
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/ui/DatePicker.jsx",
      lineNumber: 25,
      columnNumber: 5
    },
    this
  );
}
_c = DatePicker;
var _c;
$RefreshReg$(_c, "DatePicker");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/DatePicker.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/DatePicker.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFMSixTQUFTQSxhQUFhO0FBQ3RCLE9BQU9DLFdBQVc7QUFFbEIsd0JBQXdCQyxXQUFXLEVBQUVDLE9BQU9DLE9BQU9DLFlBQVksSUFBSSxHQUFHQyxNQUFNLEdBQUc7QUFDN0UsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsTUFBSztBQUFBLE1BQ0w7QUFBQSxNQUNBO0FBQUEsTUFDQSxXQUFXLHdCQUF3QkQsU0FBUztBQUFBLE1BQzVDLEdBQUlDO0FBQUFBO0FBQUFBLElBTE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS1k7QUFHaEI7QUFBQ0MsS0FWdUJMO0FBQVUsSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlSWQiLCJJbnB1dCIsIkRhdGVQaWNrZXIiLCJsYWJlbCIsImVycm9yIiwiY2xhc3NOYW1lIiwicHJvcHMiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJEYXRlUGlja2VyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VJZCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IElucHV0IGZyb20gJy4vSW5wdXQuanN4JztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhdGVQaWNrZXIoeyBsYWJlbCwgZXJyb3IsIGNsYXNzTmFtZSA9ICcnLCAuLi5wcm9wcyB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxJbnB1dFxyXG4gICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgIGxhYmVsPXtsYWJlbH1cclxuICAgICAgZXJyb3I9e2Vycm9yfVxyXG4gICAgICBjbGFzc05hbWU9e2BbY29sb3Itc2NoZW1lOmxpZ2h0XSAke2NsYXNzTmFtZX1gfVxyXG4gICAgICB7Li4ucHJvcHN9XHJcbiAgICAvPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL3VpL0RhdGVQaWNrZXIuanN4In0=