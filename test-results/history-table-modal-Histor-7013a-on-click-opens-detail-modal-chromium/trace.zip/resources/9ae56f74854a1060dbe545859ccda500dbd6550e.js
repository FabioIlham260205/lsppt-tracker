import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Loading.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6eb1056b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/Loading.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const SIZES = {
  sm: "h-4 w-4 border-2",
  md: "h-8 w-8 border-[3px]",
  lg: "h-12 w-12 border-4"
};
export default function Loading({ size = "md", className = "", ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "span",
    {
      role: "status",
      "aria-label": "Loading",
      className: `inline-block animate-spin rounded-full border-slate-300 border-t-blue-600 ${SIZES[size]} ${className}`,
      ...props
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/ui/Loading.jsx",
      lineNumber: 28,
      columnNumber: 5
    },
    this
  );
}
_c = Loading;
var _c;
$RefreshReg$(_c, "Loading");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/Loading.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/Loading.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFSSixNQUFNQSxRQUFRO0FBQUEsRUFDWkMsSUFBSTtBQUFBLEVBQ0pDLElBQUk7QUFBQSxFQUNKQyxJQUFJO0FBQ047QUFFQSx3QkFBd0JDLFFBQVEsRUFBRUMsT0FBTyxNQUFNQyxZQUFZLElBQUksR0FBR0MsTUFBTSxHQUFHO0FBQ3pFLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE1BQUs7QUFBQSxNQUNMLGNBQVc7QUFBQSxNQUNYLFdBQVcsNkVBQTZFUCxNQUFNSyxJQUFJLENBQUMsSUFBSUMsU0FBUztBQUFBLE1BQ2hILEdBQUlDO0FBQUFBO0FBQUFBLElBSk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSVk7QUFHaEI7QUFBQ0MsS0FUdUJKO0FBQU8sSUFBQUk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiU0laRVMiLCJzbSIsIm1kIiwibGciLCJMb2FkaW5nIiwic2l6ZSIsImNsYXNzTmFtZSIsInByb3BzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTG9hZGluZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgU0laRVMgPSB7XHJcbiAgc206ICdoLTQgdy00IGJvcmRlci0yJyxcclxuICBtZDogJ2gtOCB3LTggYm9yZGVyLVszcHhdJyxcclxuICBsZzogJ2gtMTIgdy0xMiBib3JkZXItNCcsXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMb2FkaW5nKHsgc2l6ZSA9ICdtZCcsIGNsYXNzTmFtZSA9ICcnLCAuLi5wcm9wcyB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzcGFuXHJcbiAgICAgIHJvbGU9XCJzdGF0dXNcIlxyXG4gICAgICBhcmlhLWxhYmVsPVwiTG9hZGluZ1wiXHJcbiAgICAgIGNsYXNzTmFtZT17YGlubGluZS1ibG9jayBhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGJvcmRlci1zbGF0ZS0zMDAgYm9yZGVyLXQtYmx1ZS02MDAgJHtTSVpFU1tzaXplXX0gJHtjbGFzc05hbWV9YH1cclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgLz5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy91aS9Mb2FkaW5nLmpzeCJ9