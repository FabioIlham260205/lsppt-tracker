import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/HistoryPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6eb1056b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/pages/HistoryPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6eb1056b"; const Fragment2 = __vite__cjsImport3_react["Fragment"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import {
  Badge,
  Button,
  DatePicker,
  EmptyState,
  Input,
  Loading,
  Modal,
  Select,
  Table,
  TBody,
  Td,
  Th,
  THead,
  Tr,
  useToast
} from "/src/components/ui/index.js";
import { getEmployees, getHistory, getTaskHistory, exportHistory, getPhases, updateTaskProgress } from "/src/api/lsppt.js?t=1787813477375";
const STATUS_VARIANT = {
  Completed: "success",
  "Completed Testing": "success",
  Documentation: "info",
  "In Progress": "info",
  "On Hold": "danger",
  Plan: "neutral",
  "Completed with Feedback": "warning",
  Testing: "warning",
  "On Queue Testing": "warning"
};
const DOT_BORDER = {
  success: "border-green-500",
  info: "border-blue-500",
  warning: "border-amber-500",
  danger: "border-red-500",
  neutral: "border-slate-400"
};
const DOT_FILL = {
  success: "bg-green-500",
  info: "bg-blue-500",
  warning: "bg-amber-500",
  danger: "bg-red-500",
  neutral: "bg-slate-400"
};
const TIME_PERIODS = {
  "minggu-ini": "Minggu Ini",
  "bulan-ini": "Bulan Ini",
  "tahun-ini": "Tahun Ini",
  "semua": "Semua"
};
function toISODate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
function defaultRange() {
  const now = /* @__PURE__ */ new Date();
  return {
    from: toISODate(new Date(now.getFullYear(), now.getMonth(), 1)),
    to: toISODate(now)
  };
}
function getPeriodRange(period) {
  const now = /* @__PURE__ */ new Date();
  switch (period) {
    case "minggu-ini": {
      const dayOfWeek = now.getDay();
      const startOfWeek = new Date(now);
      startOfWeek.setDate(now.getDate() - dayOfWeek);
      return { from: toISODate(startOfWeek), to: toISODate(now) };
    }
    case "bulan-ini":
      return { from: toISODate(new Date(now.getFullYear(), now.getMonth(), 1)), to: toISODate(now) };
    case "tahun-ini":
      return { from: toISODate(new Date(now.getFullYear(), 0, 1)), to: toISODate(now) };
    case "semua":
      return { from: "", to: "" };
    default:
      return defaultRange();
  }
}
const DATE_FMT = new Intl.DateTimeFormat("id-ID", {
  day: "numeric",
  month: "short",
  year: "numeric"
});
function formatDate(iso) {
  if (!iso) return "-";
  return DATE_FMT.format(new Date(iso));
}
function StatusBadge({ status }) {
  return /* @__PURE__ */ jsxDEV(Badge, { variant: STATUS_VARIANT[status] || "neutral", children: status }, void 0, false, {
    fileName: "/app/src/pages/HistoryPage.jsx",
    lineNumber: 122,
    columnNumber: 10
  }, this);
}
_c = StatusBadge;
function TimelineDot({ variant, isLatest }) {
  return /* @__PURE__ */ jsxDEV(
    "span",
    {
      "aria-hidden": "true",
      className: `absolute -left-[9px] top-1 h-4 w-4 rounded-full border-2 bg-white ${DOT_BORDER[variant]} ${isLatest ? DOT_FILL[variant] : ""}`
    },
    void 0,
    false,
    {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 127,
      columnNumber: 5
    },
    this
  );
}
_c2 = TimelineDot;
function DetailModal({ open, onClose, row }) {
  _s();
  const [entries, setEntries] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [phases, setPhases] = useState({});
  const [showUpdate, setShowUpdate] = useState(false);
  const [updatePhase, setUpdatePhase] = useState("");
  const [updateStatus, setUpdateStatus] = useState("");
  const [updateDate, setUpdateDate] = useState("");
  const [updateErrors, setUpdateErrors] = useState({});
  const [updating, setUpdating] = useState(false);
  const { showToast } = useToast();
  function loadHistory() {
    if (!row) return;
    setLoading(true);
    setError(null);
    getTaskHistory(row.task_id).then((res) => setEntries(res.data)).catch((err) => setError(err?.message || "Terjadi kesalahan tak terduga.")).finally(() => setLoading(false));
  }
  useEffect(() => {
    if (!open || !row) return void 0;
    loadHistory();
    setUpdatePhase(row.phase);
    setUpdateStatus(row.status);
    const today = /* @__PURE__ */ new Date();
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, "0");
    const d = String(today.getDate()).padStart(2, "0");
    setUpdateDate(`${y}-${m}-${d}`);
    setShowUpdate(false);
    setUpdateErrors({});
    return () => {
    };
  }, [open, row]);
  useEffect(() => {
    if (!open) return;
    getPhases().then((res) => setPhases(res.data)).catch(() => {
    });
  }, [open]);
  const statusOptions = updatePhase ? phases[updatePhase] ?? [] : [];
  function handlePhaseChange(e) {
    const val = e.target.value;
    setUpdatePhase(val);
    if (val && !phases[val]?.includes(updateStatus)) {
      setUpdateStatus("");
    }
  }
  function handleSubmitUpdate() {
    const errs = {};
    if (!updatePhase) errs.phase = "Pilih phase";
    if (!updateStatus) errs.status = "Pilih status";
    if (!updateDate) errs.date = "Pilih tanggal";
    setUpdateErrors(errs);
    if (Object.keys(errs).length > 0) return;
    setUpdating(true);
    updateTaskProgress(row.task_id, {
      phase: updatePhase,
      status: updateStatus,
      date: updateDate
    }).then(() => {
      showToast({ type: "success", title: "Berhasil", message: "Progress berhasil diperbarui" });
      setShowUpdate(false);
      loadHistory();
    }).catch((err) => {
      showToast({
        type: "error",
        title: "Gagal",
        message: err.status === 409 ? "Progress untuk tanggal ini sudah ada" : err.message || "Terjadi kesalahan"
      });
    }).finally(() => setUpdating(false));
  }
  const lastUpdated = entries?.length ? entries[entries.length - 1].date : null;
  return /* @__PURE__ */ jsxDEV(Modal, { open, onClose, title: row ? row.task : "Detail Task", size: "lg", children: row && /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-5", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-slate-400", children: "Karyawan" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 230,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-0.5 text-sm font-medium text-slate-800", children: row.employee }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 231,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 229,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-slate-400", children: "ClickUp ID" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 234,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-0.5 font-mono text-xs text-slate-700", children: row.clickup_task_id }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 235,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 233,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-slate-400", children: "Phase saat ini" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 238,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm font-medium text-slate-800", children: row.phase }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 239,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 237,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-slate-400", children: "Status saat ini" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 242,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1", children: /* @__PURE__ */ jsxDEV(StatusBadge, { status: row.status }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 244,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 243,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 241,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-slate-400", children: "Last Updated" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 248,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-0.5 text-sm font-medium text-slate-800", children: lastUpdated ? formatDate(lastUpdated) : "-" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 249,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 247,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 228,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-5 border-t border-slate-100 pt-5", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-wider text-slate-400", children: "Riwayat Progress" }, void 0, false, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 256,
        columnNumber: 13
      }, this),
      loading && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-3 py-10", role: "status", "aria-busy": "true", children: [
        /* @__PURE__ */ jsxDEV(Loading, { size: "md" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 262,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500", children: "Memuat riwayat progress…" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 263,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 261,
        columnNumber: 11
      }, this),
      !loading && error && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-3 py-8", role: "alert", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-600", children: error }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 269,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-400", children: "Riwayat progress tidak dapat dimuat." }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 270,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: loadHistory, children: "Coba Lagi" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 273,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 268,
        columnNumber: 11
      }, this),
      !loading && !error && entries && entries.length > 0 && /* @__PURE__ */ jsxDEV("ol", { className: "relative ml-2 mt-4 border-l-2 border-slate-100", "aria-label": "Riwayat progress", children: entries.map((entry, index) => {
        const variant = STATUS_VARIANT[entry.status] || "neutral";
        const isLatest = index === entries.length - 1;
        const prevEntry = index > 0 ? entries[index - 1] : null;
        const phaseChanged = prevEntry && prevEntry.phase !== entry.phase;
        return /* @__PURE__ */ jsxDEV(Fragment2, { children: [
          phaseChanged && /* @__PURE__ */ jsxDEV("li", { className: "relative pb-3 pl-7", "aria-hidden": "true", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "absolute -left-[9px] top-1 h-4 w-4 rounded-full border-2 border-dashed border-slate-300 bg-white" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 290,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-slate-400", children: [
              "Phase: ",
              prevEntry.phase,
              " → ",
              entry.phase
            ] }, void 0, true, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 291,
              columnNumber: 27
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 289,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("li", { className: `relative ${phaseChanged ? "pt-1" : ""} pb-6 pl-7 last:pb-1`, children: [
            /* @__PURE__ */ jsxDEV(TimelineDot, { variant, isLatest }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 297,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `text-sm ${isLatest ? "font-semibold text-slate-800" : "text-slate-600"}`,
                  children: formatDate(entry.date)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/pages/HistoryPage.jsx",
                  lineNumber: 299,
                  columnNumber: 27
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-400", children: entry.phase }, void 0, false, {
                  fileName: "/app/src/pages/HistoryPage.jsx",
                  lineNumber: 307,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(StatusBadge, { status: entry.status }, void 0, false, {
                  fileName: "/app/src/pages/HistoryPage.jsx",
                  lineNumber: 308,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/pages/HistoryPage.jsx",
                lineNumber: 306,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 298,
              columnNumber: 25
            }, this),
            isLatest && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-slate-400", children: "Kondisi terakhir tugas ini." }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 312,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 296,
            columnNumber: 23
          }, this)
        ] }, `${entry.date}-${entry.status}`, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 287,
          columnNumber: 17
        }, this);
      }) }, void 0, false, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 280,
        columnNumber: 11
      }, this),
      !loading && !error && entries && entries.length === 0 && /* @__PURE__ */ jsxDEV("p", { className: "py-6 text-sm text-slate-500", children: "Task ini belum memiliki riwayat progress yang tercatat." }, void 0, false, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 322,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 255,
      columnNumber: 11
    }, this),
    showUpdate && /* @__PURE__ */ jsxDEV("div", { className: "mt-5 rounded-lg border border-blue-200 bg-blue-50 p-4", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "mb-3 text-xs font-semibold uppercase tracking-wider text-blue-600", children: "Update Progress" }, void 0, false, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 328,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 sm:grid-cols-3", children: [
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            label: "Phase",
            placeholder: "Pilih phase",
            options: Object.keys(phases).map((p) => ({ value: p, label: p })),
            value: updatePhase,
            onChange: handlePhaseChange,
            error: updateErrors.phase
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 332,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            label: "Status",
            placeholder: updatePhase ? "Pilih status" : "Pilih phase dulu",
            options: statusOptions.map((s) => ({ value: s, label: s })),
            value: updateStatus,
            onChange: (e) => {
              setUpdateStatus(e.target.value);
              setUpdateErrors((p) => ({ ...p, status: void 0 }));
            },
            disabled: !updatePhase,
            error: updateErrors.status
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 340,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          DatePicker,
          {
            label: "Tanggal",
            value: updateDate,
            onChange: (e) => {
              setUpdateDate(e.target.value);
              setUpdateErrors((p) => ({ ...p, date: void 0 }));
            },
            error: updateErrors.date
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 349,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 331,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex justify-end gap-2", children: [
        /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "outline", size: "sm", onClick: () => setShowUpdate(false), children: "Batal" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 357,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "button", size: "sm", loading: updating, onClick: handleSubmitUpdate, children: "Simpan Progress" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 360,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 356,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 327,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex justify-end gap-2 border-t border-slate-100 pt-4", children: [
      !showUpdate && /* @__PURE__ */ jsxDEV(Button, { variant: "primary", onClick: () => setShowUpdate(true), children: "Update Progress" }, void 0, false, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 369,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: onClose, children: "Tutup" }, void 0, false, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 373,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 367,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/pages/HistoryPage.jsx",
    lineNumber: 227,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/app/src/pages/HistoryPage.jsx",
    lineNumber: 225,
    columnNumber: 5
  }, this);
}
_s(DetailModal, "zXSaioP0TV8nJcN6rchIpC8Xiao=", false, function() {
  return [useToast];
});
_c3 = DetailModal;
export default function HistoryPage() {
  _s2();
  const initialRange = useMemo(defaultRange, []);
  const [employees, setEmployees] = useState([]);
  const [employeeId, setEmployeeId] = useState("");
  const [from, setFrom] = useState(initialRange.from);
  const [to, setTo] = useState(initialRange.to);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [activePeriod, setActivePeriod] = useState("bulan-ini");
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedRow, setSelectedRow] = useState(null);
  const [exporting, setExporting] = useState(false);
  const { showToast } = useToast();
  useEffect(() => {
    let cancelled = false;
    getEmployees().then((res) => {
      if (!cancelled) setEmployees(res.data);
    }).catch(() => {
    });
    return () => {
      cancelled = true;
    };
  }, []);
  function loadHistory() {
    setLoading(true);
    setError(null);
    getHistory({ employee_id: employeeId || void 0, from: from || void 0, to: to || void 0 }).then((res) => setRows(res.data)).catch((err) => setError(err?.message || "Terjadi kesalahan tak terduga.")).finally(() => setLoading(false));
  }
  useEffect(() => {
    loadHistory();
  }, [employeeId, from, to]);
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(timer);
  }, [search]);
  const dateInvalid = Boolean(from && to && from > to);
  const employeeName = employees.find((e) => String(e.id) === employeeId)?.name;
  const filtered = useMemo(() => {
    const query = debouncedSearch.trim().toLowerCase();
    return rows.filter((row) => {
      if (employeeName && row.employee !== employeeName) return false;
      if (from && row.date < from) return false;
      if (to && row.date > to) return false;
      if (query) {
        const haystack = `${row.task} ${row.clickup_task_id} ${row.employee} ${row.phase} ${row.status}`.toLowerCase();
        if (!haystack.includes(query)) return false;
      }
      return true;
    }).sort((a, b) => b.date.localeCompare(a.date));
  }, [rows, employeeName, from, to, debouncedSearch]);
  const hasActiveFilter = Boolean(employeeId) || Boolean(search.trim()) || activePeriod !== "bulan-ini" || from !== initialRange.from || to !== initialRange.to;
  function resetFilters() {
    setEmployeeId("");
    setSearch("");
    setDebouncedSearch("");
    setActivePeriod("bulan-ini");
    setFrom(initialRange.from);
    setTo(initialRange.to);
  }
  function handlePeriodChange(period) {
    setActivePeriod(period);
    const range = getPeriodRange(period);
    setFrom(range.from);
    setTo(range.to);
  }
  function openDetail(row) {
    setSelectedRow(row);
  }
  function handleRowClick(event, row) {
    if (event.target.closest("button")) return;
    openDetail(row);
  }
  function handleExport() {
    setExporting(true);
    exportHistory({ employee_id: employeeId || void 0, from: from || void 0, to: to || void 0 }).then(() => {
      showToast({ type: "success", title: "Ekspor selesai", message: "File berhasil diunduh." });
    }).catch((err) => {
      showToast({ type: "error", title: "Gagal mengekspor", message: err?.message || "Terjadi kesalahan tak terduga." });
    }).finally(() => setExporting(false));
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-slate-50", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto max-w-5xl px-4 py-6 sm:px-8 sm:py-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end justify-between gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-slate-800", children: "History" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 501,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-slate-500", children: "Rekap progres LSPPT harian semua karyawan." }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 502,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 500,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: "/submit", className: "text-sm text-blue-600 hover:underline", children: "← Kembali ke Submit" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 506,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 499,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "mt-6 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-6", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: (e) => e.preventDefault(), className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1fr_1.4fr_auto] lg:items-end", children: [
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            label: "Karyawan",
            placeholder: "Semua karyawan",
            options: employees.map((e) => ({ value: String(e.id), label: e.name })),
            value: employeeId,
            onChange: (e) => setEmployeeId(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 513,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          DatePicker,
          {
            label: "Dari Tanggal",
            value: from,
            onChange: (e) => {
              setFrom(e.target.value);
              setActivePeriod("custom");
            },
            max: to || void 0,
            error: dateInvalid ? "Lebih besar dari tanggal akhir" : void 0
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 520,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          DatePicker,
          {
            label: "Sampai Tanggal",
            value: to,
            onChange: (e) => {
              setTo(e.target.value);
              setActivePeriod("custom");
            },
            min: from || void 0,
            error: dateInvalid ? "Lebih kecil dari tanggal mulai" : void 0
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 530,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            label: "Cari",
            type: "text",
            placeholder: "Cari tugas atau ClickUp ID…",
            value: search,
            onChange: (e) => setSearch(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 540,
            columnNumber: 13
          },
          this
        ),
        hasActiveFilter && /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "outline", onClick: resetFilters, children: "Reset Filter" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 548,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 512,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 511,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "mt-4 rounded-xl border border-slate-200 bg-white shadow-sm", children: [
        !loading && !error && !dateInvalid && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 px-4 py-3 sm:px-6", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-slate-500", children: [
            filtered.length,
            " entri ditemukan"
          ] }, void 0, true, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 558,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "hidden sm:flex items-center gap-1 rounded-lg bg-slate-100 p-1", children: Object.entries(TIME_PERIODS).map(
              ([key, label]) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => handlePeriodChange(key),
                  className: `rounded-md px-3 py-1 text-xs font-medium text-center min-w-[72px] transition-colors ${activePeriod === key ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"}`,
                  children: label
                },
                key,
                false,
                {
                  fileName: "/app/src/pages/HistoryPage.jsx",
                  lineNumber: 564,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 562,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: `hidden text-xs text-slate-400 lg:block min-w-[140px] text-right ${!(from || to) && "invisible"}`, children: from || to ? `${formatDate(from)} – ${formatDate(to)}` : " " }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 578,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "sm",
                variant: "outline",
                loading: exporting,
                disabled: dateInvalid || loading || filtered.length === 0,
                onClick: handleExport,
                children: "Export Excel"
              },
              void 0,
              false,
              {
                fileName: "/app/src/pages/HistoryPage.jsx",
                lineNumber: 581,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 561,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 557,
          columnNumber: 11
        }, this),
        dateInvalid ? /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-[280px] flex-col items-center justify-center gap-2 px-6 py-12 text-center", role: "alert", children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "h-10 w-10 text-amber-400", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: "1.5", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 597,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 596,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-slate-700", children: "Rentang tanggal tidak valid" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 599,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "max-w-xs text-xs text-slate-400", children: "Tanggal akhir lebih awal dari tanggal mulai. Sesuaikan salah satu tanggal untuk melihat history." }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 600,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 595,
          columnNumber: 11
        }, this) : loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-[280px] flex-col items-center justify-center gap-3 px-6 py-12", role: "status", "aria-busy": "true", children: [
          /* @__PURE__ */ jsxDEV(Loading, { size: "lg" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 606,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500", children: "Memuat riwayat…" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 607,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 605,
          columnNumber: 11
        }, this) : error ? /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-[280px] flex-col items-center justify-center gap-3 px-6 py-12 text-center", role: "alert", children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "h-10 w-10 text-red-400", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: "1.5", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M12 9v3.75m0 3.75h.008v.008H12m-9.303-3.382c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 612,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 611,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-slate-700", children: "Gagal memuat data" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 614,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "max-w-xs text-xs text-slate-400", children: error }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 615,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: loadHistory, children: "Coba Lagi" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 616,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 610,
          columnNumber: 11
        }, this) : filtered.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-4 sm:p-6", children: /* @__PURE__ */ jsxDEV(
          EmptyState,
          {
            title: "Belum ada data yang cocok",
            description: "Tidak ada entri history sesuai filter saat ini. Coba ubah karyawan, rentang tanggal, atau kata kunci pencarian.",
            action: hasActiveFilter ? /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: resetFilters, children: "Reset Filter" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 627,
              columnNumber: 15
            }, this) : void 0
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 622,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 621,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV(Table, { className: "min-w-[760px]", children: [
          /* @__PURE__ */ jsxDEV(THead, { children: /* @__PURE__ */ jsxDEV(Tr, { children: [
            /* @__PURE__ */ jsxDEV(Th, { children: "Karyawan" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 639,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Tanggal" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 640,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Tugas" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 641,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "ClickUp ID" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 642,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Phase" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 643,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Status" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 644,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 638,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 637,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TBody, { children: filtered.map(
            (row) => /* @__PURE__ */ jsxDEV(
              Tr,
              {
                tabIndex: 0,
                "aria-label": `Buka detail tugas ${row.task}`,
                onClick: (e) => handleRowClick(e, row),
                onKeyDown: (e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    openDetail(row);
                  }
                },
                className: "group cursor-pointer transition-colors duration-150 hover:bg-slate-50 focus-visible:bg-blue-50/60 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-blue-600",
                children: [
                  /* @__PURE__ */ jsxDEV(Td, { className: "whitespace-nowrap font-medium text-slate-800", children: row.employee }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 662,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Td, { className: "whitespace-nowrap", children: formatDate(row.date) }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 663,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => openDetail(row),
                      className: "text-left font-medium text-blue-600 group-hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "block max-w-[260px] truncate", title: row.task, children: row.task }, void 0, false, {
                        fileName: "/app/src/pages/HistoryPage.jsx",
                        lineNumber: 670,
                        columnNumber: 27
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/pages/HistoryPage.jsx",
                      lineNumber: 665,
                      columnNumber: 25
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 664,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Td, { className: "whitespace-nowrap font-mono text-xs text-slate-500", children: row.clickup_task_id }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 675,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Td, { children: row.phase }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 678,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV(StatusBadge, { status: row.status }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 680,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 679,
                    columnNumber: 23
                  }, this)
                ]
              },
              row.id,
              true,
              {
                fileName: "/app/src/pages/HistoryPage.jsx",
                lineNumber: 649,
                columnNumber: 17
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 647,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 636,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 635,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 555,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 498,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DetailModal, { open: Boolean(selectedRow), onClose: () => setSelectedRow(null), row: selectedRow }, void 0, false, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 691,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/pages/HistoryPage.jsx",
    lineNumber: 497,
    columnNumber: 5
  }, this);
}
_s2(HistoryPage, "UoCKF0Rg6nfRqGD/sAleV8Fsdfk=", false, function() {
  return [useToast];
});
_c4 = HistoryPage;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "StatusBadge");
$RefreshReg$(_c2, "TimelineDot");
$RefreshReg$(_c3, "DetailModal");
$RefreshReg$(_c4, "HistoryPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/pages/HistoryPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/pages/HistoryPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0dTLFNBeUdELFVBekdDOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRHVCxTQUFTQSx1QkFBVUMsV0FBV0MsU0FBU0MsZ0JBQWdCO0FBQ3ZEO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGNBQWNDLFlBQVlDLGdCQUFnQkMsZUFBZUMsV0FBV0MsMEJBQTBCO0FBRXZHLE1BQU1DLGlCQUFpQjtBQUFBLEVBQ3JCQyxXQUFXO0FBQUEsRUFDWCxxQkFBcUI7QUFBQSxFQUNyQkMsZUFBZTtBQUFBLEVBQ2YsZUFBZTtBQUFBLEVBQ2YsV0FBVztBQUFBLEVBQ1hDLE1BQU07QUFBQSxFQUNOLDJCQUEyQjtBQUFBLEVBQzNCQyxTQUFTO0FBQUEsRUFDVCxvQkFBb0I7QUFDdEI7QUFFQSxNQUFNQyxhQUFhO0FBQUEsRUFDakJDLFNBQVM7QUFBQSxFQUNUQyxNQUFNO0FBQUEsRUFDTkMsU0FBUztBQUFBLEVBQ1RDLFFBQVE7QUFBQSxFQUNSQyxTQUFTO0FBQ1g7QUFFQSxNQUFNQyxXQUFXO0FBQUEsRUFDZkwsU0FBUztBQUFBLEVBQ1RDLE1BQU07QUFBQSxFQUNOQyxTQUFTO0FBQUEsRUFDVEMsUUFBUTtBQUFBLEVBQ1JDLFNBQVM7QUFDWDtBQUVBLE1BQU1FLGVBQWU7QUFBQSxFQUNuQixjQUFjO0FBQUEsRUFDZCxhQUFhO0FBQUEsRUFDYixhQUFhO0FBQUEsRUFDYixTQUFTO0FBQ1g7QUFFQSxTQUFTQyxVQUFVQyxNQUFNO0FBQ3ZCLFFBQU1DLE9BQU9ELEtBQUtFLFlBQVk7QUFDOUIsUUFBTUMsUUFBUUMsT0FBT0osS0FBS0ssU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDekQsUUFBTUMsTUFBTUgsT0FBT0osS0FBS1EsUUFBUSxDQUFDLEVBQUVGLFNBQVMsR0FBRyxHQUFHO0FBQ2xELFNBQU8sR0FBR0wsSUFBSSxJQUFJRSxLQUFLLElBQUlJLEdBQUc7QUFDaEM7QUFFQSxTQUFTRSxlQUFlO0FBQ3RCLFFBQU1DLE1BQU0sb0JBQUlDLEtBQUs7QUFDckIsU0FBTztBQUFBLElBQ0xDLE1BQU1iLFVBQVUsSUFBSVksS0FBS0QsSUFBSVIsWUFBWSxHQUFHUSxJQUFJTCxTQUFTLEdBQUcsQ0FBQyxDQUFDO0FBQUEsSUFDOURRLElBQUlkLFVBQVVXLEdBQUc7QUFBQSxFQUNuQjtBQUNGO0FBRUEsU0FBU0ksZUFBZUMsUUFBUTtBQUM5QixRQUFNTCxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFVBQVFJLFFBQU07QUFBQSxJQUNaLEtBQUssY0FBYztBQUNqQixZQUFNQyxZQUFZTixJQUFJTyxPQUFPO0FBQzdCLFlBQU1DLGNBQWMsSUFBSVAsS0FBS0QsR0FBRztBQUNoQ1Esa0JBQVlDLFFBQVFULElBQUlGLFFBQVEsSUFBSVEsU0FBUztBQUM3QyxhQUFPLEVBQUVKLE1BQU1iLFVBQVVtQixXQUFXLEdBQUdMLElBQUlkLFVBQVVXLEdBQUcsRUFBRTtBQUFBLElBQzVEO0FBQUEsSUFDQSxLQUFLO0FBQ0gsYUFBTyxFQUFFRSxNQUFNYixVQUFVLElBQUlZLEtBQUtELElBQUlSLFlBQVksR0FBR1EsSUFBSUwsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHUSxJQUFJZCxVQUFVVyxHQUFHLEVBQUU7QUFBQSxJQUMvRixLQUFLO0FBQ0gsYUFBTyxFQUFFRSxNQUFNYixVQUFVLElBQUlZLEtBQUtELElBQUlSLFlBQVksR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHVyxJQUFJZCxVQUFVVyxHQUFHLEVBQUU7QUFBQSxJQUNsRixLQUFLO0FBQ0gsYUFBTyxFQUFFRSxNQUFNLElBQUlDLElBQUksR0FBRztBQUFBLElBQzVCO0FBQ0UsYUFBT0osYUFBYTtBQUFBLEVBQ3hCO0FBQ0Y7QUFFQSxNQUFNVyxXQUFXLElBQUlDLEtBQUtDLGVBQWUsU0FBUztBQUFBLEVBQ2hEZixLQUFLO0FBQUEsRUFDTEosT0FBTztBQUFBLEVBQ1BGLE1BQU07QUFDUixDQUFDO0FBRUQsU0FBU3NCLFdBQVdDLEtBQUs7QUFDdkIsTUFBSSxDQUFDQSxJQUFLLFFBQU87QUFDakIsU0FBT0osU0FBU0ssT0FBTyxJQUFJZCxLQUFLYSxHQUFHLENBQUM7QUFDdEM7QUFFQSxTQUFTRSxZQUFZLEVBQUVDLE9BQU8sR0FBRztBQUMvQixTQUFPLHVCQUFDLFNBQU0sU0FBU3pDLGVBQWV5QyxNQUFNLEtBQUssV0FBWUEsb0JBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkQ7QUFDdEU7QUFBQ0MsS0FGUUY7QUFJVCxTQUFTRyxZQUFZLEVBQUVDLFNBQVNDLFNBQVMsR0FBRztBQUMxQyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxlQUFZO0FBQUEsTUFDWixXQUFXLHFFQUNUeEMsV0FBV3VDLE9BQU8sQ0FBQyxJQUNqQkMsV0FBV2xDLFNBQVNpQyxPQUFPLElBQUksRUFBRTtBQUFBO0FBQUEsSUFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSTBDO0FBRzlDO0FBQUNFLE1BVFFIO0FBV1QsU0FBU0ksWUFBWSxFQUFFQyxNQUFNQyxTQUFTQyxJQUFJLEdBQUc7QUFBQUMsS0FBQTtBQUMzQyxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSTNFLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUM0RSxTQUFTQyxVQUFVLElBQUk3RSxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDOEUsT0FBT0MsUUFBUSxJQUFJL0UsU0FBUyxJQUFJO0FBRXZDLFFBQU0sQ0FBQ2dGLFFBQVFDLFNBQVMsSUFBSWpGLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ2tGLFlBQVlDLGFBQWEsSUFBSW5GLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUNvRixhQUFhQyxjQUFjLElBQUlyRixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDc0YsY0FBY0MsZUFBZSxJQUFJdkYsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ3dGLFlBQVlDLGFBQWEsSUFBSXpGLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUMwRixjQUFjQyxlQUFlLElBQUkzRixTQUFTLENBQUMsQ0FBQztBQUNuRCxRQUFNLENBQUM0RixVQUFVQyxXQUFXLElBQUk3RixTQUFTLEtBQUs7QUFFOUMsUUFBTSxFQUFFOEYsVUFBVSxJQUFJL0UsU0FBUztBQUUvQixXQUFTZ0YsY0FBYztBQUNyQixRQUFJLENBQUN2QixJQUFLO0FBQ1ZLLGVBQVcsSUFBSTtBQUNmRSxhQUFTLElBQUk7QUFDYjdELG1CQUFlc0QsSUFBSXdCLE9BQU8sRUFDdkJDLEtBQUssQ0FBQ0MsUUFBUXZCLFdBQVd1QixJQUFJQyxJQUFJLENBQUMsRUFDbENDLE1BQU0sQ0FBQ0MsUUFBUXRCLFNBQVNzQixLQUFLQyxXQUFXLGdDQUFnQyxDQUFDLEVBQ3pFQyxRQUFRLE1BQU0xQixXQUFXLEtBQUssQ0FBQztBQUFBLEVBQ3BDO0FBRUEvRSxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUN3RSxRQUFRLENBQUNFLElBQUssUUFBT2dDO0FBQzFCVCxnQkFBWTtBQUNaVixtQkFBZWIsSUFBSWlDLEtBQUs7QUFDeEJsQixvQkFBZ0JmLElBQUlULE1BQU07QUFDMUIsVUFBTTJDLFFBQVEsb0JBQUkzRCxLQUFLO0FBQ3ZCLFVBQU00RCxJQUFJRCxNQUFNcEUsWUFBWTtBQUM1QixVQUFNc0UsSUFBSXBFLE9BQU9rRSxNQUFNakUsU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDdEQsVUFBTW1FLElBQUlyRSxPQUFPa0UsTUFBTTlELFFBQVEsQ0FBQyxFQUFFRixTQUFTLEdBQUcsR0FBRztBQUNqRCtDLGtCQUFjLEdBQUdrQixDQUFDLElBQUlDLENBQUMsSUFBSUMsQ0FBQyxFQUFFO0FBQzlCMUIsa0JBQWMsS0FBSztBQUNuQlEsb0JBQWdCLENBQUMsQ0FBQztBQUNsQixXQUFPLE1BQU07QUFBQSxJQUFDO0FBQUEsRUFDaEIsR0FBRyxDQUFDckIsTUFBTUUsR0FBRyxDQUFDO0FBRWQxRSxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUN3RSxLQUFNO0FBQ1hsRCxjQUFVLEVBQ1A2RSxLQUFLLENBQUNDLFFBQVFqQixVQUFVaUIsSUFBSUMsSUFBSSxDQUFDLEVBQ2pDQyxNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFBQSxFQUNuQixHQUFHLENBQUM5QixJQUFJLENBQUM7QUFFVCxRQUFNd0MsZ0JBQWdCMUIsY0FBY0osT0FBT0ksV0FBVyxLQUFLLEtBQUs7QUFFaEUsV0FBUzJCLGtCQUFrQkMsR0FBRztBQUM1QixVQUFNQyxNQUFNRCxFQUFFRSxPQUFPQztBQUNyQjlCLG1CQUFlNEIsR0FBRztBQUNsQixRQUFJQSxPQUFPLENBQUNqQyxPQUFPaUMsR0FBRyxHQUFHRyxTQUFTOUIsWUFBWSxHQUFHO0FBQy9DQyxzQkFBZ0IsRUFBRTtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFdBQVM4QixxQkFBcUI7QUFDNUIsVUFBTUMsT0FBTyxDQUFDO0FBQ2QsUUFBSSxDQUFDbEMsWUFBYWtDLE1BQUtiLFFBQVE7QUFDL0IsUUFBSSxDQUFDbkIsYUFBY2dDLE1BQUt2RCxTQUFTO0FBQ2pDLFFBQUksQ0FBQ3lCLFdBQVk4QixNQUFLbEYsT0FBTztBQUM3QnVELG9CQUFnQjJCLElBQUk7QUFDcEIsUUFBSUMsT0FBT0MsS0FBS0YsSUFBSSxFQUFFRyxTQUFTLEVBQUc7QUFFbEM1QixnQkFBWSxJQUFJO0FBQ2hCeEUsdUJBQW1CbUQsSUFBSXdCLFNBQVM7QUFBQSxNQUM5QlMsT0FBT3JCO0FBQUFBLE1BQ1ByQixRQUFRdUI7QUFBQUEsTUFDUmxELE1BQU1vRDtBQUFBQSxJQUNSLENBQUMsRUFDRVMsS0FBSyxNQUFNO0FBQ1ZILGdCQUFVLEVBQUU0QixNQUFNLFdBQVdDLE9BQU8sWUFBWXJCLFNBQVMsK0JBQStCLENBQUM7QUFDekZuQixvQkFBYyxLQUFLO0FBQ25CWSxrQkFBWTtBQUFBLElBQ2QsQ0FBQyxFQUNBSyxNQUFNLENBQUNDLFFBQVE7QUFDZFAsZ0JBQVU7QUFBQSxRQUNSNEIsTUFBTTtBQUFBLFFBQ05DLE9BQU87QUFBQSxRQUNQckIsU0FBU0QsSUFBSXRDLFdBQVcsTUFBTSx5Q0FBMENzQyxJQUFJQyxXQUFXO0FBQUEsTUFDekYsQ0FBQztBQUFBLElBQ0gsQ0FBQyxFQUNBQyxRQUFRLE1BQU1WLFlBQVksS0FBSyxDQUFDO0FBQUEsRUFDckM7QUFFQSxRQUFNK0IsY0FBY2xELFNBQVMrQyxTQUFTL0MsUUFBUUEsUUFBUStDLFNBQVMsQ0FBQyxFQUFFckYsT0FBTztBQUV6RSxTQUNFLHVCQUFDLFNBQU0sTUFBWSxTQUFrQixPQUFPb0MsTUFBTUEsSUFBSXFELE9BQU8sZUFBZSxNQUFLLE1BQzlFckQsaUJBQ0MsbUNBQ0U7QUFBQSwyQkFBQyxRQUFHLFdBQVUsbURBQ1o7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDBCQUF5Qix3QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQztBQUFBLFFBQy9DLHVCQUFDLFFBQUcsV0FBVSw2Q0FBNkNBLGNBQUlzRCxZQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFO0FBQUEsV0FGMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDBCQUF5QiwwQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ2pELHVCQUFDLFFBQUcsV0FBVSwyQ0FBMkN0RCxjQUFJdUQsbUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkU7QUFBQSxXQUYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsMEJBQXlCLDhCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsUUFDckQsdUJBQUMsUUFBRyxXQUFVLDJDQUEyQ3ZELGNBQUlpQyxTQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsV0FGckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDBCQUF5QiwrQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFFBQ3RELHVCQUFDLFFBQUcsV0FBVSxRQUNaLGlDQUFDLGVBQVksUUFBUWpDLElBQUlULFVBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsMEJBQXlCLDRCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1EO0FBQUEsUUFDbkQsdUJBQUMsUUFBRyxXQUFVLDZDQUNYNkQsd0JBQWNqRSxXQUFXaUUsV0FBVyxJQUFJLE9BRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsNkJBQUMsT0FBRSxXQUFVLGlFQUFnRSxnQ0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQ2hELFdBQ0MsdUJBQUMsU0FBSSxXQUFVLDBDQUF5QyxNQUFLLFVBQVMsYUFBVSxRQUM5RTtBQUFBLCtCQUFDLFdBQVEsTUFBSyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUNsQix1QkFBQyxPQUFFLFdBQVUsMEJBQXlCLHdDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThEO0FBQUEsV0FGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFHRCxDQUFDQSxXQUFXRSxTQUNYLHVCQUFDLFNBQUksV0FBVSx5Q0FBd0MsTUFBSyxTQUMxRDtBQUFBLCtCQUFDLE9BQUUsV0FBVSx3QkFBd0JBLG1CQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJDO0FBQUEsUUFDM0MsdUJBQUMsT0FBRSxXQUFVLDBCQUF5QixvREFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFdBQVUsU0FBU2lCLGFBQWEseUJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFHRCxDQUFDbkIsV0FBVyxDQUFDRSxTQUFTSixXQUFXQSxRQUFRK0MsU0FBUyxLQUNqRCx1QkFBQyxRQUFHLFdBQVUsa0RBQWlELGNBQVcsb0JBQ3ZFL0Msa0JBQVFzRCxJQUFJLENBQUNDLE9BQU9DLFVBQVU7QUFDN0IsY0FBTWhFLFVBQVU1QyxlQUFlMkcsTUFBTWxFLE1BQU0sS0FBSztBQUNoRCxjQUFNSSxXQUFXK0QsVUFBVXhELFFBQVErQyxTQUFTO0FBQzVDLGNBQU1VLFlBQVlELFFBQVEsSUFBSXhELFFBQVF3RCxRQUFRLENBQUMsSUFBSTtBQUNuRCxjQUFNRSxlQUFlRCxhQUFhQSxVQUFVMUIsVUFBVXdCLE1BQU14QjtBQUM1RCxlQUNFLHVCQUFDNUcsV0FBQSxFQUNFdUk7QUFBQUEsMEJBQ0MsdUJBQUMsUUFBRyxXQUFVLHNCQUFxQixlQUFZLFFBQzdDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHNHQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSDtBQUFBLFlBQ2xILHVCQUFDLFVBQUssV0FBVSx5SkFBd0o7QUFBQTtBQUFBLGNBQzlKRCxVQUFVMUI7QUFBQUEsY0FBTTtBQUFBLGNBQUl3QixNQUFNeEI7QUFBQUEsaUJBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUVGLHVCQUFDLFFBQUcsV0FBVyxZQUFZMkIsZUFBZSxTQUFTLEVBQUUsd0JBQ25EO0FBQUEsbUNBQUMsZUFBWSxTQUFrQixZQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLFlBQ2xELHVCQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcsV0FDVGpFLFdBQVcsaUNBQWlDLGdCQUFnQjtBQUFBLGtCQUc3RFIscUJBQVdzRSxNQUFNN0YsSUFBSTtBQUFBO0FBQUEsZ0JBTHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsMkJBQ2Q7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsMEJBQTBCNkYsZ0JBQU14QixTQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRDtBQUFBLGdCQUN0RCx1QkFBQyxlQUFZLFFBQVF3QixNQUFNbEUsVUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0M7QUFBQSxtQkFGcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUNDSSxZQUNDLHVCQUFDLE9BQUUsV0FBVSwrQkFBOEIsMkNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsZUFoQjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsYUEzQmEsR0FBRzhELE1BQU03RixJQUFJLElBQUk2RixNQUFNbEUsTUFBTSxJQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBO0FBQUEsTUFFSixDQUFDLEtBckNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQ0E7QUFBQSxNQUdELENBQUNhLFdBQVcsQ0FBQ0UsU0FBU0osV0FBV0EsUUFBUStDLFdBQVcsS0FDbkQsdUJBQUMsT0FBRSxXQUFVLCtCQUE4Qix1RUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRztBQUFBLFNBbkV0RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUVBO0FBQUEsSUFFQ3ZDLGNBQ0MsdUJBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUEsNkJBQUMsT0FBRSxXQUFVLHFFQUFvRSwrQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sYUFBWTtBQUFBLFlBQ1osU0FBU3FDLE9BQU9DLEtBQUt4QyxNQUFNLEVBQUVnRCxJQUFJLENBQUNLLE9BQU8sRUFBRWxCLE9BQU9rQixHQUFHQyxPQUFPRCxFQUFFLEVBQUU7QUFBQSxZQUNoRSxPQUFPakQ7QUFBQUEsWUFDUCxVQUFVMkI7QUFBQUEsWUFDVixPQUFPckIsYUFBYWU7QUFBQUE7QUFBQUEsVUFOdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTTRCO0FBQUEsUUFFNUI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLGFBQWFyQixjQUFjLGlCQUFpQjtBQUFBLFlBQzVDLFNBQVMwQixjQUFja0IsSUFBSSxDQUFDTyxPQUFPLEVBQUVwQixPQUFPb0IsR0FBR0QsT0FBT0MsRUFBRSxFQUFFO0FBQUEsWUFDMUQsT0FBT2pEO0FBQUFBLFlBQ1AsVUFBVSxDQUFDMEIsTUFBTTtBQUFFekIsOEJBQWdCeUIsRUFBRUUsT0FBT0MsS0FBSztBQUFHeEIsOEJBQWdCLENBQUMwQyxPQUFPLEVBQUUsR0FBR0EsR0FBR3RFLFFBQVF5QyxPQUFVLEVBQUU7QUFBQSxZQUFHO0FBQUEsWUFDM0csVUFBVSxDQUFDcEI7QUFBQUEsWUFDWCxPQUFPTSxhQUFhM0I7QUFBQUE7QUFBQUEsVUFQdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTzZCO0FBQUEsUUFFN0I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU95QjtBQUFBQSxZQUNQLFVBQVUsQ0FBQ3dCLE1BQU07QUFBRXZCLDRCQUFjdUIsRUFBRUUsT0FBT0MsS0FBSztBQUFHeEIsOEJBQWdCLENBQUMwQyxPQUFPLEVBQUUsR0FBR0EsR0FBR2pHLE1BQU1vRSxPQUFVLEVBQUU7QUFBQSxZQUFHO0FBQUEsWUFDdkcsT0FBT2QsYUFBYXREO0FBQUFBO0FBQUFBLFVBSnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUkyQjtBQUFBLFdBdEI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSwrQkFBQyxVQUFPLE1BQUssVUFBUyxTQUFRLFdBQVUsTUFBSyxNQUFLLFNBQVMsTUFBTStDLGNBQWMsS0FBSyxHQUFHLHFCQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQU8sTUFBSyxVQUFTLE1BQUssTUFBSyxTQUFTUyxVQUFVLFNBQVN5QixvQkFBb0IsK0JBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0FwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFDQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxXQUFVLDhEQUNaO0FBQUEsT0FBQ25DLGNBQ0EsdUJBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUyxNQUFNQyxjQUFjLElBQUksR0FBRywrQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFRix1QkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTWixTQUFTLHFCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLE9BckpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzSkEsS0F4Sko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBKQTtBQUVKO0FBQUNFLEdBclBRSixhQUFXO0FBQUEsVUFhSXRELFFBQVE7QUFBQTtBQUFBLE1BYnZCc0Q7QUF1UFQsd0JBQXdCbUUsY0FBYztBQUFBQyxNQUFBO0FBQ3BDLFFBQU1DLGVBQWUzSSxRQUFROEMsY0FBYyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzhGLFdBQVdDLFlBQVksSUFBSTVJLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM2SSxZQUFZQyxhQUFhLElBQUk5SSxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDZ0QsTUFBTStGLE9BQU8sSUFBSS9JLFNBQVMwSSxhQUFhMUYsSUFBSTtBQUNsRCxRQUFNLENBQUNDLElBQUkrRixLQUFLLElBQUloSixTQUFTMEksYUFBYXpGLEVBQUU7QUFDNUMsUUFBTSxDQUFDZ0csUUFBUUMsU0FBUyxJQUFJbEosU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ21KLGlCQUFpQkMsa0JBQWtCLElBQUlwSixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDcUosY0FBY0MsZUFBZSxJQUFJdEosU0FBUyxXQUFXO0FBRTVELFFBQU0sQ0FBQ3VKLE1BQU1DLE9BQU8sSUFBSXhKLFNBQVMsRUFBRTtBQUNuQyxRQUFNLENBQUM0RSxTQUFTQyxVQUFVLElBQUk3RSxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDOEUsT0FBT0MsUUFBUSxJQUFJL0UsU0FBUyxJQUFJO0FBRXZDLFFBQU0sQ0FBQ3lKLGFBQWFDLGNBQWMsSUFBSTFKLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUMySixXQUFXQyxZQUFZLElBQUk1SixTQUFTLEtBQUs7QUFDaEQsUUFBTSxFQUFFOEYsVUFBVSxJQUFJL0UsU0FBUztBQUUvQmpCLFlBQVUsTUFBTTtBQUNkLFFBQUkrSixZQUFZO0FBQ2hCN0ksaUJBQWEsRUFDVmlGLEtBQUssQ0FBQ0MsUUFBUTtBQUNiLFVBQUksQ0FBQzJELFVBQVdqQixjQUFhMUMsSUFBSUMsSUFBSTtBQUFBLElBQ3ZDLENBQUMsRUFDQUMsTUFBTSxNQUFNO0FBQUEsSUFBQyxDQUFDO0FBQ2pCLFdBQU8sTUFBTTtBQUNYeUQsa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxXQUFTOUQsY0FBYztBQUNyQmxCLGVBQVcsSUFBSTtBQUNmRSxhQUFTLElBQUk7QUFDYjlELGVBQVcsRUFBRTZJLGFBQWFqQixjQUFjckMsUUFBV3hELE1BQU1BLFFBQVF3RCxRQUFXdkQsSUFBSUEsTUFBTXVELE9BQVUsQ0FBQyxFQUM5RlAsS0FBSyxDQUFDQyxRQUFRc0QsUUFBUXRELElBQUlDLElBQUksQ0FBQyxFQUMvQkMsTUFBTSxDQUFDQyxRQUFRdEIsU0FBU3NCLEtBQUtDLFdBQVcsZ0NBQWdDLENBQUMsRUFDekVDLFFBQVEsTUFBTTFCLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFDcEM7QUFFQS9FLFlBQVUsTUFBTTtBQUNkaUcsZ0JBQVk7QUFBQSxFQUVkLEdBQUcsQ0FBQzhDLFlBQVk3RixNQUFNQyxFQUFFLENBQUM7QUFFekJuRCxZQUFVLE1BQU07QUFDZCxVQUFNaUssUUFBUUMsV0FBVyxNQUFNWixtQkFBbUJILE1BQU0sR0FBRyxHQUFHO0FBQzlELFdBQU8sTUFBTWdCLGFBQWFGLEtBQUs7QUFBQSxFQUNqQyxHQUFHLENBQUNkLE1BQU0sQ0FBQztBQUVYLFFBQU1pQixjQUFjQyxRQUFRbkgsUUFBUUMsTUFBTUQsT0FBT0MsRUFBRTtBQUVuRCxRQUFNbUgsZUFBZXpCLFVBQVUwQixLQUFLLENBQUNyRCxNQUFNeEUsT0FBT3dFLEVBQUVzRCxFQUFFLE1BQU16QixVQUFVLEdBQUcwQjtBQUV6RSxRQUFNQyxXQUFXekssUUFBUSxNQUFNO0FBQzdCLFVBQU0wSyxRQUFRdEIsZ0JBQWdCdUIsS0FBSyxFQUFFQyxZQUFZO0FBQ2pELFdBQU9wQixLQUNKcUIsT0FBTyxDQUFDcEcsUUFBUTtBQUNmLFVBQUk0RixnQkFBZ0I1RixJQUFJc0QsYUFBYXNDLGFBQWMsUUFBTztBQUMxRCxVQUFJcEgsUUFBUXdCLElBQUlwQyxPQUFPWSxLQUFNLFFBQU87QUFDcEMsVUFBSUMsTUFBTXVCLElBQUlwQyxPQUFPYSxHQUFJLFFBQU87QUFDaEMsVUFBSXdILE9BQU87QUFDVCxjQUFNSSxXQUFXLEdBQUdyRyxJQUFJcUQsSUFBSSxJQUFJckQsSUFBSXVELGVBQWUsSUFBSXZELElBQUlzRCxRQUFRLElBQUl0RCxJQUFJaUMsS0FBSyxJQUFJakMsSUFBSVQsTUFBTSxHQUFHNEcsWUFBWTtBQUM3RyxZQUFJLENBQUNFLFNBQVN6RCxTQUFTcUQsS0FBSyxFQUFHLFFBQU87QUFBQSxNQUN4QztBQUNBLGFBQU87QUFBQSxJQUNULENBQUMsRUFDQUssS0FBSyxDQUFDQyxHQUFHQyxNQUFNQSxFQUFFNUksS0FBSzZJLGNBQWNGLEVBQUUzSSxJQUFJLENBQUM7QUFBQSxFQUNoRCxHQUFHLENBQUNtSCxNQUFNYSxjQUFjcEgsTUFBTUMsSUFBSWtHLGVBQWUsQ0FBQztBQUVsRCxRQUFNK0Isa0JBQ0pmLFFBQVF0QixVQUFVLEtBQ2xCc0IsUUFBUWxCLE9BQU95QixLQUFLLENBQUMsS0FDckJyQixpQkFBaUIsZUFDakJyRyxTQUFTMEYsYUFBYTFGLFFBQ3RCQyxPQUFPeUYsYUFBYXpGO0FBRXRCLFdBQVNrSSxlQUFlO0FBQ3RCckMsa0JBQWMsRUFBRTtBQUNoQkksY0FBVSxFQUFFO0FBQ1pFLHVCQUFtQixFQUFFO0FBQ3JCRSxvQkFBZ0IsV0FBVztBQUMzQlAsWUFBUUwsYUFBYTFGLElBQUk7QUFDekJnRyxVQUFNTixhQUFhekYsRUFBRTtBQUFBLEVBQ3ZCO0FBRUEsV0FBU21JLG1CQUFtQmpJLFFBQVE7QUFDbENtRyxvQkFBZ0JuRyxNQUFNO0FBQ3RCLFVBQU1rSSxRQUFRbkksZUFBZUMsTUFBTTtBQUNuQzRGLFlBQVFzQyxNQUFNckksSUFBSTtBQUNsQmdHLFVBQU1xQyxNQUFNcEksRUFBRTtBQUFBLEVBQ2hCO0FBRUEsV0FBU3FJLFdBQVc5RyxLQUFLO0FBQ3ZCa0YsbUJBQWVsRixHQUFHO0FBQUEsRUFDcEI7QUFFQSxXQUFTK0csZUFBZUMsT0FBT2hILEtBQUs7QUFDbEMsUUFBSWdILE1BQU10RSxPQUFPdUUsUUFBUSxRQUFRLEVBQUc7QUFDcENILGVBQVc5RyxHQUFHO0FBQUEsRUFDaEI7QUFFQSxXQUFTa0gsZUFBZTtBQUN0QjlCLGlCQUFhLElBQUk7QUFDakJ6SSxrQkFBYyxFQUFFMkksYUFBYWpCLGNBQWNyQyxRQUFXeEQsTUFBTUEsUUFBUXdELFFBQVd2RCxJQUFJQSxNQUFNdUQsT0FBVSxDQUFDLEVBQ2pHUCxLQUFLLE1BQU07QUFDVkgsZ0JBQVUsRUFBRTRCLE1BQU0sV0FBV0MsT0FBTyxrQkFBa0JyQixTQUFTLHlCQUF5QixDQUFDO0FBQUEsSUFDM0YsQ0FBQyxFQUNBRixNQUFNLENBQUNDLFFBQVE7QUFDZFAsZ0JBQVUsRUFBRTRCLE1BQU0sU0FBU0MsT0FBTyxvQkFBb0JyQixTQUFTRCxLQUFLQyxXQUFXLGlDQUFpQyxDQUFDO0FBQUEsSUFDbkgsQ0FBQyxFQUNBQyxRQUFRLE1BQU1xRCxhQUFhLEtBQUssQ0FBQztBQUFBLEVBQ3RDO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsK0NBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHFDQUFvQyx1QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxVQUN6RCx1QkFBQyxPQUFFLFdBQVUsK0JBQThCLDBEQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsTUFBSyxXQUFVLFdBQVUseUNBQXdDLG1DQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BRUEsdUJBQUMsYUFBUSxXQUFVLHlFQUNqQixpQ0FBQyxVQUFLLFVBQVUsQ0FBQzVDLE1BQU1BLEVBQUUyRSxlQUFlLEdBQUcsV0FBVSxnRkFDbkQ7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sYUFBWTtBQUFBLFlBQ1osU0FBU2hELFVBQVVYLElBQUksQ0FBQ2hCLE9BQU8sRUFBRUcsT0FBTzNFLE9BQU93RSxFQUFFc0QsRUFBRSxHQUFHaEMsT0FBT3RCLEVBQUV1RCxLQUFLLEVBQUU7QUFBQSxZQUN0RSxPQUFPMUI7QUFBQUEsWUFDUCxVQUFVLENBQUM3QixNQUFNOEIsY0FBYzlCLEVBQUVFLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFVBTC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtpRDtBQUFBLFFBRWpEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPbkU7QUFBQUEsWUFDUCxVQUFVLENBQUNnRSxNQUFNO0FBQ2YrQixzQkFBUS9CLEVBQUVFLE9BQU9DLEtBQUs7QUFDdEJtQyw4QkFBZ0IsUUFBUTtBQUFBLFlBQzFCO0FBQUEsWUFDQSxLQUFLckcsTUFBTXVEO0FBQUFBLFlBQ1gsT0FBTzBELGNBQWMsbUNBQW1DMUQ7QUFBQUE7QUFBQUEsVUFSMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUW9FO0FBQUEsUUFFcEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU92RDtBQUFBQSxZQUNQLFVBQVUsQ0FBQytELE1BQU07QUFDZmdDLG9CQUFNaEMsRUFBRUUsT0FBT0MsS0FBSztBQUNwQm1DLDhCQUFnQixRQUFRO0FBQUEsWUFDMUI7QUFBQSxZQUNBLEtBQUt0RyxRQUFRd0Q7QUFBQUEsWUFDYixPQUFPMEQsY0FBYyxtQ0FBbUMxRDtBQUFBQTtBQUFBQSxVQVIxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRb0U7QUFBQSxRQUVwRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sTUFBSztBQUFBLFlBQ0wsYUFBWTtBQUFBLFlBQ1osT0FBT3lDO0FBQUFBLFlBQ1AsVUFBVSxDQUFDakMsTUFBTWtDLFVBQVVsQyxFQUFFRSxPQUFPQyxLQUFLO0FBQUE7QUFBQSxVQUwzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLNkM7QUFBQSxRQUU1QytELG1CQUNDLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVEsV0FBVSxTQUFTQyxjQUFjLDRCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQXRDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0NBLEtBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQ0E7QUFBQSxNQUVBLHVCQUFDLGFBQVEsV0FBVSw4REFDaEI7QUFBQSxTQUFDdkcsV0FBVyxDQUFDRSxTQUFTLENBQUNvRixlQUN0Qix1QkFBQyxTQUFJLFdBQVUsaUdBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsc0NBQ1ZNO0FBQUFBLHFCQUFTL0M7QUFBQUEsWUFBTztBQUFBLGVBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxpRUFDWkYsaUJBQU83QyxRQUFReEMsWUFBWSxFQUFFOEY7QUFBQUEsY0FBSSxDQUFDLENBQUM0RCxLQUFLdEQsS0FBSyxNQUM1QztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNOEMsbUJBQW1CUSxHQUFHO0FBQUEsa0JBQ3JDLFdBQVcsdUZBQ1R2QyxpQkFBaUJ1QyxNQUNiLHNDQUNBLHFDQUFxQztBQUFBLGtCQUcxQ3REO0FBQUFBO0FBQUFBLGdCQVRJc0Q7QUFBQUEsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBO0FBQUEsWUFDRCxLQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVyxtRUFBbUUsRUFBRTVJLFFBQVFDLE9BQU8sV0FBVyxJQUMxR0Qsa0JBQVFDLEtBQUssR0FBR1UsV0FBV1gsSUFBSSxDQUFDLE1BQU1XLFdBQVdWLEVBQUUsQ0FBQyxLQUFLLE9BRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVE7QUFBQSxnQkFDUixTQUFTMEc7QUFBQUEsZ0JBQ1QsVUFBVU8sZUFBZXRGLFdBQVc0RixTQUFTL0MsV0FBVztBQUFBLGdCQUN4RCxTQUFTaUU7QUFBQUEsZ0JBQWE7QUFBQTtBQUFBLGNBTHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsZUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxhQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0NBO0FBQUEsUUFHRHhCLGNBQ0MsdUJBQUMsU0FBSSxXQUFVLHdGQUF1RixNQUFLLFNBQ3pHO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRCQUEyQixNQUFLLFFBQU8sU0FBUSxhQUFZLFFBQU8sZ0JBQWUsYUFBWSxPQUMxRyxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLEdBQUUsc0xBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVPLEtBRHpPO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxzQ0FBcUMsMkNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZFO0FBQUEsVUFDN0UsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQyxnSEFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLElBQ0V0RixVQUNGLHVCQUFDLFNBQUksV0FBVSw0RUFBMkUsTUFBSyxVQUFTLGFBQVUsUUFDaEg7QUFBQSxpQ0FBQyxXQUFRLE1BQUssUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQjtBQUFBLFVBQ2xCLHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsK0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsYUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBQ0VFLFFBQ0YsdUJBQUMsU0FBSSxXQUFVLHdGQUF1RixNQUFLLFNBQ3pHO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBCQUF5QixNQUFLLFFBQU8sU0FBUSxhQUFZLFFBQU8sZ0JBQWUsYUFBWSxPQUN4RyxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLEdBQUUsME1BQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJQLEtBRDdQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxzQ0FBcUMsaUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFDbkUsdUJBQUMsT0FBRSxXQUFVLG1DQUFtQ0EsbUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNEO0FBQUEsVUFDdEQsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxXQUFVLFNBQVNpQixhQUFhLHlCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0EsSUFDRXlFLFNBQVMvQyxXQUFXLElBQ3RCLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixhQUFZO0FBQUEsWUFDWixRQUNFeUQsa0JBQ0UsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxXQUFVLFNBQVNDLGNBQWMsNEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFDRTNFO0FBQUFBO0FBQUFBLFVBUlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0csS0FWTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2IsaUNBQUMsU0FBTSxXQUFVLGlCQUNmO0FBQUEsaUNBQUMsU0FDQyxpQ0FBQyxNQUNDO0FBQUEsbUNBQUMsTUFBRyx3QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFZO0FBQUEsWUFDWix1QkFBQyxNQUFHLHVCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVc7QUFBQSxZQUNYLHVCQUFDLE1BQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUztBQUFBLFlBQ1QsdUJBQUMsTUFBRywwQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFjO0FBQUEsWUFDZCx1QkFBQyxNQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVM7QUFBQSxZQUNULHVCQUFDLE1BQUcsc0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBVTtBQUFBLGVBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0VnRSxtQkFBU3hDO0FBQUFBLFlBQUksQ0FBQ3hELFFBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxVQUFVO0FBQUEsZ0JBQ1YsY0FBWSxxQkFBcUJBLElBQUlxRCxJQUFJO0FBQUEsZ0JBQ3pDLFNBQVMsQ0FBQ2IsTUFBTXVFLGVBQWV2RSxHQUFHeEMsR0FBRztBQUFBLGdCQUNyQyxXQUFXLENBQUN3QyxNQUFNO0FBQ2hCLHNCQUFJQSxFQUFFNEUsUUFBUSxXQUFXNUUsRUFBRTRFLFFBQVEsS0FBSztBQUN0QzVFLHNCQUFFMkUsZUFBZTtBQUNqQkwsK0JBQVc5RyxHQUFHO0FBQUEsa0JBQ2hCO0FBQUEsZ0JBQ0Y7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxNQUFHLFdBQVUsZ0RBQWdEQSxjQUFJc0QsWUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkU7QUFBQSxrQkFDM0UsdUJBQUMsTUFBRyxXQUFVLHFCQUFxQm5FLHFCQUFXYSxJQUFJcEMsSUFBSSxLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLGtCQUN4RCx1QkFBQyxNQUNDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLE1BQU1rSixXQUFXOUcsR0FBRztBQUFBLHNCQUM3QixXQUFVO0FBQUEsc0JBRVYsaUNBQUMsVUFBSyxXQUFVLGdDQUErQixPQUFPQSxJQUFJcUQsTUFDdkRyRCxjQUFJcUQsUUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUE7QUFBQSxvQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVVBO0FBQUEsa0JBQ0EsdUJBQUMsTUFBRyxXQUFVLHNEQUNYckQsY0FBSXVELG1CQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxNQUFJdkQsY0FBSWlDLFNBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZTtBQUFBLGtCQUNmLHVCQUFDLE1BQ0MsaUNBQUMsZUFBWSxRQUFRakMsSUFBSVQsVUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0MsS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBO0FBQUE7QUFBQSxjQS9CS1MsSUFBSThGO0FBQUFBLGNBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlDQTtBQUFBLFVBQ0QsS0FwQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQ0E7QUFBQSxhQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaURBLEtBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtREE7QUFBQSxXQW5JSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUlBO0FBQUEsU0E5TEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStMQTtBQUFBLElBRUEsdUJBQUMsZUFBWSxNQUFNSCxRQUFRVixXQUFXLEdBQUcsU0FBUyxNQUFNQyxlQUFlLElBQUksR0FBRyxLQUFLRCxlQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStGO0FBQUEsT0FsTWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtTUE7QUFFSjtBQUFDaEIsSUF2VHVCRCxhQUFXO0FBQUEsVUFnQlh6SCxRQUFRO0FBQUE7QUFBQSxNQWhCUnlIO0FBQVcsSUFBQXhFLElBQUFJLEtBQUF5SCxLQUFBQztBQUFBLGFBQUE5SCxJQUFBO0FBQUEsYUFBQUksS0FBQTtBQUFBLGFBQUF5SCxLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbIkZyYWdtZW50IiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiQmFkZ2UiLCJCdXR0b24iLCJEYXRlUGlja2VyIiwiRW1wdHlTdGF0ZSIsIklucHV0IiwiTG9hZGluZyIsIk1vZGFsIiwiU2VsZWN0IiwiVGFibGUiLCJUQm9keSIsIlRkIiwiVGgiLCJUSGVhZCIsIlRyIiwidXNlVG9hc3QiLCJnZXRFbXBsb3llZXMiLCJnZXRIaXN0b3J5IiwiZ2V0VGFza0hpc3RvcnkiLCJleHBvcnRIaXN0b3J5IiwiZ2V0UGhhc2VzIiwidXBkYXRlVGFza1Byb2dyZXNzIiwiU1RBVFVTX1ZBUklBTlQiLCJDb21wbGV0ZWQiLCJEb2N1bWVudGF0aW9uIiwiUGxhbiIsIlRlc3RpbmciLCJET1RfQk9SREVSIiwic3VjY2VzcyIsImluZm8iLCJ3YXJuaW5nIiwiZGFuZ2VyIiwibmV1dHJhbCIsIkRPVF9GSUxMIiwiVElNRV9QRVJJT0RTIiwidG9JU09EYXRlIiwiZGF0ZSIsInllYXIiLCJnZXRGdWxsWWVhciIsIm1vbnRoIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsImRheSIsImdldERhdGUiLCJkZWZhdWx0UmFuZ2UiLCJub3ciLCJEYXRlIiwiZnJvbSIsInRvIiwiZ2V0UGVyaW9kUmFuZ2UiLCJwZXJpb2QiLCJkYXlPZldlZWsiLCJnZXREYXkiLCJzdGFydE9mV2VlayIsInNldERhdGUiLCJEQVRFX0ZNVCIsIkludGwiLCJEYXRlVGltZUZvcm1hdCIsImZvcm1hdERhdGUiLCJpc28iLCJmb3JtYXQiLCJTdGF0dXNCYWRnZSIsInN0YXR1cyIsIl9jIiwiVGltZWxpbmVEb3QiLCJ2YXJpYW50IiwiaXNMYXRlc3QiLCJfYzIiLCJEZXRhaWxNb2RhbCIsIm9wZW4iLCJvbkNsb3NlIiwicm93IiwiX3MiLCJlbnRyaWVzIiwic2V0RW50cmllcyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsInBoYXNlcyIsInNldFBoYXNlcyIsInNob3dVcGRhdGUiLCJzZXRTaG93VXBkYXRlIiwidXBkYXRlUGhhc2UiLCJzZXRVcGRhdGVQaGFzZSIsInVwZGF0ZVN0YXR1cyIsInNldFVwZGF0ZVN0YXR1cyIsInVwZGF0ZURhdGUiLCJzZXRVcGRhdGVEYXRlIiwidXBkYXRlRXJyb3JzIiwic2V0VXBkYXRlRXJyb3JzIiwidXBkYXRpbmciLCJzZXRVcGRhdGluZyIsInNob3dUb2FzdCIsImxvYWRIaXN0b3J5IiwidGFza19pZCIsInRoZW4iLCJyZXMiLCJkYXRhIiwiY2F0Y2giLCJlcnIiLCJtZXNzYWdlIiwiZmluYWxseSIsInVuZGVmaW5lZCIsInBoYXNlIiwidG9kYXkiLCJ5IiwibSIsImQiLCJzdGF0dXNPcHRpb25zIiwiaGFuZGxlUGhhc2VDaGFuZ2UiLCJlIiwidmFsIiwidGFyZ2V0IiwidmFsdWUiLCJpbmNsdWRlcyIsImhhbmRsZVN1Ym1pdFVwZGF0ZSIsImVycnMiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwidHlwZSIsInRpdGxlIiwibGFzdFVwZGF0ZWQiLCJ0YXNrIiwiZW1wbG95ZWUiLCJjbGlja3VwX3Rhc2tfaWQiLCJtYXAiLCJlbnRyeSIsImluZGV4IiwicHJldkVudHJ5IiwicGhhc2VDaGFuZ2VkIiwicCIsImxhYmVsIiwicyIsIkhpc3RvcnlQYWdlIiwiX3MyIiwiaW5pdGlhbFJhbmdlIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwiZW1wbG95ZWVJZCIsInNldEVtcGxveWVlSWQiLCJzZXRGcm9tIiwic2V0VG8iLCJzZWFyY2giLCJzZXRTZWFyY2giLCJkZWJvdW5jZWRTZWFyY2giLCJzZXREZWJvdW5jZWRTZWFyY2giLCJhY3RpdmVQZXJpb2QiLCJzZXRBY3RpdmVQZXJpb2QiLCJyb3dzIiwic2V0Um93cyIsInNlbGVjdGVkUm93Iiwic2V0U2VsZWN0ZWRSb3ciLCJleHBvcnRpbmciLCJzZXRFeHBvcnRpbmciLCJjYW5jZWxsZWQiLCJlbXBsb3llZV9pZCIsInRpbWVyIiwic2V0VGltZW91dCIsImNsZWFyVGltZW91dCIsImRhdGVJbnZhbGlkIiwiQm9vbGVhbiIsImVtcGxveWVlTmFtZSIsImZpbmQiLCJpZCIsIm5hbWUiLCJmaWx0ZXJlZCIsInF1ZXJ5IiwidHJpbSIsInRvTG93ZXJDYXNlIiwiZmlsdGVyIiwiaGF5c3RhY2siLCJzb3J0IiwiYSIsImIiLCJsb2NhbGVDb21wYXJlIiwiaGFzQWN0aXZlRmlsdGVyIiwicmVzZXRGaWx0ZXJzIiwiaGFuZGxlUGVyaW9kQ2hhbmdlIiwicmFuZ2UiLCJvcGVuRGV0YWlsIiwiaGFuZGxlUm93Q2xpY2siLCJldmVudCIsImNsb3Nlc3QiLCJoYW5kbGVFeHBvcnQiLCJwcmV2ZW50RGVmYXVsdCIsImtleSIsIl9jMyIsIl9jNCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJIaXN0b3J5UGFnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRnJhZ21lbnQsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7XHJcbiAgQmFkZ2UsXHJcbiAgQnV0dG9uLFxyXG4gIERhdGVQaWNrZXIsXHJcbiAgRW1wdHlTdGF0ZSxcclxuICBJbnB1dCxcclxuICBMb2FkaW5nLFxyXG4gIE1vZGFsLFxyXG4gIFNlbGVjdCxcclxuICBUYWJsZSxcclxuICBUQm9keSxcclxuICBUZCxcclxuICBUaCxcclxuICBUSGVhZCxcclxuICBUcixcclxuICB1c2VUb2FzdCxcclxufSBmcm9tICcuLi9jb21wb25lbnRzL3VpJztcclxuaW1wb3J0IHsgZ2V0RW1wbG95ZWVzLCBnZXRIaXN0b3J5LCBnZXRUYXNrSGlzdG9yeSwgZXhwb3J0SGlzdG9yeSwgZ2V0UGhhc2VzLCB1cGRhdGVUYXNrUHJvZ3Jlc3MgfSBmcm9tICcuLi9hcGkvbHNwcHQnO1xyXG5cclxuY29uc3QgU1RBVFVTX1ZBUklBTlQgPSB7XHJcbiAgQ29tcGxldGVkOiAnc3VjY2VzcycsXHJcbiAgJ0NvbXBsZXRlZCBUZXN0aW5nJzogJ3N1Y2Nlc3MnLFxyXG4gIERvY3VtZW50YXRpb246ICdpbmZvJyxcclxuICAnSW4gUHJvZ3Jlc3MnOiAnaW5mbycsXHJcbiAgJ09uIEhvbGQnOiAnZGFuZ2VyJyxcclxuICBQbGFuOiAnbmV1dHJhbCcsXHJcbiAgJ0NvbXBsZXRlZCB3aXRoIEZlZWRiYWNrJzogJ3dhcm5pbmcnLFxyXG4gIFRlc3Rpbmc6ICd3YXJuaW5nJyxcclxuICAnT24gUXVldWUgVGVzdGluZyc6ICd3YXJuaW5nJyxcclxufTtcclxuXHJcbmNvbnN0IERPVF9CT1JERVIgPSB7XHJcbiAgc3VjY2VzczogJ2JvcmRlci1ncmVlbi01MDAnLFxyXG4gIGluZm86ICdib3JkZXItYmx1ZS01MDAnLFxyXG4gIHdhcm5pbmc6ICdib3JkZXItYW1iZXItNTAwJyxcclxuICBkYW5nZXI6ICdib3JkZXItcmVkLTUwMCcsXHJcbiAgbmV1dHJhbDogJ2JvcmRlci1zbGF0ZS00MDAnLFxyXG59O1xyXG5cclxuY29uc3QgRE9UX0ZJTEwgPSB7XHJcbiAgc3VjY2VzczogJ2JnLWdyZWVuLTUwMCcsXHJcbiAgaW5mbzogJ2JnLWJsdWUtNTAwJyxcclxuICB3YXJuaW5nOiAnYmctYW1iZXItNTAwJyxcclxuICBkYW5nZXI6ICdiZy1yZWQtNTAwJyxcclxuICBuZXV0cmFsOiAnYmctc2xhdGUtNDAwJyxcclxufTtcclxuXHJcbmNvbnN0IFRJTUVfUEVSSU9EUyA9IHtcclxuICAnbWluZ2d1LWluaSc6ICdNaW5nZ3UgSW5pJyxcclxuICAnYnVsYW4taW5pJzogJ0J1bGFuIEluaScsXHJcbiAgJ3RhaHVuLWluaSc6ICdUYWh1biBJbmknLFxyXG4gICdzZW11YSc6ICdTZW11YScsXHJcbn07XHJcblxyXG5mdW5jdGlvbiB0b0lTT0RhdGUoZGF0ZSkge1xyXG4gIGNvbnN0IHllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XHJcbiAgY29uc3QgbW9udGggPSBTdHJpbmcoZGF0ZS5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgJzAnKTtcclxuICBjb25zdCBkYXkgPSBTdHJpbmcoZGF0ZS5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fWA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRlZmF1bHRSYW5nZSgpIHtcclxuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gIHJldHVybiB7XHJcbiAgICBmcm9tOiB0b0lTT0RhdGUobmV3IERhdGUobm93LmdldEZ1bGxZZWFyKCksIG5vdy5nZXRNb250aCgpLCAxKSksXHJcbiAgICB0bzogdG9JU09EYXRlKG5vdyksXHJcbiAgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0UGVyaW9kUmFuZ2UocGVyaW9kKSB7XHJcbiAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICBzd2l0Y2ggKHBlcmlvZCkge1xyXG4gICAgY2FzZSAnbWluZ2d1LWluaSc6IHtcclxuICAgICAgY29uc3QgZGF5T2ZXZWVrID0gbm93LmdldERheSgpO1xyXG4gICAgICBjb25zdCBzdGFydE9mV2VlayA9IG5ldyBEYXRlKG5vdyk7XHJcbiAgICAgIHN0YXJ0T2ZXZWVrLnNldERhdGUobm93LmdldERhdGUoKSAtIGRheU9mV2Vlayk7XHJcbiAgICAgIHJldHVybiB7IGZyb206IHRvSVNPRGF0ZShzdGFydE9mV2VlayksIHRvOiB0b0lTT0RhdGUobm93KSB9O1xyXG4gICAgfVxyXG4gICAgY2FzZSAnYnVsYW4taW5pJzpcclxuICAgICAgcmV0dXJuIHsgZnJvbTogdG9JU09EYXRlKG5ldyBEYXRlKG5vdy5nZXRGdWxsWWVhcigpLCBub3cuZ2V0TW9udGgoKSwgMSkpLCB0bzogdG9JU09EYXRlKG5vdykgfTtcclxuICAgIGNhc2UgJ3RhaHVuLWluaSc6XHJcbiAgICAgIHJldHVybiB7IGZyb206IHRvSVNPRGF0ZShuZXcgRGF0ZShub3cuZ2V0RnVsbFllYXIoKSwgMCwgMSkpLCB0bzogdG9JU09EYXRlKG5vdykgfTtcclxuICAgIGNhc2UgJ3NlbXVhJzpcclxuICAgICAgcmV0dXJuIHsgZnJvbTogJycsIHRvOiAnJyB9O1xyXG4gICAgZGVmYXVsdDpcclxuICAgICAgcmV0dXJuIGRlZmF1bHRSYW5nZSgpO1xyXG4gIH1cclxufVxyXG5cclxuY29uc3QgREFURV9GTVQgPSBuZXcgSW50bC5EYXRlVGltZUZvcm1hdCgnaWQtSUQnLCB7XHJcbiAgZGF5OiAnbnVtZXJpYycsXHJcbiAgbW9udGg6ICdzaG9ydCcsXHJcbiAgeWVhcjogJ251bWVyaWMnLFxyXG59KTtcclxuXHJcbmZ1bmN0aW9uIGZvcm1hdERhdGUoaXNvKSB7XHJcbiAgaWYgKCFpc28pIHJldHVybiAnLSc7XHJcbiAgcmV0dXJuIERBVEVfRk1ULmZvcm1hdChuZXcgRGF0ZShpc28pKTtcclxufVxyXG5cclxuZnVuY3Rpb24gU3RhdHVzQmFkZ2UoeyBzdGF0dXMgfSkge1xyXG4gIHJldHVybiA8QmFkZ2UgdmFyaWFudD17U1RBVFVTX1ZBUklBTlRbc3RhdHVzXSB8fCAnbmV1dHJhbCd9PntzdGF0dXN9PC9CYWRnZT47XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFRpbWVsaW5lRG90KHsgdmFyaWFudCwgaXNMYXRlc3QgfSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3BhblxyXG4gICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxyXG4gICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSAtbGVmdC1bOXB4XSB0b3AtMSBoLTQgdy00IHJvdW5kZWQtZnVsbCBib3JkZXItMiBiZy13aGl0ZSAke1xyXG4gICAgICAgIERPVF9CT1JERVJbdmFyaWFudF1cclxuICAgICAgfSAke2lzTGF0ZXN0ID8gRE9UX0ZJTExbdmFyaWFudF0gOiAnJ31gfVxyXG4gICAgLz5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBEZXRhaWxNb2RhbCh7IG9wZW4sIG9uQ2xvc2UsIHJvdyB9KSB7XHJcbiAgY29uc3QgW2VudHJpZXMsIHNldEVudHJpZXNdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IFtwaGFzZXMsIHNldFBoYXNlc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3Nob3dVcGRhdGUsIHNldFNob3dVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt1cGRhdGVQaGFzZSwgc2V0VXBkYXRlUGhhc2VdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFt1cGRhdGVTdGF0dXMsIHNldFVwZGF0ZVN0YXR1c10gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3VwZGF0ZURhdGUsIHNldFVwZGF0ZURhdGVdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFt1cGRhdGVFcnJvcnMsIHNldFVwZGF0ZUVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3VwZGF0aW5nLCBzZXRVcGRhdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IHsgc2hvd1RvYXN0IH0gPSB1c2VUb2FzdCgpO1xyXG5cclxuICBmdW5jdGlvbiBsb2FkSGlzdG9yeSgpIHtcclxuICAgIGlmICghcm93KSByZXR1cm47XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICBnZXRUYXNrSGlzdG9yeShyb3cudGFza19pZClcclxuICAgICAgLnRoZW4oKHJlcykgPT4gc2V0RW50cmllcyhyZXMuZGF0YSkpXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBzZXRFcnJvcihlcnI/Lm1lc3NhZ2UgfHwgJ1RlcmphZGkga2VzYWxhaGFuIHRhayB0ZXJkdWdhLicpKVxyXG4gICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSk7XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFvcGVuIHx8ICFyb3cpIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICBsb2FkSGlzdG9yeSgpO1xyXG4gICAgc2V0VXBkYXRlUGhhc2Uocm93LnBoYXNlKTtcclxuICAgIHNldFVwZGF0ZVN0YXR1cyhyb3cuc3RhdHVzKTtcclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IHkgPSB0b2RheS5nZXRGdWxsWWVhcigpO1xyXG4gICAgY29uc3QgbSA9IFN0cmluZyh0b2RheS5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgJzAnKTtcclxuICAgIGNvbnN0IGQgPSBTdHJpbmcodG9kYXkuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgc2V0VXBkYXRlRGF0ZShgJHt5fS0ke219LSR7ZH1gKTtcclxuICAgIHNldFNob3dVcGRhdGUoZmFsc2UpO1xyXG4gICAgc2V0VXBkYXRlRXJyb3JzKHt9KTtcclxuICAgIHJldHVybiAoKSA9PiB7fTtcclxuICB9LCBbb3Blbiwgcm93XSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIW9wZW4pIHJldHVybjtcclxuICAgIGdldFBoYXNlcygpXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHNldFBoYXNlcyhyZXMuZGF0YSkpXHJcbiAgICAgIC5jYXRjaCgoKSA9PiB7fSk7XHJcbiAgfSwgW29wZW5dKTtcclxuXHJcbiAgY29uc3Qgc3RhdHVzT3B0aW9ucyA9IHVwZGF0ZVBoYXNlID8gcGhhc2VzW3VwZGF0ZVBoYXNlXSA/PyBbXSA6IFtdO1xyXG5cclxuICBmdW5jdGlvbiBoYW5kbGVQaGFzZUNoYW5nZShlKSB7XHJcbiAgICBjb25zdCB2YWwgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIHNldFVwZGF0ZVBoYXNlKHZhbCk7XHJcbiAgICBpZiAodmFsICYmICFwaGFzZXNbdmFsXT8uaW5jbHVkZXModXBkYXRlU3RhdHVzKSkge1xyXG4gICAgICBzZXRVcGRhdGVTdGF0dXMoJycpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlU3VibWl0VXBkYXRlKCkge1xyXG4gICAgY29uc3QgZXJycyA9IHt9O1xyXG4gICAgaWYgKCF1cGRhdGVQaGFzZSkgZXJycy5waGFzZSA9ICdQaWxpaCBwaGFzZSc7XHJcbiAgICBpZiAoIXVwZGF0ZVN0YXR1cykgZXJycy5zdGF0dXMgPSAnUGlsaWggc3RhdHVzJztcclxuICAgIGlmICghdXBkYXRlRGF0ZSkgZXJycy5kYXRlID0gJ1BpbGloIHRhbmdnYWwnO1xyXG4gICAgc2V0VXBkYXRlRXJyb3JzKGVycnMpO1xyXG4gICAgaWYgKE9iamVjdC5rZXlzKGVycnMpLmxlbmd0aCA+IDApIHJldHVybjtcclxuXHJcbiAgICBzZXRVcGRhdGluZyh0cnVlKTtcclxuICAgIHVwZGF0ZVRhc2tQcm9ncmVzcyhyb3cudGFza19pZCwge1xyXG4gICAgICBwaGFzZTogdXBkYXRlUGhhc2UsXHJcbiAgICAgIHN0YXR1czogdXBkYXRlU3RhdHVzLFxyXG4gICAgICBkYXRlOiB1cGRhdGVEYXRlLFxyXG4gICAgfSlcclxuICAgICAgLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgIHNob3dUb2FzdCh7IHR5cGU6ICdzdWNjZXNzJywgdGl0bGU6ICdCZXJoYXNpbCcsIG1lc3NhZ2U6ICdQcm9ncmVzcyBiZXJoYXNpbCBkaXBlcmJhcnVpJyB9KTtcclxuICAgICAgICBzZXRTaG93VXBkYXRlKGZhbHNlKTtcclxuICAgICAgICBsb2FkSGlzdG9yeSgpO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICAgIHNob3dUb2FzdCh7XHJcbiAgICAgICAgICB0eXBlOiAnZXJyb3InLFxyXG4gICAgICAgICAgdGl0bGU6ICdHYWdhbCcsXHJcbiAgICAgICAgICBtZXNzYWdlOiBlcnIuc3RhdHVzID09PSA0MDkgPyAnUHJvZ3Jlc3MgdW50dWsgdGFuZ2dhbCBpbmkgc3VkYWggYWRhJyA6IChlcnIubWVzc2FnZSB8fCAnVGVyamFkaSBrZXNhbGFoYW4nKSxcclxuICAgICAgICB9KTtcclxuICAgICAgfSlcclxuICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0VXBkYXRpbmcoZmFsc2UpKTtcclxuICB9XHJcblxyXG4gIGNvbnN0IGxhc3RVcGRhdGVkID0gZW50cmllcz8ubGVuZ3RoID8gZW50cmllc1tlbnRyaWVzLmxlbmd0aCAtIDFdLmRhdGUgOiBudWxsO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE1vZGFsIG9wZW49e29wZW59IG9uQ2xvc2U9e29uQ2xvc2V9IHRpdGxlPXtyb3cgPyByb3cudGFzayA6ICdEZXRhaWwgVGFzayd9IHNpemU9XCJsZ1wiPlxyXG4gICAgICB7cm93ICYmIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgPGRsIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLXgtNiBnYXAteS0zIHNtOmdyaWQtY29scy01XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5LYXJ5YXdhbjwvZHQ+XHJcbiAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTAuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwXCI+e3Jvdy5lbXBsb3llZX08L2RkPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPkNsaWNrVXAgSUQ8L2R0PlxyXG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0wLjUgZm9udC1tb25vIHRleHQteHMgdGV4dC1zbGF0ZS03MDBcIj57cm93LmNsaWNrdXBfdGFza19pZH08L2RkPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlBoYXNlIHNhYXQgaW5pPC9kdD5cclxuICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwXCI+e3Jvdy5waGFzZX08L2RkPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlN0YXR1cyBzYWF0IGluaTwvZHQ+XHJcbiAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTFcIj5cclxuICAgICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSBzdGF0dXM9e3Jvdy5zdGF0dXN9IC8+XHJcbiAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5MYXN0IFVwZGF0ZWQ8L2R0PlxyXG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0wLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge2xhc3RVcGRhdGVkID8gZm9ybWF0RGF0ZShsYXN0VXBkYXRlZCkgOiAnLSd9XHJcbiAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2RsPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIHB0LTVcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgIFJpd2F5YXQgUHJvZ3Jlc3NcclxuICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAge2xvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHktMTBcIiByb2xlPVwic3RhdHVzXCIgYXJpYS1idXN5PVwidHJ1ZVwiPlxyXG4gICAgICAgICAgICAgICAgPExvYWRpbmcgc2l6ZT1cIm1kXCIgLz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS01MDBcIj5NZW11YXQgcml3YXlhdCBwcm9ncmVzc+KApjwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHshbG9hZGluZyAmJiBlcnJvciAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMyBweS04XCIgcm9sZT1cImFsZXJ0XCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcn08L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFJpd2F5YXQgcHJvZ3Jlc3MgdGlkYWsgZGFwYXQgZGltdWF0LlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e2xvYWRIaXN0b3J5fT5cclxuICAgICAgICAgICAgICAgICAgQ29iYSBMYWdpXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHshbG9hZGluZyAmJiAhZXJyb3IgJiYgZW50cmllcyAmJiBlbnRyaWVzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxvbCBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtbC0yIG10LTQgYm9yZGVyLWwtMiBib3JkZXItc2xhdGUtMTAwXCIgYXJpYS1sYWJlbD1cIlJpd2F5YXQgcHJvZ3Jlc3NcIj5cclxuICAgICAgICAgICAgICAgIHtlbnRyaWVzLm1hcCgoZW50cnksIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHZhcmlhbnQgPSBTVEFUVVNfVkFSSUFOVFtlbnRyeS5zdGF0dXNdIHx8ICduZXV0cmFsJztcclxuICAgICAgICAgICAgICAgICAgY29uc3QgaXNMYXRlc3QgPSBpbmRleCA9PT0gZW50cmllcy5sZW5ndGggLSAxO1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBwcmV2RW50cnkgPSBpbmRleCA+IDAgPyBlbnRyaWVzW2luZGV4IC0gMV0gOiBudWxsO1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBwaGFzZUNoYW5nZWQgPSBwcmV2RW50cnkgJiYgcHJldkVudHJ5LnBoYXNlICE9PSBlbnRyeS5waGFzZTtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICA8RnJhZ21lbnQga2V5PXtgJHtlbnRyeS5kYXRlfS0ke2VudHJ5LnN0YXR1c31gfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwaGFzZUNoYW5nZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwicmVsYXRpdmUgcGItMyBwbC03XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWxlZnQtWzlweF0gdG9wLTEgaC00IHctNCByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXNsYXRlLTUwIHB4LTIgcHktMC41IHRleHQtWzEwcHhdIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGhhc2U6IHtwcmV2RW50cnkucGhhc2V9IOKGkiB7ZW50cnkucGhhc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9e2ByZWxhdGl2ZSAke3BoYXNlQ2hhbmdlZCA/ICdwdC0xJyA6ICcnfSBwYi02IHBsLTcgbGFzdDpwYi0xYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUaW1lbGluZURvdCB2YXJpYW50PXt2YXJpYW50fSBpc0xhdGVzdD17aXNMYXRlc3R9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXNtICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTGF0ZXN0ID8gJ2ZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDAnIDogJ3RleHQtc2xhdGUtNjAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUoZW50cnkuZGF0ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+e2VudHJ5LnBoYXNlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSBzdGF0dXM9e2VudHJ5LnN0YXR1c30gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNMYXRlc3QgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPktvbmRpc2kgdGVyYWtoaXIgdHVnYXMgaW5pLjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9GcmFnbWVudD5cclxuICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIDwvb2w+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7IWxvYWRpbmcgJiYgIWVycm9yICYmIGVudHJpZXMgJiYgZW50cmllcy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInB5LTYgdGV4dC1zbSB0ZXh0LXNsYXRlLTUwMFwiPlRhc2sgaW5pIGJlbHVtIG1lbWlsaWtpIHJpd2F5YXQgcHJvZ3Jlc3MgeWFuZyB0ZXJjYXRhdC48L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7c2hvd1VwZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgYmctYmx1ZS01MCBwLTRcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0zIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgVXBkYXRlIFByb2dyZXNzXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMyBzbTpncmlkLWNvbHMtM1wiPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIlBoYXNlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQaWxpaCBwaGFzZVwiXHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e09iamVjdC5rZXlzKHBoYXNlcykubWFwKChwKSA9PiAoeyB2YWx1ZTogcCwgbGFiZWw6IHAgfSkpfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlUGhhc2V9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQaGFzZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgZXJyb3I9e3VwZGF0ZUVycm9ycy5waGFzZX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiU3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3VwZGF0ZVBoYXNlID8gJ1BpbGloIHN0YXR1cycgOiAnUGlsaWggcGhhc2UgZHVsdSd9XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e3N0YXR1c09wdGlvbnMubWFwKChzKSA9PiAoeyB2YWx1ZTogcywgbGFiZWw6IHMgfSkpfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlU3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHsgc2V0VXBkYXRlU3RhdHVzKGUudGFyZ2V0LnZhbHVlKTsgc2V0VXBkYXRlRXJyb3JzKChwKSA9PiAoeyAuLi5wLCBzdGF0dXM6IHVuZGVmaW5lZCB9KSk7IH19XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshdXBkYXRlUGhhc2V9XHJcbiAgICAgICAgICAgICAgICAgIGVycm9yPXt1cGRhdGVFcnJvcnMuc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiVGFuZ2dhbFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVEYXRlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHsgc2V0VXBkYXRlRGF0ZShlLnRhcmdldC52YWx1ZSk7IHNldFVwZGF0ZUVycm9ycygocCkgPT4gKHsgLi4ucCwgZGF0ZTogdW5kZWZpbmVkIH0pKTsgfX1cclxuICAgICAgICAgICAgICAgICAgZXJyb3I9e3VwZGF0ZUVycm9ycy5kYXRlfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgdmFyaWFudD1cIm91dGxpbmVcIiBzaXplPVwic21cIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93VXBkYXRlKGZhbHNlKX0+XHJcbiAgICAgICAgICAgICAgICAgIEJhdGFsXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIHNpemU9XCJzbVwiIGxvYWRpbmc9e3VwZGF0aW5nfSBvbkNsaWNrPXtoYW5kbGVTdWJtaXRVcGRhdGV9PlxyXG4gICAgICAgICAgICAgICAgICBTaW1wYW4gUHJvZ3Jlc3NcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXgganVzdGlmeS1lbmQgZ2FwLTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBwdC00XCI+XHJcbiAgICAgICAgICAgIHshc2hvd1VwZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dVcGRhdGUodHJ1ZSl9PlxyXG4gICAgICAgICAgICAgICAgVXBkYXRlIFByb2dyZXNzXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXtvbkNsb3NlfT5cclxuICAgICAgICAgICAgICBUdXR1cFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG4gICAgPC9Nb2RhbD5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIaXN0b3J5UGFnZSgpIHtcclxuICBjb25zdCBpbml0aWFsUmFuZ2UgPSB1c2VNZW1vKGRlZmF1bHRSYW5nZSwgW10pO1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlSWQsIHNldEVtcGxveWVlSWRdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtmcm9tLCBzZXRGcm9tXSA9IHVzZVN0YXRlKGluaXRpYWxSYW5nZS5mcm9tKTtcclxuICBjb25zdCBbdG8sIHNldFRvXSA9IHVzZVN0YXRlKGluaXRpYWxSYW5nZS50byk7XHJcbiAgY29uc3QgW3NlYXJjaCwgc2V0U2VhcmNoXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbZGVib3VuY2VkU2VhcmNoLCBzZXREZWJvdW5jZWRTZWFyY2hdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFthY3RpdmVQZXJpb2QsIHNldEFjdGl2ZVBlcmlvZF0gPSB1c2VTdGF0ZSgnYnVsYW4taW5pJyk7XHJcblxyXG4gIGNvbnN0IFtyb3dzLCBzZXRSb3dzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICBjb25zdCBbc2VsZWN0ZWRSb3csIHNldFNlbGVjdGVkUm93XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtleHBvcnRpbmcsIHNldEV4cG9ydGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgeyBzaG93VG9hc3QgfSA9IHVzZVRvYXN0KCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XHJcbiAgICBnZXRFbXBsb3llZXMoKVxyXG4gICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHNldEVtcGxveWVlcyhyZXMuZGF0YSk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoKSA9PiB7fSk7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBjYW5jZWxsZWQgPSB0cnVlO1xyXG4gICAgfTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGZ1bmN0aW9uIGxvYWRIaXN0b3J5KCkge1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgZ2V0SGlzdG9yeSh7IGVtcGxveWVlX2lkOiBlbXBsb3llZUlkIHx8IHVuZGVmaW5lZCwgZnJvbTogZnJvbSB8fCB1bmRlZmluZWQsIHRvOiB0byB8fCB1bmRlZmluZWQgfSlcclxuICAgICAgLnRoZW4oKHJlcykgPT4gc2V0Um93cyhyZXMuZGF0YSkpXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBzZXRFcnJvcihlcnI/Lm1lc3NhZ2UgfHwgJ1RlcmphZGkga2VzYWxhaGFuIHRhayB0ZXJkdWdhLicpKVxyXG4gICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSk7XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbG9hZEhpc3RvcnkoKTtcclxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcclxuICB9LCBbZW1wbG95ZWVJZCwgZnJvbSwgdG9dKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBzZXREZWJvdW5jZWRTZWFyY2goc2VhcmNoKSwgMzAwKTtcclxuICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQodGltZXIpO1xyXG4gIH0sIFtzZWFyY2hdKTtcclxuXHJcbiAgY29uc3QgZGF0ZUludmFsaWQgPSBCb29sZWFuKGZyb20gJiYgdG8gJiYgZnJvbSA+IHRvKTtcclxuXHJcbiAgY29uc3QgZW1wbG95ZWVOYW1lID0gZW1wbG95ZWVzLmZpbmQoKGUpID0+IFN0cmluZyhlLmlkKSA9PT0gZW1wbG95ZWVJZCk/Lm5hbWU7XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBxdWVyeSA9IGRlYm91bmNlZFNlYXJjaC50cmltKCkudG9Mb3dlckNhc2UoKTtcclxuICAgIHJldHVybiByb3dzXHJcbiAgICAgIC5maWx0ZXIoKHJvdykgPT4ge1xyXG4gICAgICAgIGlmIChlbXBsb3llZU5hbWUgJiYgcm93LmVtcGxveWVlICE9PSBlbXBsb3llZU5hbWUpIHJldHVybiBmYWxzZTtcclxuICAgICAgICBpZiAoZnJvbSAmJiByb3cuZGF0ZSA8IGZyb20pIHJldHVybiBmYWxzZTtcclxuICAgICAgICBpZiAodG8gJiYgcm93LmRhdGUgPiB0bykgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIGlmIChxdWVyeSkge1xyXG4gICAgICAgICAgY29uc3QgaGF5c3RhY2sgPSBgJHtyb3cudGFza30gJHtyb3cuY2xpY2t1cF90YXNrX2lkfSAke3Jvdy5lbXBsb3llZX0gJHtyb3cucGhhc2V9ICR7cm93LnN0YXR1c31gLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICBpZiAoIWhheXN0YWNrLmluY2x1ZGVzKHF1ZXJ5KSkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgfSlcclxuICAgICAgLnNvcnQoKGEsIGIpID0+IGIuZGF0ZS5sb2NhbGVDb21wYXJlKGEuZGF0ZSkpO1xyXG4gIH0sIFtyb3dzLCBlbXBsb3llZU5hbWUsIGZyb20sIHRvLCBkZWJvdW5jZWRTZWFyY2hdKTtcclxuXHJcbiAgY29uc3QgaGFzQWN0aXZlRmlsdGVyID1cclxuICAgIEJvb2xlYW4oZW1wbG95ZWVJZCkgfHxcclxuICAgIEJvb2xlYW4oc2VhcmNoLnRyaW0oKSkgfHxcclxuICAgIGFjdGl2ZVBlcmlvZCAhPT0gJ2J1bGFuLWluaScgfHxcclxuICAgIGZyb20gIT09IGluaXRpYWxSYW5nZS5mcm9tIHx8XHJcbiAgICB0byAhPT0gaW5pdGlhbFJhbmdlLnRvO1xyXG5cclxuICBmdW5jdGlvbiByZXNldEZpbHRlcnMoKSB7XHJcbiAgICBzZXRFbXBsb3llZUlkKCcnKTtcclxuICAgIHNldFNlYXJjaCgnJyk7XHJcbiAgICBzZXREZWJvdW5jZWRTZWFyY2goJycpO1xyXG4gICAgc2V0QWN0aXZlUGVyaW9kKCdidWxhbi1pbmknKTtcclxuICAgIHNldEZyb20oaW5pdGlhbFJhbmdlLmZyb20pO1xyXG4gICAgc2V0VG8oaW5pdGlhbFJhbmdlLnRvKTtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGhhbmRsZVBlcmlvZENoYW5nZShwZXJpb2QpIHtcclxuICAgIHNldEFjdGl2ZVBlcmlvZChwZXJpb2QpO1xyXG4gICAgY29uc3QgcmFuZ2UgPSBnZXRQZXJpb2RSYW5nZShwZXJpb2QpO1xyXG4gICAgc2V0RnJvbShyYW5nZS5mcm9tKTtcclxuICAgIHNldFRvKHJhbmdlLnRvKTtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIG9wZW5EZXRhaWwocm93KSB7XHJcbiAgICBzZXRTZWxlY3RlZFJvdyhyb3cpO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlUm93Q2xpY2soZXZlbnQsIHJvdykge1xyXG4gICAgaWYgKGV2ZW50LnRhcmdldC5jbG9zZXN0KCdidXR0b24nKSkgcmV0dXJuO1xyXG4gICAgb3BlbkRldGFpbChyb3cpO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlRXhwb3J0KCkge1xyXG4gICAgc2V0RXhwb3J0aW5nKHRydWUpO1xyXG4gICAgZXhwb3J0SGlzdG9yeSh7IGVtcGxveWVlX2lkOiBlbXBsb3llZUlkIHx8IHVuZGVmaW5lZCwgZnJvbTogZnJvbSB8fCB1bmRlZmluZWQsIHRvOiB0byB8fCB1bmRlZmluZWQgfSlcclxuICAgICAgLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgIHNob3dUb2FzdCh7IHR5cGU6ICdzdWNjZXNzJywgdGl0bGU6ICdFa3Nwb3Igc2VsZXNhaScsIG1lc3NhZ2U6ICdGaWxlIGJlcmhhc2lsIGRpdW5kdWguJyB9KTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICBzaG93VG9hc3QoeyB0eXBlOiAnZXJyb3InLCB0aXRsZTogJ0dhZ2FsIG1lbmdla3Nwb3InLCBtZXNzYWdlOiBlcnI/Lm1lc3NhZ2UgfHwgJ1RlcmphZGkga2VzYWxhaGFuIHRhayB0ZXJkdWdhLicgfSk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5maW5hbGx5KCgpID0+IHNldEV4cG9ydGluZyhmYWxzZSkpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTUwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy01eGwgcHgtNCBweS02IHNtOnB4LTggc206cHktOFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPkhpc3Rvcnk8L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICBSZWthcCBwcm9ncmVzIExTUFBUIGhhcmlhbiBzZW11YSBrYXJ5YXdhbi5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YSBocmVmPVwiL3N1Ym1pdFwiIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ibHVlLTYwMCBob3Zlcjp1bmRlcmxpbmVcIj5cclxuICAgICAgICAgICAgJmxhcnI7IEtlbWJhbGkga2UgU3VibWl0XHJcbiAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm10LTYgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSBwLTQgc2hhZG93LXNtIHNtOnAtNlwiPlxyXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9eyhlKSA9PiBlLnByZXZlbnREZWZhdWx0KCl9IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTQgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLVsxZnJfMWZyXzFmcl8xLjRmcl9hdXRvXSBsZzppdGVtcy1lbmRcIj5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiS2FyeWF3YW5cIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VtdWEga2FyeWF3YW5cIlxyXG4gICAgICAgICAgICAgIG9wdGlvbnM9e2VtcGxveWVlcy5tYXAoKGUpID0+ICh7IHZhbHVlOiBTdHJpbmcoZS5pZCksIGxhYmVsOiBlLm5hbWUgfSkpfVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtlbXBsb3llZUlkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1wbG95ZWVJZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJEYXJpIFRhbmdnYWxcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtmcm9tfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0RnJvbShlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICBzZXRBY3RpdmVQZXJpb2QoJ2N1c3RvbScpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgbWF4PXt0byB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgZXJyb3I9e2RhdGVJbnZhbGlkID8gJ0xlYmloIGJlc2FyIGRhcmkgdGFuZ2dhbCBha2hpcicgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJTYW1wYWkgVGFuZ2dhbFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3RvfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0VG8oZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgc2V0QWN0aXZlUGVyaW9kKCdjdXN0b20nKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIG1pbj17ZnJvbSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgZXJyb3I9e2RhdGVJbnZhbGlkID8gJ0xlYmloIGtlY2lsIGRhcmkgdGFuZ2dhbCBtdWxhaScgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiQ2FyaVwiXHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ2FyaSB0dWdhcyBhdGF1IENsaWNrVXAgSUTigKZcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2h9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2goZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICB7aGFzQWN0aXZlRmlsdGVyICYmIChcclxuICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e3Jlc2V0RmlsdGVyc30+XHJcbiAgICAgICAgICAgICAgICBSZXNldCBGaWx0ZXJcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm10LTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSBzaGFkb3ctc21cIj5cclxuICAgICAgICAgIHshbG9hZGluZyAmJiAhZXJyb3IgJiYgIWRhdGVJbnZhbGlkICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgcHgtNCBweS0zIHNtOnB4LTZcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICB7ZmlsdGVyZWQubGVuZ3RofSBlbnRyaSBkaXRlbXVrYW5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gc206ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcm91bmRlZC1sZyBiZy1zbGF0ZS0xMDAgcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhUSU1FX1BFUklPRFMpLm1hcCgoW2tleSwgbGFiZWxdKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtrZXl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBlcmlvZENoYW5nZShrZXkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcm91bmRlZC1tZCBweC0zIHB5LTEgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWNlbnRlciBtaW4tdy1bNzJweF0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlUGVyaW9kID09PSBrZXlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSB0ZXh0LXNsYXRlLTgwMCBzaGFkb3ctc20nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2BoaWRkZW4gdGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBsZzpibG9jayBtaW4tdy1bMTQwcHhdIHRleHQtcmlnaHQgJHshKGZyb20gfHwgdG8pICYmICdpbnZpc2libGUnfWB9PlxyXG4gICAgICAgICAgICAgICAgICB7ZnJvbSB8fCB0byA/IGAke2Zvcm1hdERhdGUoZnJvbSl9IOKAkyAke2Zvcm1hdERhdGUodG8pfWAgOiAnXFx1MDBBMCd9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcclxuICAgICAgICAgICAgICAgICAgbG9hZGluZz17ZXhwb3J0aW5nfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGF0ZUludmFsaWQgfHwgbG9hZGluZyB8fCBmaWx0ZXJlZC5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUV4cG9ydH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRXhwb3J0IEV4Y2VsXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHtkYXRlSW52YWxpZCA/IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLVsyODBweF0gZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB4LTYgcHktMTIgdGV4dC1jZW50ZXJcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cImgtMTAgdy0xMCB0ZXh0LWFtYmVyLTQwMFwiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMS41XCI+XHJcbiAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgZD1cIk0xMiA5djMuNzVtLTkuMzAzIDMuMzc2Yy0uODY2IDEuNS4yMTcgMy4zNzQgMS45NDggMy4zNzRoMTQuNzFjMS43MyAwIDIuODEzLTEuODc0IDEuOTQ4LTMuMzc0TDEzLjk0OSAzLjM3OGMtLjg2Ni0xLjUtMy4wMzItMS41LTMuODk4IDBMMi42OTcgMTYuMTI2ek0xMiAxNS43NWguMDA3di4wMDhIMTJ2LS4wMDh6XCIgLz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+UmVudGFuZyB0YW5nZ2FsIHRpZGFrIHZhbGlkPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1heC13LXhzIHRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgIFRhbmdnYWwgYWtoaXIgbGViaWggYXdhbCBkYXJpIHRhbmdnYWwgbXVsYWkuIFNlc3VhaWthbiBzYWxhaCBzYXR1IHRhbmdnYWwgdW50dWsgbWVsaWhhdCBoaXN0b3J5LlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApIDogbG9hZGluZyA/IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLVsyODBweF0gZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zIHB4LTYgcHktMTJcIiByb2xlPVwic3RhdHVzXCIgYXJpYS1idXN5PVwidHJ1ZVwiPlxyXG4gICAgICAgICAgICAgIDxMb2FkaW5nIHNpemU9XCJsZ1wiIC8+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMFwiPk1lbXVhdCByaXdheWF04oCmPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiBlcnJvciA/IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLVsyODBweF0gZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zIHB4LTYgcHktMTIgdGV4dC1jZW50ZXJcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cImgtMTAgdy0xMCB0ZXh0LXJlZC00MDBcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjEuNVwiPlxyXG4gICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIGQ9XCJNMTIgOXYzLjc1bTAgMy43NWguMDA4di4wMDhIMTJtLTkuMzAzLTMuMzgyYy0uODY2IDEuNS4yMTcgMy4zNzQgMS45NDggMy4zNzRoMTQuNzFjMS43MyAwIDIuODEzLTEuODc0IDEuOTQ4LTMuMzc0TDEzLjk0OSAzLjM3OGMtLjg2Ni0xLjUtMy4wMzItMS41LTMuODk4IDBMMi42OTcgMTYuMTI2ek0xMiAxNS43NWguMDA3di4wMDhIMTJ2LS4wMDh6XCIgLz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+R2FnYWwgbWVtdWF0IGRhdGE8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWF4LXcteHMgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPntlcnJvcn08L3A+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e2xvYWRIaXN0b3J5fT5cclxuICAgICAgICAgICAgICAgIENvYmEgTGFnaVxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiBmaWx0ZXJlZC5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHNtOnAtNlwiPlxyXG4gICAgICAgICAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkJlbHVtIGFkYSBkYXRhIHlhbmcgY29jb2tcIlxyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb249XCJUaWRhayBhZGEgZW50cmkgaGlzdG9yeSBzZXN1YWkgZmlsdGVyIHNhYXQgaW5pLiBDb2JhIHViYWgga2FyeWF3YW4sIHJlbnRhbmcgdGFuZ2dhbCwgYXRhdSBrYXRhIGt1bmNpIHBlbmNhcmlhbi5cIlxyXG4gICAgICAgICAgICAgICAgYWN0aW9uPXtcclxuICAgICAgICAgICAgICAgICAgaGFzQWN0aXZlRmlsdGVyID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXtyZXNldEZpbHRlcnN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgUmVzZXQgRmlsdGVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICkgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgPFRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LVs3NjBweF1cIj5cclxuICAgICAgICAgICAgICAgIDxUSGVhZD5cclxuICAgICAgICAgICAgICAgICAgPFRyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUaD5LYXJ5YXdhbjwvVGg+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRoPlRhbmdnYWw8L1RoPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUaD5UdWdhczwvVGg+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRoPkNsaWNrVXAgSUQ8L1RoPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUaD5QaGFzZTwvVGg+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRoPlN0YXR1czwvVGg+XHJcbiAgICAgICAgICAgICAgICAgIDwvVHI+XHJcbiAgICAgICAgICAgICAgICA8L1RIZWFkPlxyXG4gICAgICAgICAgICAgICAgPFRCb2R5PlxyXG4gICAgICAgICAgICAgICAgICB7ZmlsdGVyZWQubWFwKChyb3cpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8VHJcclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17cm93LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdGFiSW5kZXg9ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgQnVrYSBkZXRhaWwgdHVnYXMgJHtyb3cudGFza31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZVJvd0NsaWNrKGUsIHJvdyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbktleURvd249eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gJ0VudGVyJyB8fCBlLmtleSA9PT0gJyAnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wZW5EZXRhaWwocm93KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBob3ZlcjpiZy1zbGF0ZS01MCBmb2N1cy12aXNpYmxlOmJnLWJsdWUtNTAvNjAgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTotb3V0bGluZS1vZmZzZXQtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUZCBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLW5vd3JhcCBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMFwiPntyb3cuZW1wbG95ZWV9PC9UZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUZCBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLW5vd3JhcFwiPntmb3JtYXREYXRlKHJvdy5kYXRlKX08L1RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlbkRldGFpbChyb3cpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtbGVmdCBmb250LW1lZGl1bSB0ZXh0LWJsdWUtNjAwIGdyb3VwLWhvdmVyOnVuZGVybGluZSBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtb2Zmc2V0LTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIG1heC13LVsyNjBweF0gdHJ1bmNhdGVcIiB0aXRsZT17cm93LnRhc2t9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jvdy50YXNrfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRkIGNsYXNzTmFtZT1cIndoaXRlc3BhY2Utbm93cmFwIGZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtyb3cuY2xpY2t1cF90YXNrX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9UZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUZD57cm93LnBoYXNlfTwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSBzdGF0dXM9e3Jvdy5zdGF0dXN9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvVHI+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9UQm9keT5cclxuICAgICAgICAgICAgICA8L1RhYmxlPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxEZXRhaWxNb2RhbCBvcGVuPXtCb29sZWFuKHNlbGVjdGVkUm93KX0gb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWRSb3cobnVsbCl9IHJvdz17c2VsZWN0ZWRSb3d9IC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiL2FwcC9zcmMvcGFnZXMvSGlzdG9yeVBhZ2UuanN4In0=