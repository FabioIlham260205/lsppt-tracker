import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ComponentsPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f7470b49"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/pages/ComponentsPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f7470b49"; const useState = __vite__cjsImport3_react["useState"];
import {
  Button,
  Input,
  Select,
  DatePicker,
  Modal,
  Table,
  THead,
  TBody,
  Tr,
  Th,
  Td,
  Badge,
  ToastProvider,
  useToast,
  Loading,
  EmptyState
} from "/src/components/ui/index.js";
const PHASES = ["TS", "QA"];
const STATUSES = {
  TS: ["Completed", "Documentation", "On Hold", "In Progress", "Plan"],
  QA: [
    "Completed",
    "Completed Testing",
    "Completed with Feedback",
    "Testing",
    "On Queue Testing",
    "Plan"
  ]
};
function Section({ title, children }) {
  return /* @__PURE__ */ jsxDEV("section", { className: "rounded-xl border border-slate-200 bg-white p-6 shadow-sm", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "mb-4 text-lg font-semibold text-slate-800", children: title }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 56,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "/app/src/pages/ComponentsPage.jsx",
    lineNumber: 55,
    columnNumber: 5
  }, this);
}
_c = Section;
function DemoContent() {
  _s();
  const { showToast } = useToast();
  const [modalOpen, setModalOpen] = useState(false);
  const [phase, setPhase] = useState("");
  const [form, setForm] = useState({ title: "", url: "", date: "" });
  const [saving, setSaving] = useState(false);
  const statusVariant = {
    Completed: "success",
    "In Progress": "info",
    Testing: "warning",
    "On Hold": "danger",
    Plan: "neutral"
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-slate-100 p-8", children: /* @__PURE__ */ jsxDEV("div", { className: "mx-auto max-w-5xl space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-slate-800", children: "UI Components" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 82,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500", children: "Live preview semua komponen untuk tim (Fabio & Bagas)." }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 83,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 81,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("a", { href: "/submit", className: "text-sm text-blue-600 hover:underline", children: "← Back to /submit" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 87,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 80,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Button", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(Button, { children: "Primary" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 94,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", children: "Secondary" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 95,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "danger", children: "Danger" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 96,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "outline", children: "Outline" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 97,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { size: "sm", children: "Small" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 98,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { size: "lg", children: "Large" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 99,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { loading: true, children: "Loading" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 100,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { disabled: true, children: "Disabled" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 101,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 93,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 92,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Input / Select / DatePicker", children: /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 sm:grid-cols-3", children: [
      /* @__PURE__ */ jsxDEV(
        Input,
        {
          label: "Task Title",
          placeholder: "e.g. Fix login bug",
          value: form.title,
          onChange: (e) => setForm({ ...form, title: e.target.value })
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 107,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Select,
        {
          label: "Phase",
          placeholder: "Select phase",
          options: PHASES,
          value: phase,
          onChange: (e) => setPhase(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 113,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        DatePicker,
        {
          label: "Date",
          value: form.date,
          onChange: (e) => setForm({ ...form, date: e.target.value })
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 120,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Input,
        {
          label: "ClickUp URL",
          type: "url",
          placeholder: "https://app.clickup.com/t/...",
          error: "Invalid URL format"
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 125,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 106,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 105,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Modal", children: [
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => setModalOpen(true), children: "Open Modal" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 135,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          open: modalOpen,
          onClose: () => setModalOpen(false),
          title: "Confirm Save LSPPT",
          footer: /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: () => setModalOpen(false), children: "Cancel" }, void 0, false, {
              fileName: "/app/src/pages/ComponentsPage.jsx",
              lineNumber: 142,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { onClick: () => setModalOpen(false), children: "Save" }, void 0, false, {
              fileName: "/app/src/pages/ComponentsPage.jsx",
              lineNumber: 145,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 141,
            columnNumber: 13
          }, this),
          children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-600", children: "Are you sure you want to save this LSPPT entry? This action cannot be undone. Press ESC or click the overlay to close." }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 149,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 136,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 134,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Table", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-lg border border-slate-200", children: /* @__PURE__ */ jsxDEV(Table, { children: [
      /* @__PURE__ */ jsxDEV(THead, { children: /* @__PURE__ */ jsxDEV(Tr, { children: [
        /* @__PURE__ */ jsxDEV(Th, { children: "Task" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 161,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(Th, { children: "Phase" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 162,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(Th, { children: "Status" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 163,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(Th, { children: "Date" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 164,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 160,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 159,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(TBody, { children: [
        { task: "Fix login redirect", phase: "TS", status: "Completed", date: "2026-08-20" },
        { task: "Write API docs", phase: "TS", status: "Documentation", date: "2026-08-21" },
        { task: "Regression testing", phase: "QA", status: "Testing", date: "2026-08-22" }
      ].map(
        (row) => /* @__PURE__ */ jsxDEV(Tr, { children: [
          /* @__PURE__ */ jsxDEV(Td, { className: "font-medium", children: row.task }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 174,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Td, { children: row.phase }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 175,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV(Badge, { variant: statusVariant[row.status] || "neutral", children: row.status }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 177,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 176,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Td, { children: row.date }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 179,
            columnNumber: 21
          }, this)
        ] }, row.task, true, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 173,
          columnNumber: 17
        }, this)
      ) }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 167,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 158,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 157,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 156,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Badge", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
      /* @__PURE__ */ jsxDEV(Badge, { variant: "success", children: "Completed" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 189,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Badge, { variant: "info", children: "In Progress" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 190,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Badge, { variant: "warning", children: "Testing" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 191,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Badge, { variant: "danger", children: "On Hold" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 192,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Badge, { variant: "neutral", children: "Plan" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 193,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 188,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 187,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Toast", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outline",
          onClick: () => showToast({ type: "success", title: "Success", message: "LSPPT saved successfully." }),
          children: "Success toast"
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 199,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outline",
          onClick: () => showToast({ type: "error", title: "Error", message: "Failed to save. Try again." }),
          children: "Error toast"
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 207,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outline",
          onClick: () => showToast({ type: "info", message: "Auto-dismiss in 4 seconds." }),
          children: "Info toast"
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 215,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 198,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 197,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Loading", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
      /* @__PURE__ */ jsxDEV(Loading, { size: "sm" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 226,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Loading, { size: "md" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 227,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Loading, { size: "lg" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 228,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 225,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 224,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Empty State", children: /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        title: "No history found",
        description: "Try adjusting the employee filter or date range.",
        action: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", children: "Reset filter" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 236,
          columnNumber: 21
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 233,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 232,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Mini Form Demo (Button + Toast)", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex max-w-md items-end gap-3", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 space-y-3", children: [
        /* @__PURE__ */ jsxDEV(Input, { label: "Task Title", placeholder: "e.g. Fix login bug" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 243,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            label: "Status (dynamic per Phase)",
            placeholder: phase ? "Select status" : "Pick a Phase first",
            options: phase ? STATUSES[phase] : [],
            disabled: !phase
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 244,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 242,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 241,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex gap-2", children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          loading: saving,
          onClick: () => {
            setSaving(true);
            setTimeout(() => {
              setSaving(false);
              showToast({ type: "success", message: "Form submitted!" });
            }, 1200);
          },
          children: "Submit"
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 253,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 252,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 240,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/pages/ComponentsPage.jsx",
    lineNumber: 79,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/app/src/pages/ComponentsPage.jsx",
    lineNumber: 78,
    columnNumber: 5
  }, this);
}
_s(DemoContent, "4cmHjlGK970TmV425qDyIWkO+EE=", false, function() {
  return [useToast];
});
_c2 = DemoContent;
export default function ComponentsPage() {
  return /* @__PURE__ */ jsxDEV(ToastProvider, { children: /* @__PURE__ */ jsxDEV(DemoContent, {}, void 0, false, {
    fileName: "/app/src/pages/ComponentsPage.jsx",
    lineNumber: 275,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/app/src/pages/ComponentsPage.jsx",
    lineNumber: 274,
    columnNumber: 5
  }, this);
}
_c3 = ComponentsPage;
var _c, _c2, _c3;
$RefreshReg$(_c, "Section");
$RefreshReg$(_c2, "DemoContent");
$RefreshReg$(_c3, "ComponentsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/pages/ComponentsPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/pages/ComponentsPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NNLFNBcUZRLFVBckZSOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBDTixTQUFTQSxnQkFBZ0I7QUFDekI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBRVAsTUFBTUMsU0FBUyxDQUFDLE1BQU0sSUFBSTtBQUMxQixNQUFNQyxXQUFXO0FBQUEsRUFDZkMsSUFBSSxDQUFDLGFBQWEsaUJBQWlCLFdBQVcsZUFBZSxNQUFNO0FBQUEsRUFDbkVDLElBQUk7QUFBQSxJQUNGO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUFNO0FBRVY7QUFFQSxTQUFTQyxRQUFRLEVBQUVDLE9BQU9DLFNBQVMsR0FBRztBQUNwQyxTQUNFLHVCQUFDLGFBQVEsV0FBVSw2REFDakI7QUFBQSwyQkFBQyxRQUFHLFdBQVUsNkNBQTZDRCxtQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRTtBQUFBLElBQ2hFQztBQUFBQSxPQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNDLEtBUFFIO0FBU1QsU0FBU0ksY0FBYztBQUFBQyxLQUFBO0FBQ3JCLFFBQU0sRUFBRUMsVUFBVSxJQUFJYixTQUFTO0FBQy9CLFFBQU0sQ0FBQ2MsV0FBV0MsWUFBWSxJQUFJN0IsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzhCLE9BQU9DLFFBQVEsSUFBSS9CLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNnQyxNQUFNQyxPQUFPLElBQUlqQyxTQUFTLEVBQUVzQixPQUFPLElBQUlZLEtBQUssSUFBSUMsTUFBTSxHQUFHLENBQUM7QUFDakUsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlyQyxTQUFTLEtBQUs7QUFFMUMsUUFBTXNDLGdCQUFnQjtBQUFBLElBQ3BCQyxXQUFXO0FBQUEsSUFDWCxlQUFlO0FBQUEsSUFDZkMsU0FBUztBQUFBLElBQ1QsV0FBVztBQUFBLElBQ1hDLE1BQU07QUFBQSxFQUNSO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUNBQ2IsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsNkJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxRQUMvRCx1QkFBQyxPQUFFLFdBQVUsMEJBQXlCLHNFQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxNQUFLLFdBQVUsV0FBVSx5Q0FBd0MsaUNBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQSx1QkFBQyxXQUFRLE9BQU0sVUFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSw2QkFBQyxVQUFPLHVCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsVUFBTyxTQUFRLGFBQVkseUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxNQUNyQyx1QkFBQyxVQUFPLFNBQVEsVUFBUyxzQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLE1BQy9CLHVCQUFDLFVBQU8sU0FBUSxXQUFVLHVCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsVUFBTyxNQUFLLE1BQUsscUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUI7QUFBQSxNQUN2Qix1QkFBQyxVQUFPLE1BQUssTUFBSyxxQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QjtBQUFBLE1BQ3ZCLHVCQUFDLFVBQU8sU0FBTyxNQUFDLHVCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVCO0FBQUEsTUFDdkIsdUJBQUMsVUFBTyxVQUFRLE1BQUMsd0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxTQVIzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUVBLHVCQUFDLFdBQVEsT0FBTSwrQkFDYixpQ0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sYUFBWTtBQUFBLFVBQ1osT0FBT1QsS0FBS1Y7QUFBQUEsVUFDWixVQUFVLENBQUNvQixNQUFNVCxRQUFRLEVBQUUsR0FBR0QsTUFBTVYsT0FBT29CLEVBQUVDLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsUUFKN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSStEO0FBQUEsTUFFL0Q7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLGFBQVk7QUFBQSxVQUNaLFNBQVMzQjtBQUFBQSxVQUNULE9BQU9hO0FBQUFBLFVBQ1AsVUFBVSxDQUFDWSxNQUFNWCxTQUFTVyxFQUFFQyxPQUFPQyxLQUFLO0FBQUE7QUFBQSxRQUwxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLNEM7QUFBQSxNQUU1QztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sT0FBT1osS0FBS0c7QUFBQUEsVUFDWixVQUFVLENBQUNPLE1BQU1ULFFBQVEsRUFBRSxHQUFHRCxNQUFNRyxNQUFNTyxFQUFFQyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLFFBSDVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUc4RDtBQUFBLE1BRTlEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixNQUFLO0FBQUEsVUFDTCxhQUFZO0FBQUEsVUFDWixPQUFNO0FBQUE7QUFBQSxRQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUk0QjtBQUFBLFNBdkI5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBLEtBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxJQUVBLHVCQUFDLFdBQVEsT0FBTSxTQUNiO0FBQUEsNkJBQUMsVUFBTyxTQUFTLE1BQU1mLGFBQWEsSUFBSSxHQUFHLDBCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFEO0FBQUEsTUFDckQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1EO0FBQUFBLFVBQ04sU0FBUyxNQUFNQyxhQUFhLEtBQUs7QUFBQSxVQUNqQyxPQUFNO0FBQUEsVUFDTixRQUNFLG1DQUNFO0FBQUEsbUNBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUyxNQUFNQSxhQUFhLEtBQUssR0FBRyxzQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBTyxTQUFTLE1BQU1BLGFBQWEsS0FBSyxHQUFHLG9CQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBLGVBSmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUdGLGlDQUFDLE9BQUUsV0FBVSwwQkFBeUIsc0lBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQTtBQUFBLFFBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWlCQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUVBLHVCQUFDLFdBQVEsT0FBTSxTQUNiLGlDQUFDLFNBQUksV0FBVSxzREFDYixpQ0FBQyxTQUNDO0FBQUEsNkJBQUMsU0FDQyxpQ0FBQyxNQUNDO0FBQUEsK0JBQUMsTUFBRyxvQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVE7QUFBQSxRQUNSLHVCQUFDLE1BQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTO0FBQUEsUUFDVCx1QkFBQyxNQUFHLHNCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVTtBQUFBLFFBQ1YsdUJBQUMsTUFBRyxvQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVE7QUFBQSxXQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FDRTtBQUFBLFFBQ0MsRUFBRWdCLE1BQU0sc0JBQXNCZixPQUFPLE1BQU1nQixRQUFRLGFBQWFYLE1BQU0sYUFBYTtBQUFBLFFBQ25GLEVBQUVVLE1BQU0sa0JBQWtCZixPQUFPLE1BQU1nQixRQUFRLGlCQUFpQlgsTUFBTSxhQUFhO0FBQUEsUUFDbkYsRUFBRVUsTUFBTSxzQkFBc0JmLE9BQU8sTUFBTWdCLFFBQVEsV0FBV1gsTUFBTSxhQUFhO0FBQUEsTUFBQyxFQUNsRlk7QUFBQUEsUUFBSSxDQUFDQyxRQUNMLHVCQUFDLE1BQ0M7QUFBQSxpQ0FBQyxNQUFHLFdBQVUsZUFBZUEsY0FBSUgsUUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxVQUN0Qyx1QkFBQyxNQUFJRyxjQUFJbEIsU0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlO0FBQUEsVUFDZix1QkFBQyxNQUNDLGlDQUFDLFNBQU0sU0FBU1EsY0FBY1UsSUFBSUYsTUFBTSxLQUFLLFdBQVlFLGNBQUlGLFVBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FLEtBRHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE1BQUlFLGNBQUliLFFBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYztBQUFBLGFBTlBhLElBQUlILE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsTUFDRCxLQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLFNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkEsS0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkJBO0FBQUEsSUFFQSx1QkFBQyxXQUFRLE9BQU0sU0FDYixpQ0FBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSw2QkFBQyxTQUFNLFNBQVEsV0FBVSx5QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQ2xDLHVCQUFDLFNBQU0sU0FBUSxRQUFPLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsU0FBTSxTQUFRLFdBQVUsdUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0M7QUFBQSxNQUNoQyx1QkFBQyxTQUFNLFNBQVEsVUFBUyx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLE1BQy9CLHVCQUFDLFNBQU0sU0FBUSxXQUFVLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUEsU0FML0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFFQSx1QkFBQyxXQUFRLE9BQU0sU0FDYixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixTQUFTLE1BQ1BsQixVQUFVLEVBQUVzQixNQUFNLFdBQVczQixPQUFPLFdBQVc0QixTQUFTLDRCQUE0QixDQUFDO0FBQUEsVUFDdEY7QUFBQTtBQUFBLFFBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixTQUFTLE1BQ1B2QixVQUFVLEVBQUVzQixNQUFNLFNBQVMzQixPQUFPLFNBQVM0QixTQUFTLDZCQUE2QixDQUFDO0FBQUEsVUFDbkY7QUFBQTtBQUFBLFFBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixTQUFTLE1BQU12QixVQUFVLEVBQUVzQixNQUFNLFFBQVFDLFNBQVMsNkJBQTZCLENBQUM7QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLFNBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkEsS0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBRUEsdUJBQUMsV0FBUSxPQUFNLFdBQ2IsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkJBQUMsV0FBUSxNQUFLLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQjtBQUFBLE1BQ2xCLHVCQUFDLFdBQVEsTUFBSyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0I7QUFBQSxNQUNsQix1QkFBQyxXQUFRLE1BQUssUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCO0FBQUEsU0FIcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQSx1QkFBQyxXQUFRLE9BQU0sZUFDYjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sYUFBWTtBQUFBLFFBQ1osUUFBUSx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFdBQVUsNEJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQTtBQUFBLE1BSDFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUdvRSxLQUp0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUVBLHVCQUFDLFdBQVEsT0FBTSxtQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQ0FDYixpQ0FBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSwrQkFBQyxTQUFNLE9BQU0sY0FBYSxhQUFZLHdCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLGFBQWFwQixRQUFRLGtCQUFrQjtBQUFBLFlBQ3ZDLFNBQVNBLFFBQVFaLFNBQVNZLEtBQUssSUFBSTtBQUFBLFlBQ25DLFVBQVUsQ0FBQ0E7QUFBQUE7QUFBQUEsVUFKYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJbUI7QUFBQSxXQU5yQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBU007QUFBQUEsVUFDVCxTQUFTLE1BQU07QUFDYkMsc0JBQVUsSUFBSTtBQUNkYyx1QkFBVyxNQUFNO0FBQ2ZkLHdCQUFVLEtBQUs7QUFDZlYsd0JBQVUsRUFBRXNCLE1BQU0sV0FBV0MsU0FBUyxrQkFBa0IsQ0FBQztBQUFBLFlBQzNELEdBQUcsSUFBSTtBQUFBLFVBQ1Q7QUFBQSxVQUFFO0FBQUE7QUFBQSxRQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLE9BM0xGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0TEEsS0E3TEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThMQTtBQUVKO0FBQUN4QixHQWhOUUQsYUFBVztBQUFBLFVBQ0lYLFFBQVE7QUFBQTtBQUFBLE1BRHZCVztBQWtOVCx3QkFBd0IyQixpQkFBaUI7QUFDdkMsU0FDRSx1QkFBQyxpQkFDQyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVksS0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDQyxNQU51QkQ7QUFBYyxJQUFBNUIsSUFBQThCLEtBQUFEO0FBQUEsYUFBQTdCLElBQUE7QUFBQSxhQUFBOEIsS0FBQTtBQUFBLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkJ1dHRvbiIsIklucHV0IiwiU2VsZWN0IiwiRGF0ZVBpY2tlciIsIk1vZGFsIiwiVGFibGUiLCJUSGVhZCIsIlRCb2R5IiwiVHIiLCJUaCIsIlRkIiwiQmFkZ2UiLCJUb2FzdFByb3ZpZGVyIiwidXNlVG9hc3QiLCJMb2FkaW5nIiwiRW1wdHlTdGF0ZSIsIlBIQVNFUyIsIlNUQVRVU0VTIiwiVFMiLCJRQSIsIlNlY3Rpb24iLCJ0aXRsZSIsImNoaWxkcmVuIiwiX2MiLCJEZW1vQ29udGVudCIsIl9zIiwic2hvd1RvYXN0IiwibW9kYWxPcGVuIiwic2V0TW9kYWxPcGVuIiwicGhhc2UiLCJzZXRQaGFzZSIsImZvcm0iLCJzZXRGb3JtIiwidXJsIiwiZGF0ZSIsInNhdmluZyIsInNldFNhdmluZyIsInN0YXR1c1ZhcmlhbnQiLCJDb21wbGV0ZWQiLCJUZXN0aW5nIiwiUGxhbiIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsInRhc2siLCJzdGF0dXMiLCJtYXAiLCJyb3ciLCJ0eXBlIiwibWVzc2FnZSIsInNldFRpbWVvdXQiLCJDb21wb25lbnRzUGFnZSIsIl9jMyIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb21wb25lbnRzUGFnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7XHJcbiAgQnV0dG9uLFxyXG4gIElucHV0LFxyXG4gIFNlbGVjdCxcclxuICBEYXRlUGlja2VyLFxyXG4gIE1vZGFsLFxyXG4gIFRhYmxlLFxyXG4gIFRIZWFkLFxyXG4gIFRCb2R5LFxyXG4gIFRyLFxyXG4gIFRoLFxyXG4gIFRkLFxyXG4gIEJhZGdlLFxyXG4gIFRvYXN0UHJvdmlkZXIsXHJcbiAgdXNlVG9hc3QsXHJcbiAgTG9hZGluZyxcclxuICBFbXB0eVN0YXRlLFxyXG59IGZyb20gJy4uL2NvbXBvbmVudHMvdWknO1xyXG5cclxuY29uc3QgUEhBU0VTID0gWydUUycsICdRQSddO1xyXG5jb25zdCBTVEFUVVNFUyA9IHtcclxuICBUUzogWydDb21wbGV0ZWQnLCAnRG9jdW1lbnRhdGlvbicsICdPbiBIb2xkJywgJ0luIFByb2dyZXNzJywgJ1BsYW4nXSxcclxuICBRQTogW1xyXG4gICAgJ0NvbXBsZXRlZCcsXHJcbiAgICAnQ29tcGxldGVkIFRlc3RpbmcnLFxyXG4gICAgJ0NvbXBsZXRlZCB3aXRoIEZlZWRiYWNrJyxcclxuICAgICdUZXN0aW5nJyxcclxuICAgICdPbiBRdWV1ZSBUZXN0aW5nJyxcclxuICAgICdQbGFuJyxcclxuICBdLFxyXG59O1xyXG5cclxuZnVuY3Rpb24gU2VjdGlvbih7IHRpdGxlLCBjaGlsZHJlbiB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcC02IHNoYWRvdy1zbVwiPlxyXG4gICAgICA8aDIgY2xhc3NOYW1lPVwibWItNCB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDBcIj57dGl0bGV9PC9oMj5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIERlbW9Db250ZW50KCkge1xyXG4gIGNvbnN0IHsgc2hvd1RvYXN0IH0gPSB1c2VUb2FzdCgpO1xyXG4gIGNvbnN0IFttb2RhbE9wZW4sIHNldE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3BoYXNlLCBzZXRQaGFzZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGUoeyB0aXRsZTogJycsIHVybDogJycsIGRhdGU6ICcnIH0pO1xyXG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IHN0YXR1c1ZhcmlhbnQgPSB7XHJcbiAgICBDb21wbGV0ZWQ6ICdzdWNjZXNzJyxcclxuICAgICdJbiBQcm9ncmVzcyc6ICdpbmZvJyxcclxuICAgIFRlc3Rpbmc6ICd3YXJuaW5nJyxcclxuICAgICdPbiBIb2xkJzogJ2RhbmdlcicsXHJcbiAgICBQbGFuOiAnbmV1dHJhbCcsXHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTEwMCBwLThcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTV4bCBzcGFjZS15LTZcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPlVJIENvbXBvbmVudHM8L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgTGl2ZSBwcmV2aWV3IHNlbXVhIGtvbXBvbmVuIHVudHVrIHRpbSAoRmFiaW8gJmFtcDsgQmFnYXMpLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxhIGhyZWY9XCIvc3VibWl0XCIgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWJsdWUtNjAwIGhvdmVyOnVuZGVybGluZVwiPlxyXG4gICAgICAgICAgICDihpAgQmFjayB0byAvc3VibWl0XHJcbiAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxTZWN0aW9uIHRpdGxlPVwiQnV0dG9uXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8QnV0dG9uPlByaW1hcnk8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCI+U2Vjb25kYXJ5PC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImRhbmdlclwiPkRhbmdlcjwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCI+T3V0bGluZTwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiPlNtYWxsPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cImxnXCI+TGFyZ2U8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvbiBsb2FkaW5nPkxvYWRpbmc8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD5EaXNhYmxlZDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9TZWN0aW9uPlxyXG5cclxuICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIklucHV0IC8gU2VsZWN0IC8gRGF0ZVBpY2tlclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC00IHNtOmdyaWQtY29scy0zXCI+XHJcbiAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiVGFzayBUaXRsZVwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIEZpeCBsb2dpbiBidWdcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnRpdGxlfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHRpdGxlOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiUGhhc2VcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IHBoYXNlXCJcclxuICAgICAgICAgICAgICBvcHRpb25zPXtQSEFTRVN9XHJcbiAgICAgICAgICAgICAgdmFsdWU9e3BoYXNlfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGhhc2UoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiRGF0ZVwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uZGF0ZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBkYXRlOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJDbGlja1VwIFVSTFwiXHJcbiAgICAgICAgICAgICAgdHlwZT1cInVybFwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL2FwcC5jbGlja3VwLmNvbS90Ly4uLlwiXHJcbiAgICAgICAgICAgICAgZXJyb3I9XCJJbnZhbGlkIFVSTCBmb3JtYXRcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9TZWN0aW9uPlxyXG5cclxuICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIk1vZGFsXCI+XHJcbiAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsT3Blbih0cnVlKX0+T3BlbiBNb2RhbDwvQnV0dG9uPlxyXG4gICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgIG9wZW49e21vZGFsT3Blbn1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0TW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICAgICAgdGl0bGU9XCJDb25maXJtIFNhdmUgTFNQUFRcIlxyXG4gICAgICAgICAgICBmb290ZXI9e1xyXG4gICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17KCkgPT4gc2V0TW9kYWxPcGVuKGZhbHNlKX0+XHJcbiAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsT3BlbihmYWxzZSl9PlNhdmU8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIHNhdmUgdGhpcyBMU1BQVCBlbnRyeT8gVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS5cclxuICAgICAgICAgICAgICBQcmVzcyBFU0Mgb3IgY2xpY2sgdGhlIG92ZXJsYXkgdG8gY2xvc2UuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgPC9TZWN0aW9uPlxyXG5cclxuICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIlRhYmxlXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgIDxUYWJsZT5cclxuICAgICAgICAgICAgICA8VEhlYWQ+XHJcbiAgICAgICAgICAgICAgICA8VHI+XHJcbiAgICAgICAgICAgICAgICAgIDxUaD5UYXNrPC9UaD5cclxuICAgICAgICAgICAgICAgICAgPFRoPlBoYXNlPC9UaD5cclxuICAgICAgICAgICAgICAgICAgPFRoPlN0YXR1czwvVGg+XHJcbiAgICAgICAgICAgICAgICAgIDxUaD5EYXRlPC9UaD5cclxuICAgICAgICAgICAgICAgIDwvVHI+XHJcbiAgICAgICAgICAgICAgPC9USGVhZD5cclxuICAgICAgICAgICAgICA8VEJvZHk+XHJcbiAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICB7IHRhc2s6ICdGaXggbG9naW4gcmVkaXJlY3QnLCBwaGFzZTogJ1RTJywgc3RhdHVzOiAnQ29tcGxldGVkJywgZGF0ZTogJzIwMjYtMDgtMjAnIH0sXHJcbiAgICAgICAgICAgICAgICAgIHsgdGFzazogJ1dyaXRlIEFQSSBkb2NzJywgcGhhc2U6ICdUUycsIHN0YXR1czogJ0RvY3VtZW50YXRpb24nLCBkYXRlOiAnMjAyNi0wOC0yMScgfSxcclxuICAgICAgICAgICAgICAgICAgeyB0YXNrOiAnUmVncmVzc2lvbiB0ZXN0aW5nJywgcGhhc2U6ICdRQScsIHN0YXR1czogJ1Rlc3RpbmcnLCBkYXRlOiAnMjAyNi0wOC0yMicgfSxcclxuICAgICAgICAgICAgICAgIF0ubWFwKChyb3cpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFRyIGtleT17cm93LnRhc2t9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZCBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPntyb3cudGFza308L1RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZD57cm93LnBoYXNlfTwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9e3N0YXR1c1ZhcmlhbnRbcm93LnN0YXR1c10gfHwgJ25ldXRyYWwnfT57cm93LnN0YXR1c308L0JhZGdlPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRkPntyb3cuZGF0ZX08L1RkPlxyXG4gICAgICAgICAgICAgICAgICA8L1RyPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9UQm9keT5cclxuICAgICAgICAgICAgPC9UYWJsZT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvU2VjdGlvbj5cclxuXHJcbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJCYWRnZVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cInN1Y2Nlc3NcIj5Db21wbGV0ZWQ8L0JhZGdlPlxyXG4gICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cImluZm9cIj5JbiBQcm9ncmVzczwvQmFkZ2U+XHJcbiAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwid2FybmluZ1wiPlRlc3Rpbmc8L0JhZGdlPlxyXG4gICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cImRhbmdlclwiPk9uIEhvbGQ8L0JhZGdlPlxyXG4gICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm5ldXRyYWxcIj5QbGFuPC9CYWRnZT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvU2VjdGlvbj5cclxuXHJcbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJUb2FzdFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgIHNob3dUb2FzdCh7IHR5cGU6ICdzdWNjZXNzJywgdGl0bGU6ICdTdWNjZXNzJywgbWVzc2FnZTogJ0xTUFBUIHNhdmVkIHN1Y2Nlc3NmdWxseS4nIH0pXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgU3VjY2VzcyB0b2FzdFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgc2hvd1RvYXN0KHsgdHlwZTogJ2Vycm9yJywgdGl0bGU6ICdFcnJvcicsIG1lc3NhZ2U6ICdGYWlsZWQgdG8gc2F2ZS4gVHJ5IGFnYWluLicgfSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBFcnJvciB0b2FzdFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzaG93VG9hc3QoeyB0eXBlOiAnaW5mbycsIG1lc3NhZ2U6ICdBdXRvLWRpc21pc3MgaW4gNCBzZWNvbmRzLicgfSl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBJbmZvIHRvYXN0XHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9TZWN0aW9uPlxyXG5cclxuICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIkxvYWRpbmdcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgPExvYWRpbmcgc2l6ZT1cInNtXCIgLz5cclxuICAgICAgICAgICAgPExvYWRpbmcgc2l6ZT1cIm1kXCIgLz5cclxuICAgICAgICAgICAgPExvYWRpbmcgc2l6ZT1cImxnXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvU2VjdGlvbj5cclxuXHJcbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJFbXB0eSBTdGF0ZVwiPlxyXG4gICAgICAgICAgPEVtcHR5U3RhdGVcclxuICAgICAgICAgICAgdGl0bGU9XCJObyBoaXN0b3J5IGZvdW5kXCJcclxuICAgICAgICAgICAgZGVzY3JpcHRpb249XCJUcnkgYWRqdXN0aW5nIHRoZSBlbXBsb3llZSBmaWx0ZXIgb3IgZGF0ZSByYW5nZS5cIlxyXG4gICAgICAgICAgICBhY3Rpb249ezxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cIm91dGxpbmVcIj5SZXNldCBmaWx0ZXI8L0J1dHRvbj59XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvU2VjdGlvbj5cclxuXHJcbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJNaW5pIEZvcm0gRGVtbyAoQnV0dG9uICsgVG9hc3QpXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWF4LXctbWQgaXRlbXMtZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgIDxJbnB1dCBsYWJlbD1cIlRhc2sgVGl0bGVcIiBwbGFjZWhvbGRlcj1cImUuZy4gRml4IGxvZ2luIGJ1Z1wiIC8+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJTdGF0dXMgKGR5bmFtaWMgcGVyIFBoYXNlKVwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17cGhhc2UgPyAnU2VsZWN0IHN0YXR1cycgOiAnUGljayBhIFBoYXNlIGZpcnN0J31cclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e3BoYXNlID8gU1RBVFVTRVNbcGhhc2VdIDogW119XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXBoYXNlfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgbG9hZGluZz17c2F2aW5nfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldFNhdmluZyh0cnVlKTtcclxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRTYXZpbmcoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICBzaG93VG9hc3QoeyB0eXBlOiAnc3VjY2VzcycsIG1lc3NhZ2U6ICdGb3JtIHN1Ym1pdHRlZCEnIH0pO1xyXG4gICAgICAgICAgICAgICAgfSwgMTIwMCk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFN1Ym1pdFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvU2VjdGlvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb21wb25lbnRzUGFnZSgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPFRvYXN0UHJvdmlkZXI+XHJcbiAgICAgIDxEZW1vQ29udGVudCAvPlxyXG4gICAgPC9Ub2FzdFByb3ZpZGVyPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiIvYXBwL3NyYy9wYWdlcy9Db21wb25lbnRzUGFnZS5qc3gifQ==