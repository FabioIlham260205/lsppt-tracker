import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Modal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f7470b49"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/Modal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f7470b49"; const useEffect = __vite__cjsImport3_react["useEffect"];
import __vite__cjsImport4_reactDom from "/node_modules/.vite/deps/react-dom.js?v=f7470b49"; const createPortal = __vite__cjsImport4_reactDom["createPortal"];
const SIZES = {
  sm: "max-w-sm",
  md: "max-w-lg",
  lg: "max-w-2xl"
};
export default function Modal({ open, onClose, title, footer, size = "md", children }) {
  _s();
  useEffect(() => {
    if (!open) return void 0;
    const handleKey = (e) => {
      if (e.key === "Escape") onClose?.();
    };
    document.addEventListener("keydown", handleKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  return createPortal(
    /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-slate-900/50", onClick: onClose }, void 0, false, {
        fileName: "/app/src/components/ui/Modal.jsx",
        lineNumber: 49,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          role: "dialog",
          "aria-modal": "true",
          className: `relative w-full ${SIZES[size]} rounded-lg bg-white shadow-xl`,
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-slate-200 px-5 py-3", children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-semibold text-slate-800", children: title }, void 0, false, {
                fileName: "/app/src/components/ui/Modal.jsx",
                lineNumber: 56,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: onClose,
                  "aria-label": "Close",
                  className: "rounded p-1 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600",
                  children: /* @__PURE__ */ jsxDEV("svg", { className: "h-5 w-5", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M6 18L18 6M6 6l12 12" }, void 0, false, {
                    fileName: "/app/src/components/ui/Modal.jsx",
                    lineNumber: 64,
                    columnNumber: 15
                  }, this) }, void 0, false, {
                    fileName: "/app/src/components/ui/Modal.jsx",
                    lineNumber: 63,
                    columnNumber: 13
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/components/ui/Modal.jsx",
                  lineNumber: 57,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/components/ui/Modal.jsx",
              lineNumber: 55,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-4", children }, void 0, false, {
              fileName: "/app/src/components/ui/Modal.jsx",
              lineNumber: 68,
              columnNumber: 9
            }, this),
            footer && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2 border-t border-slate-200 px-5 py-3", children: footer }, void 0, false, {
              fileName: "/app/src/components/ui/Modal.jsx",
              lineNumber: 70,
              columnNumber: 9
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/components/ui/Modal.jsx",
          lineNumber: 50,
          columnNumber: 7
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/ui/Modal.jsx",
      lineNumber: 48,
      columnNumber: 5
    }, this),
    document.body
  );
}
_s(Modal, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = Modal;
var _c;
$RefreshReg$(_c, "Modal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/Modal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/Modal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCTixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0Msb0JBQW9CO0FBRTdCLE1BQU1DLFFBQVE7QUFBQSxFQUNaQyxJQUFJO0FBQUEsRUFDSkMsSUFBSTtBQUFBLEVBQ0pDLElBQUk7QUFDTjtBQUVBLHdCQUF3QkMsTUFBTSxFQUFFQyxNQUFNQyxTQUFTQyxPQUFPQyxRQUFRQyxPQUFPLE1BQU1DLFNBQVMsR0FBRztBQUFBQyxLQUFBO0FBQ3JGYixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNPLEtBQU0sUUFBT087QUFFbEIsVUFBTUMsWUFBWUEsQ0FBQ0MsTUFBTTtBQUN2QixVQUFJQSxFQUFFQyxRQUFRLFNBQVVULFdBQVU7QUFBQSxJQUNwQztBQUVBVSxhQUFTQyxpQkFBaUIsV0FBV0osU0FBUztBQUM5Q0csYUFBU0UsS0FBS0MsTUFBTUMsV0FBVztBQUMvQixXQUFPLE1BQU07QUFDWEosZUFBU0ssb0JBQW9CLFdBQVdSLFNBQVM7QUFDakRHLGVBQVNFLEtBQUtDLE1BQU1DLFdBQVc7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxDQUFDZixNQUFNQyxPQUFPLENBQUM7QUFFbEIsTUFBSSxDQUFDRCxLQUFNLFFBQU87QUFFbEIsU0FBT047QUFBQUEsSUFDTCx1QkFBQyxTQUFJLFdBQVUsMkRBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0NBQW1DLFNBQVNPLFdBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUU7QUFBQSxNQUNuRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsY0FBVztBQUFBLFVBQ1gsV0FBVyxtQkFBbUJOLE1BQU1TLElBQUksQ0FBQztBQUFBLFVBRXpDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHlFQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLDBDQUEwQ0YsbUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThEO0FBQUEsY0FDOUQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVNEO0FBQUFBLGtCQUNULGNBQVc7QUFBQSxrQkFDWCxXQUFVO0FBQUEsa0JBRVYsaUNBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFNBQVEsYUFBWSxRQUFPLGdCQUFlLGFBQVksS0FDekYsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxHQUFFLDBCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRSxLQUQ3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUE7QUFBQSxnQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLGlCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxhQUFhSSxZQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQztBQUFBLFlBQ3BDRixVQUNDLHVCQUFDLFNBQUksV0FBVSw4REFBOERBLG9CQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRjtBQUFBO0FBQUE7QUFBQSxRQXBCeEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Bc0JBO0FBQUEsU0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBQ0FRLFNBQVNFO0FBQUFBLEVBQ1g7QUFDRjtBQUFDUCxHQS9DdUJQLE9BQUs7QUFBQSxLQUFMQTtBQUFLLElBQUFrQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJjcmVhdGVQb3J0YWwiLCJTSVpFUyIsInNtIiwibWQiLCJsZyIsIk1vZGFsIiwib3BlbiIsIm9uQ2xvc2UiLCJ0aXRsZSIsImZvb3RlciIsInNpemUiLCJjaGlsZHJlbiIsIl9zIiwidW5kZWZpbmVkIiwiaGFuZGxlS2V5IiwiZSIsImtleSIsImRvY3VtZW50IiwiYWRkRXZlbnRMaXN0ZW5lciIsImJvZHkiLCJzdHlsZSIsIm92ZXJmbG93IiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IGNyZWF0ZVBvcnRhbCB9IGZyb20gJ3JlYWN0LWRvbSc7XHJcblxyXG5jb25zdCBTSVpFUyA9IHtcclxuICBzbTogJ21heC13LXNtJyxcclxuICBtZDogJ21heC13LWxnJyxcclxuICBsZzogJ21heC13LTJ4bCcsXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNb2RhbCh7IG9wZW4sIG9uQ2xvc2UsIHRpdGxlLCBmb290ZXIsIHNpemUgPSAnbWQnLCBjaGlsZHJlbiB9KSB7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghb3BlbikgcmV0dXJuIHVuZGVmaW5lZDtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVLZXkgPSAoZSkgPT4ge1xyXG4gICAgICBpZiAoZS5rZXkgPT09ICdFc2NhcGUnKSBvbkNsb3NlPy4oKTtcclxuICAgIH07XHJcblxyXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleSk7XHJcbiAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gJ2hpZGRlbic7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5KTtcclxuICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9ICcnO1xyXG4gICAgfTtcclxuICB9LCBbb3Blbiwgb25DbG9zZV0pO1xyXG5cclxuICBpZiAoIW9wZW4pIHJldHVybiBudWxsO1xyXG5cclxuICByZXR1cm4gY3JlYXRlUG9ydGFsKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1zbGF0ZS05MDAvNTBcIiBvbkNsaWNrPXtvbkNsb3NlfSAvPlxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgcm9sZT1cImRpYWxvZ1wiXHJcbiAgICAgICAgYXJpYS1tb2RhbD1cInRydWVcIlxyXG4gICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIHctZnVsbCAke1NJWkVTW3NpemVdfSByb3VuZGVkLWxnIGJnLXdoaXRlIHNoYWRvdy14bGB9XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIHB4LTUgcHktM1wiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwXCI+e3RpdGxlfTwvaDI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2xvc2VcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIHAtMSB0ZXh0LXNsYXRlLTQwMCB0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1zbGF0ZS0xMDAgaG92ZXI6dGV4dC1zbGF0ZS02MDBcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cImgtNSB3LTVcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIj5cclxuICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgZD1cIk02IDE4TDE4IDZNNiA2bDEyIDEyXCIgLz5cclxuICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktNFwiPntjaGlsZHJlbn08L2Rpdj5cclxuICAgICAgICB7Zm9vdGVyICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMiBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwIHB4LTUgcHktM1wiPntmb290ZXJ9PC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj4sXHJcbiAgICBkb2N1bWVudC5ib2R5XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvdWkvTW9kYWwuanN4In0=