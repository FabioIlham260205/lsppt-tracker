import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Select.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f7470b49"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/Select.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f7470b49"; const useId = __vite__cjsImport3_react["useId"];
const BASE = "w-full rounded-md border px-3 py-2 text-sm text-slate-900 shadow-sm outline-none transition focus:ring-2 disabled:bg-slate-50";
function toOption(option) {
  return typeof option === "object" ? option : { value: option, label: option };
}
export default function Select({
  label,
  options = [],
  placeholder = "Select...",
  error,
  className = "",
  id,
  ...props
}) {
  _s();
  const autoId = useId();
  const selectId = id || autoId;
  return /* @__PURE__ */ jsxDEV("div", { children: [
    label && /* @__PURE__ */ jsxDEV("label", { htmlFor: selectId, className: "mb-1 block text-sm font-medium text-slate-700", children: label }, void 0, false, {
      fileName: "/app/src/components/ui/Select.jsx",
      lineNumber: 44,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "select",
      {
        id: selectId,
        className: `${BASE} ${error ? "border-red-400 focus:border-red-500 focus:ring-red-500" : "border-slate-300 focus:border-blue-500 focus:ring-blue-500"} ${className}`,
        ...props,
        children: [
          /* @__PURE__ */ jsxDEV("option", { value: "", children: placeholder }, void 0, false, {
            fileName: "/app/src/components/ui/Select.jsx",
            lineNumber: 57,
            columnNumber: 9
          }, this),
          options.map(toOption).map(
            (opt) => /* @__PURE__ */ jsxDEV("option", { value: opt.value, children: opt.label }, opt.value, false, {
              fileName: "/app/src/components/ui/Select.jsx",
              lineNumber: 59,
              columnNumber: 9
            }, this)
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/app/src/components/ui/Select.jsx",
        lineNumber: 48,
        columnNumber: 7
      },
      this
    ),
    error && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-600", children: error }, void 0, false, {
      fileName: "/app/src/components/ui/Select.jsx",
      lineNumber: 64,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/ui/Select.jsx",
    lineNumber: 42,
    columnNumber: 5
  }, this);
}
_s(Select, "c30GLqU4NaAI3XCSCLfDXteiTN8=");
_c = Select;
var _c;
$RefreshReg$(_c, "Select");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/Select.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/Select.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQXhCUixTQUFTQSxhQUFhO0FBRXRCLE1BQU1DLE9BQ0o7QUFFRixTQUFTQyxTQUFTQyxRQUFRO0FBQ3hCLFNBQU8sT0FBT0EsV0FBVyxXQUFXQSxTQUFTLEVBQUVDLE9BQU9ELFFBQVFFLE9BQU9GLE9BQU87QUFDOUU7QUFFQSx3QkFBd0JHLE9BQU87QUFBQSxFQUM3QkQ7QUFBQUEsRUFDQUUsVUFBVTtBQUFBLEVBQ1ZDLGNBQWM7QUFBQSxFQUNkQztBQUFBQSxFQUNBQyxZQUFZO0FBQUEsRUFDWkM7QUFBQUEsRUFDQSxHQUFHQztBQUNMLEdBQUc7QUFBQUMsS0FBQTtBQUNELFFBQU1DLFNBQVNkLE1BQU07QUFDckIsUUFBTWUsV0FBV0osTUFBTUc7QUFFdkIsU0FDRSx1QkFBQyxTQUNFVDtBQUFBQSxhQUNDLHVCQUFDLFdBQU0sU0FBU1UsVUFBVSxXQUFVLGlEQUNqQ1YsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBSVU7QUFBQUEsUUFDSixXQUFXLEdBQUdkLElBQUksSUFDaEJRLFFBQ0ksMkRBQ0EsNERBQTRELElBQzlEQyxTQUFTO0FBQUEsUUFDYixHQUFJRTtBQUFBQSxRQUVKO0FBQUEsaUNBQUMsWUFBTyxPQUFNLElBQUlKLHlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLFVBQzdCRCxRQUFRUyxJQUFJZCxRQUFRLEVBQUVjO0FBQUFBLFlBQUksQ0FBQ0MsUUFDMUIsdUJBQUMsWUFBdUIsT0FBT0EsSUFBSWIsT0FDaENhLGNBQUlaLFNBRE1ZLElBQUliLE9BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNEO0FBQUE7QUFBQTtBQUFBLE1BZEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZUE7QUFBQSxJQUNDSyxTQUFTLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJBLG1CQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdEO0FBQUEsT0F0QjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1QkE7QUFFSjtBQUFDSSxHQXRDdUJQLFFBQU07QUFBQSxLQUFOQTtBQUFNLElBQUFZO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUlkIiwiQkFTRSIsInRvT3B0aW9uIiwib3B0aW9uIiwidmFsdWUiLCJsYWJlbCIsIlNlbGVjdCIsIm9wdGlvbnMiLCJwbGFjZWhvbGRlciIsImVycm9yIiwiY2xhc3NOYW1lIiwiaWQiLCJwcm9wcyIsIl9zIiwiYXV0b0lkIiwic2VsZWN0SWQiLCJtYXAiLCJvcHQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZWxlY3QuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUlkIH0gZnJvbSAncmVhY3QnO1xyXG5cclxuY29uc3QgQkFTRSA9XHJcbiAgJ3ctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCBzaGFkb3ctc20gb3V0bGluZS1ub25lIHRyYW5zaXRpb24gZm9jdXM6cmluZy0yIGRpc2FibGVkOmJnLXNsYXRlLTUwJztcclxuXHJcbmZ1bmN0aW9uIHRvT3B0aW9uKG9wdGlvbikge1xyXG4gIHJldHVybiB0eXBlb2Ygb3B0aW9uID09PSAnb2JqZWN0JyA/IG9wdGlvbiA6IHsgdmFsdWU6IG9wdGlvbiwgbGFiZWw6IG9wdGlvbiB9O1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZWxlY3Qoe1xyXG4gIGxhYmVsLFxyXG4gIG9wdGlvbnMgPSBbXSxcclxuICBwbGFjZWhvbGRlciA9ICdTZWxlY3QuLi4nLFxyXG4gIGVycm9yLFxyXG4gIGNsYXNzTmFtZSA9ICcnLFxyXG4gIGlkLFxyXG4gIC4uLnByb3BzXHJcbn0pIHtcclxuICBjb25zdCBhdXRvSWQgPSB1c2VJZCgpO1xyXG4gIGNvbnN0IHNlbGVjdElkID0gaWQgfHwgYXV0b0lkO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAge2xhYmVsICYmIChcclxuICAgICAgICA8bGFiZWwgaHRtbEZvcj17c2VsZWN0SWR9IGNsYXNzTmFtZT1cIm1iLTEgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAge2xhYmVsfVxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICl9XHJcbiAgICAgIDxzZWxlY3RcclxuICAgICAgICBpZD17c2VsZWN0SWR9XHJcbiAgICAgICAgY2xhc3NOYW1lPXtgJHtCQVNFfSAke1xyXG4gICAgICAgICAgZXJyb3JcclxuICAgICAgICAgICAgPyAnYm9yZGVyLXJlZC00MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDAgZm9jdXM6cmluZy1yZWQtNTAwJ1xyXG4gICAgICAgICAgICA6ICdib3JkZXItc2xhdGUtMzAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLWJsdWUtNTAwJ1xyXG4gICAgICAgIH0gJHtjbGFzc05hbWV9YH1cclxuICAgICAgICB7Li4ucHJvcHN9XHJcbiAgICAgID5cclxuICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+e3BsYWNlaG9sZGVyfTwvb3B0aW9uPlxyXG4gICAgICAgIHtvcHRpb25zLm1hcCh0b09wdGlvbikubWFwKChvcHQpID0+IChcclxuICAgICAgICAgIDxvcHRpb24ga2V5PXtvcHQudmFsdWV9IHZhbHVlPXtvcHQudmFsdWV9PlxyXG4gICAgICAgICAgICB7b3B0LmxhYmVsfVxyXG4gICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvc2VsZWN0PlxyXG4gICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTYwMFwiPntlcnJvcn08L3A+fVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvdWkvU2VsZWN0LmpzeCJ9