import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Input.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f7470b49"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/Input.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f7470b49"; const useId = __vite__cjsImport3_react["useId"];
const BASE = "w-full rounded-md border px-3 py-2 text-sm text-slate-900 shadow-sm outline-none transition placeholder:text-slate-400 focus:ring-2 disabled:bg-slate-50";
export default function Input({ label, error, className = "", id, ...props }) {
  _s();
  const autoId = useId();
  const inputId = id || autoId;
  return /* @__PURE__ */ jsxDEV("div", { children: [
    label && /* @__PURE__ */ jsxDEV("label", { htmlFor: inputId, className: "mb-1 block text-sm font-medium text-slate-700", children: label }, void 0, false, {
      fileName: "/app/src/components/ui/Input.jsx",
      lineNumber: 32,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        id: inputId,
        className: `${BASE} ${error ? "border-red-400 focus:border-red-500 focus:ring-red-500" : "border-slate-300 focus:border-blue-500 focus:ring-blue-500"} ${className}`,
        ...props
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/ui/Input.jsx",
        lineNumber: 36,
        columnNumber: 7
      },
      this
    ),
    error && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-600", children: error }, void 0, false, {
      fileName: "/app/src/components/ui/Input.jsx",
      lineNumber: 45,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/ui/Input.jsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
}
_s(Input, "c30GLqU4NaAI3XCSCLfDXteiTN8=");
_c = Input;
var _c;
$RefreshReg$(_c, "Input");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/Input.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/Input.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBWlIsU0FBU0EsYUFBYTtBQUV0QixNQUFNQyxPQUNKO0FBRUYsd0JBQXdCQyxNQUFNLEVBQUVDLE9BQU9DLE9BQU9DLFlBQVksSUFBSUMsSUFBSSxHQUFHQyxNQUFNLEdBQUc7QUFBQUMsS0FBQTtBQUM1RSxRQUFNQyxTQUFTVCxNQUFNO0FBQ3JCLFFBQU1VLFVBQVVKLE1BQU1HO0FBRXRCLFNBQ0UsdUJBQUMsU0FDRU47QUFBQUEsYUFDQyx1QkFBQyxXQUFNLFNBQVNPLFNBQVMsV0FBVSxpREFDaENQLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUY7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLElBQUlPO0FBQUFBLFFBQ0osV0FBVyxHQUFHVCxJQUFJLElBQ2hCRyxRQUNJLDJEQUNBLDREQUE0RCxJQUM5REMsU0FBUztBQUFBLFFBQ2IsR0FBSUU7QUFBQUE7QUFBQUEsTUFQTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPWTtBQUFBLElBRVhILFNBQVMsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkEsbUJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0Q7QUFBQSxPQWY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0JBO0FBRUo7QUFBQ0ksR0F2QnVCTixPQUFLO0FBQUEsS0FBTEE7QUFBSyxJQUFBUztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VJZCIsIkJBU0UiLCJJbnB1dCIsImxhYmVsIiwiZXJyb3IiLCJjbGFzc05hbWUiLCJpZCIsInByb3BzIiwiX3MiLCJhdXRvSWQiLCJpbnB1dElkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSW5wdXQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUlkIH0gZnJvbSAncmVhY3QnO1xyXG5cclxuY29uc3QgQkFTRSA9XHJcbiAgJ3ctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCBzaGFkb3ctc20gb3V0bGluZS1ub25lIHRyYW5zaXRpb24gcGxhY2Vob2xkZXI6dGV4dC1zbGF0ZS00MDAgZm9jdXM6cmluZy0yIGRpc2FibGVkOmJnLXNsYXRlLTUwJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIElucHV0KHsgbGFiZWwsIGVycm9yLCBjbGFzc05hbWUgPSAnJywgaWQsIC4uLnByb3BzIH0pIHtcclxuICBjb25zdCBhdXRvSWQgPSB1c2VJZCgpO1xyXG4gIGNvbnN0IGlucHV0SWQgPSBpZCB8fCBhdXRvSWQ7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICB7bGFiZWwgJiYgKFxyXG4gICAgICAgIDxsYWJlbCBodG1sRm9yPXtpbnB1dElkfSBjbGFzc05hbWU9XCJtYi0xIGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5cclxuICAgICAgICAgIHtsYWJlbH1cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICApfVxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICBpZD17aW5wdXRJZH1cclxuICAgICAgICBjbGFzc05hbWU9e2Ake0JBU0V9ICR7XHJcbiAgICAgICAgICBlcnJvclxyXG4gICAgICAgICAgICA/ICdib3JkZXItcmVkLTQwMCBmb2N1czpib3JkZXItcmVkLTUwMCBmb2N1czpyaW5nLXJlZC01MDAnXHJcbiAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0zMDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOnJpbmctYmx1ZS01MDAnXHJcbiAgICAgICAgfSAke2NsYXNzTmFtZX1gfVxyXG4gICAgICAgIHsuLi5wcm9wc31cclxuICAgICAgLz5cclxuICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC02MDBcIj57ZXJyb3J9PC9wPn1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL3VpL0lucHV0LmpzeCJ9