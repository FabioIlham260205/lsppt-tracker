import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Button.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f7470b49"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/Button.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export default function Button({
  variant = "primary",
  size = "md",
  loading = false,
  disabled = false,
  className = "",
  children,
  ...props
}) {
  const VARIANTS = {
    primary: "bg-blue-600 text-white hover:bg-blue-700 focus-visible:outline-blue-600",
    secondary: "bg-slate-200 text-slate-800 hover:bg-slate-300 focus-visible:outline-slate-400",
    danger: "bg-red-600 text-white hover:bg-red-700 focus-visible:outline-red-600",
    outline: "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 focus-visible:outline-blue-600"
  };
  const SIZES = {
    sm: "px-3 py-1.5 text-xs",
    md: "px-4 py-2 text-sm",
    lg: "px-5 py-2.5 text-base"
  };
  const isDisabled = disabled || loading;
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      disabled: isDisabled,
      className: `inline-flex items-center justify-center gap-2 rounded-md font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 disabled:pointer-events-none disabled:opacity-60 ${VARIANTS[variant]} ${SIZES[size]} ${className}`,
      ...props,
      children: [
        loading && /* @__PURE__ */ jsxDEV("span", { className: "h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" }, void 0, false, {
          fileName: "/app/src/components/ui/Button.jsx",
          lineNumber: 52,
          columnNumber: 7
        }, this),
        children
      ]
    },
    void 0,
    true,
    {
      fileName: "/app/src/components/ui/Button.jsx",
      lineNumber: 46,
      columnNumber: 5
    },
    this
  );
}
_c = Button;
var _c;
$RefreshReg$(_c, "Button");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/Button.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/Button.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NROzs7Ozs7Ozs7Ozs7Ozs7O0FBaENSLHdCQUF3QkEsT0FBTztBQUFBLEVBQzdCQyxVQUFVO0FBQUEsRUFDVkMsT0FBTztBQUFBLEVBQ1BDLFVBQVU7QUFBQSxFQUNWQyxXQUFXO0FBQUEsRUFDWEMsWUFBWTtBQUFBLEVBQ1pDO0FBQUFBLEVBQ0EsR0FBR0M7QUFDTCxHQUFHO0FBQ0QsUUFBTUMsV0FBVztBQUFBLElBQ2ZDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsUUFBUTtBQUFBLElBQ1JDLFNBQ0U7QUFBQSxFQUNKO0FBRUEsUUFBTUMsUUFBUTtBQUFBLElBQ1pDLElBQUk7QUFBQSxJQUNKQyxJQUFJO0FBQUEsSUFDSkMsSUFBSTtBQUFBLEVBQ047QUFFQSxRQUFNQyxhQUFhYixZQUFZRDtBQUUvQixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxVQUFVYztBQUFBQSxNQUNWLFdBQVcsa01BQWtNVCxTQUFTUCxPQUFPLENBQUMsSUFBSVksTUFBTVgsSUFBSSxDQUFDLElBQUlHLFNBQVM7QUFBQSxNQUMxUCxHQUFJRTtBQUFBQSxNQUVISjtBQUFBQSxtQkFDQyx1QkFBQyxVQUFLLFdBQVUsb0ZBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0c7QUFBQSxRQUVqR0c7QUFBQUE7QUFBQUE7QUFBQUEsSUFSSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQTtBQUVKO0FBQUNZLEtBckN1QmxCO0FBQU0sSUFBQWtCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkJ1dHRvbiIsInZhcmlhbnQiLCJzaXplIiwibG9hZGluZyIsImRpc2FibGVkIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJwcm9wcyIsIlZBUklBTlRTIiwicHJpbWFyeSIsInNlY29uZGFyeSIsImRhbmdlciIsIm91dGxpbmUiLCJTSVpFUyIsInNtIiwibWQiLCJsZyIsImlzRGlzYWJsZWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCdXR0b24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEJ1dHRvbih7XHJcbiAgdmFyaWFudCA9ICdwcmltYXJ5JyxcclxuICBzaXplID0gJ21kJyxcclxuICBsb2FkaW5nID0gZmFsc2UsXHJcbiAgZGlzYWJsZWQgPSBmYWxzZSxcclxuICBjbGFzc05hbWUgPSAnJyxcclxuICBjaGlsZHJlbixcclxuICAuLi5wcm9wc1xyXG59KSB7XHJcbiAgY29uc3QgVkFSSUFOVFMgPSB7XHJcbiAgICBwcmltYXJ5OiAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1ibHVlLTcwMCBmb2N1cy12aXNpYmxlOm91dGxpbmUtYmx1ZS02MDAnLFxyXG4gICAgc2Vjb25kYXJ5OiAnYmctc2xhdGUtMjAwIHRleHQtc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTMwMCBmb2N1cy12aXNpYmxlOm91dGxpbmUtc2xhdGUtNDAwJyxcclxuICAgIGRhbmdlcjogJ2JnLXJlZC02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1yZWQtNzAwIGZvY3VzLXZpc2libGU6b3V0bGluZS1yZWQtNjAwJyxcclxuICAgIG91dGxpbmU6XHJcbiAgICAgICdib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBiZy13aGl0ZSB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS01MCBmb2N1cy12aXNpYmxlOm91dGxpbmUtYmx1ZS02MDAnLFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IFNJWkVTID0ge1xyXG4gICAgc206ICdweC0zIHB5LTEuNSB0ZXh0LXhzJyxcclxuICAgIG1kOiAncHgtNCBweS0yIHRleHQtc20nLFxyXG4gICAgbGc6ICdweC01IHB5LTIuNSB0ZXh0LWJhc2UnLFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGlzRGlzYWJsZWQgPSBkaXNhYmxlZCB8fCBsb2FkaW5nO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGJ1dHRvblxyXG4gICAgICBkaXNhYmxlZD17aXNEaXNhYmxlZH1cclxuICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQtbWQgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW9mZnNldC0yIGRpc2FibGVkOnBvaW50ZXItZXZlbnRzLW5vbmUgZGlzYWJsZWQ6b3BhY2l0eS02MCAke1ZBUklBTlRTW3ZhcmlhbnRdfSAke1NJWkVTW3NpemVdfSAke2NsYXNzTmFtZX1gfVxyXG4gICAgICB7Li4ucHJvcHN9XHJcbiAgICA+XHJcbiAgICAgIHtsb2FkaW5nICYmIChcclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoLTQgdy00IGFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLWN1cnJlbnQgYm9yZGVyLXQtdHJhbnNwYXJlbnRcIiAvPlxyXG4gICAgICApfVxyXG4gICAgICB7Y2hpbGRyZW59XHJcbiAgICA8L2J1dHRvbj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy91aS9CdXR0b24uanN4In0=