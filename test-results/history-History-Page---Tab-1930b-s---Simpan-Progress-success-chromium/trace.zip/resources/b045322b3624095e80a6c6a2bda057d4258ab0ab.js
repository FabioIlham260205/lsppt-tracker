import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Table.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f7470b49"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/Table.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function Table({ className = "", ...props }) {
  return /* @__PURE__ */ jsxDEV("table", { className: `w-full text-left text-sm ${className}`, ...props }, void 0, false, {
    fileName: "/app/src/components/ui/Table.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}
_c = Table;
export function THead({ className = "", ...props }) {
  return /* @__PURE__ */ jsxDEV("thead", { className: `border-b border-slate-200 bg-slate-50 ${className}`, ...props }, void 0, false, {
    fileName: "/app/src/components/ui/Table.jsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
}
_c2 = THead;
export function TBody({ className = "", ...props }) {
  return /* @__PURE__ */ jsxDEV("tbody", { className, ...props }, void 0, false, {
    fileName: "/app/src/components/ui/Table.jsx",
    lineNumber: 29,
    columnNumber: 10
  }, this);
}
_c3 = TBody;
export function Tr({ className = "", ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "tr",
    {
      className: `border-b border-slate-100 transition-colors last:border-0 hover:bg-slate-50 ${className}`,
      ...props
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/ui/Table.jsx",
      lineNumber: 34,
      columnNumber: 5
    },
    this
  );
}
_c4 = Tr;
export function Th({ className = "", ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "th",
    {
      className: `px-4 py-3 text-xs font-semibold tracking-wide text-slate-600 uppercase ${className}`,
      ...props
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/ui/Table.jsx",
      lineNumber: 43,
      columnNumber: 5
    },
    this
  );
}
_c5 = Th;
export function Td({ className = "", ...props }) {
  return /* @__PURE__ */ jsxDEV("td", { className: `px-4 py-3 text-slate-700 ${className}`, ...props }, void 0, false, {
    fileName: "/app/src/components/ui/Table.jsx",
    lineNumber: 51,
    columnNumber: 10
  }, this);
}
_c6 = Td;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "Table");
$RefreshReg$(_c2, "THead");
$RefreshReg$(_c3, "TBody");
$RefreshReg$(_c4, "Tr");
$RefreshReg$(_c5, "Th");
$RefreshReg$(_c6, "Td");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/Table.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/Table.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQ1M7Ozs7Ozs7Ozs7Ozs7Ozs7QUFERixnQkFBU0EsTUFBTSxFQUFFQyxZQUFZLElBQUksR0FBR0MsTUFBTSxHQUFHO0FBQ2xELFNBQU8sdUJBQUMsV0FBTSxXQUFXLDRCQUE0QkQsU0FBUyxJQUFJLEdBQUlDLFNBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUU7QUFDOUU7QUFBQ0MsS0FGZUg7QUFJVCxnQkFBU0ksTUFBTSxFQUFFSCxZQUFZLElBQUksR0FBR0MsTUFBTSxHQUFHO0FBQ2xELFNBQU8sdUJBQUMsV0FBTSxXQUFXLHlDQUF5Q0QsU0FBUyxJQUFJLEdBQUlDLFNBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBa0Y7QUFDM0Y7QUFBQ0csTUFGZUQ7QUFJVCxnQkFBU0UsTUFBTSxFQUFFTCxZQUFZLElBQUksR0FBR0MsTUFBTSxHQUFHO0FBQ2xELFNBQU8sdUJBQUMsV0FBTSxXQUFzQixHQUFJQSxTQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXVDO0FBQ2hEO0FBQUNLLE1BRmVEO0FBSVQsZ0JBQVNFLEdBQUcsRUFBRVAsWUFBWSxJQUFJLEdBQUdDLE1BQU0sR0FBRztBQUMvQyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXLCtFQUErRUQsU0FBUztBQUFBLE1BQ25HLEdBQUlDO0FBQUFBO0FBQUFBLElBRk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBRVk7QUFHaEI7QUFBQ08sTUFQZUQ7QUFTVCxnQkFBU0UsR0FBRyxFQUFFVCxZQUFZLElBQUksR0FBR0MsTUFBTSxHQUFHO0FBQy9DLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVcsMEVBQTBFRCxTQUFTO0FBQUEsTUFDOUYsR0FBSUM7QUFBQUE7QUFBQUEsSUFGTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFFWTtBQUdoQjtBQUFDUyxNQVBlRDtBQVNULGdCQUFTRSxHQUFHLEVBQUVYLFlBQVksSUFBSSxHQUFHQyxNQUFNLEdBQUc7QUFDL0MsU0FBTyx1QkFBQyxRQUFHLFdBQVcsNEJBQTRCRCxTQUFTLElBQUksR0FBSUMsU0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFrRTtBQUMzRTtBQUFDVyxNQUZlRDtBQUFFLElBQUFULElBQUFFLEtBQUFFLEtBQUFFLEtBQUFFLEtBQUFFO0FBQUEsYUFBQVYsSUFBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRSxLQUFBIiwibmFtZXMiOlsiVGFibGUiLCJjbGFzc05hbWUiLCJwcm9wcyIsIl9jIiwiVEhlYWQiLCJfYzIiLCJUQm9keSIsIl9jMyIsIlRyIiwiX2M0IiwiVGgiLCJfYzUiLCJUZCIsIl9jNiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYWJsZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGZ1bmN0aW9uIFRhYmxlKHsgY2xhc3NOYW1lID0gJycsIC4uLnByb3BzIH0pIHtcclxuICByZXR1cm4gPHRhYmxlIGNsYXNzTmFtZT17YHctZnVsbCB0ZXh0LWxlZnQgdGV4dC1zbSAke2NsYXNzTmFtZX1gfSB7Li4ucHJvcHN9IC8+O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVEhlYWQoeyBjbGFzc05hbWUgPSAnJywgLi4ucHJvcHMgfSkge1xyXG4gIHJldHVybiA8dGhlYWQgY2xhc3NOYW1lPXtgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS01MCAke2NsYXNzTmFtZX1gfSB7Li4ucHJvcHN9IC8+O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVEJvZHkoeyBjbGFzc05hbWUgPSAnJywgLi4ucHJvcHMgfSkge1xyXG4gIHJldHVybiA8dGJvZHkgY2xhc3NOYW1lPXtjbGFzc05hbWV9IHsuLi5wcm9wc30gLz47XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBUcih7IGNsYXNzTmFtZSA9ICcnLCAuLi5wcm9wcyB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDx0clxyXG4gICAgICBjbGFzc05hbWU9e2Bib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIHRyYW5zaXRpb24tY29sb3JzIGxhc3Q6Ym9yZGVyLTAgaG92ZXI6Ymctc2xhdGUtNTAgJHtjbGFzc05hbWV9YH1cclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgLz5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVGgoeyBjbGFzc05hbWUgPSAnJywgLi4ucHJvcHMgfSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8dGhcclxuICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0zIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFja2luZy13aWRlIHRleHQtc2xhdGUtNjAwIHVwcGVyY2FzZSAke2NsYXNzTmFtZX1gfVxyXG4gICAgICB7Li4ucHJvcHN9XHJcbiAgICAvPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBUZCh7IGNsYXNzTmFtZSA9ICcnLCAuLi5wcm9wcyB9KSB7XHJcbiAgcmV0dXJuIDx0ZCBjbGFzc05hbWU9e2BweC00IHB5LTMgdGV4dC1zbGF0ZS03MDAgJHtjbGFzc05hbWV9YH0gey4uLnByb3BzfSAvPjtcclxufVxyXG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvdWkvVGFibGUuanN4In0=