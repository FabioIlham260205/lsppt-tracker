import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/HistoryPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6eb1056b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/pages/HistoryPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6eb1056b"; const Fragment2 = __vite__cjsImport3_react["Fragment"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import {
  Badge,
  Button,
  DatePicker,
  EmptyState,
  Input,
  Loading,
  Modal,
  Select,
  Table,
  TBody,
  Td,
  Th,
  THead,
  Tr,
  useToast
} from "/src/components/ui/index.js";
import { getEmployees, getHistory, getTaskHistory, exportHistory } from "/src/api/lsppt.js";
const STATUS_VARIANT = {
  Completed: "success",
  "Completed Testing": "success",
  Documentation: "info",
  "In Progress": "info",
  "On Hold": "danger",
  Plan: "neutral",
  "Completed with Feedback": "warning",
  Testing: "warning",
  "On Queue Testing": "warning"
};
const DOT_BORDER = {
  success: "border-green-500",
  info: "border-blue-500",
  warning: "border-amber-500",
  danger: "border-red-500",
  neutral: "border-slate-400"
};
const DOT_FILL = {
  success: "bg-green-500",
  info: "bg-blue-500",
  warning: "bg-amber-500",
  danger: "bg-red-500",
  neutral: "bg-slate-400"
};
const TIME_PERIODS = {
  "minggu-ini": "Minggu Ini",
  "bulan-ini": "Bulan Ini",
  "tahun-ini": "Tahun Ini",
  "semua": "Semua"
};
function toISODate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
function defaultRange() {
  const now = /* @__PURE__ */ new Date();
  return {
    from: toISODate(new Date(now.getFullYear(), now.getMonth(), 1)),
    to: toISODate(now)
  };
}
function getPeriodRange(period) {
  const now = /* @__PURE__ */ new Date();
  switch (period) {
    case "minggu-ini": {
      const dayOfWeek = now.getDay();
      const startOfWeek = new Date(now);
      startOfWeek.setDate(now.getDate() - dayOfWeek);
      return { from: toISODate(startOfWeek), to: toISODate(now) };
    }
    case "bulan-ini":
      return { from: toISODate(new Date(now.getFullYear(), now.getMonth(), 1)), to: toISODate(now) };
    case "tahun-ini":
      return { from: toISODate(new Date(now.getFullYear(), 0, 1)), to: toISODate(now) };
    case "semua":
      return { from: "", to: "" };
    default:
      return defaultRange();
  }
}
const DATE_FMT = new Intl.DateTimeFormat("id-ID", {
  day: "numeric",
  month: "short",
  year: "numeric"
});
function formatDate(iso) {
  if (!iso) return "-";
  return DATE_FMT.format(new Date(iso));
}
function StatusBadge({ status }) {
  return /* @__PURE__ */ jsxDEV(Badge, { variant: STATUS_VARIANT[status] || "neutral", children: status }, void 0, false, {
    fileName: "/app/src/pages/HistoryPage.jsx",
    lineNumber: 122,
    columnNumber: 10
  }, this);
}
_c = StatusBadge;
function TimelineDot({ variant, isLatest }) {
  return /* @__PURE__ */ jsxDEV(
    "span",
    {
      "aria-hidden": "true",
      className: `absolute -left-[9px] top-1 h-4 w-4 rounded-full border-2 bg-white ${DOT_BORDER[variant]} ${isLatest ? DOT_FILL[variant] : ""}`
    },
    void 0,
    false,
    {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 127,
      columnNumber: 5
    },
    this
  );
}
_c2 = TimelineDot;
function DetailModal({ open, onClose, row }) {
  _s();
  const [entries, setEntries] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  function loadHistory() {
    if (!row) return;
    setLoading(true);
    setError(null);
    getTaskHistory(row.task_id).then((res) => setEntries(res.data)).catch((err) => setError(err?.message || "Terjadi kesalahan tak terduga.")).finally(() => setLoading(false));
  }
  useEffect(() => {
    if (!open || !row) return void 0;
    loadHistory();
    return () => {
    };
  }, [open, row]);
  const lastUpdated = entries?.length ? entries[entries.length - 1].date : null;
  return /* @__PURE__ */ jsxDEV(Modal, { open, onClose, title: row ? row.task : "Detail Task", size: "lg", children: row && /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-5", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-slate-400", children: "Karyawan" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 165,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-0.5 text-sm font-medium text-slate-800", children: row.employee }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 166,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 164,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-slate-400", children: "ClickUp ID" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 169,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-0.5 font-mono text-xs text-slate-700", children: row.clickup_task_id }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 170,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 168,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-slate-400", children: "Phase saat ini" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 173,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm font-medium text-slate-800", children: row.phase }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 174,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 172,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-slate-400", children: "Status saat ini" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 177,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1", children: /* @__PURE__ */ jsxDEV(StatusBadge, { status: row.status }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 179,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 178,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 176,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-slate-400", children: "Last Updated" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 183,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-0.5 text-sm font-medium text-slate-800", children: lastUpdated ? formatDate(lastUpdated) : "-" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 184,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 182,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 163,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-5 border-t border-slate-100 pt-5", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-wider text-slate-400", children: "Riwayat Progress" }, void 0, false, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 191,
        columnNumber: 13
      }, this),
      loading && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-3 py-10", role: "status", "aria-busy": "true", children: [
        /* @__PURE__ */ jsxDEV(Loading, { size: "md" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 197,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500", children: "Memuat riwayat progress…" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 198,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 196,
        columnNumber: 11
      }, this),
      !loading && error && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-3 py-8", role: "alert", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-600", children: error }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 204,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-400", children: "Riwayat progress tidak dapat dimuat." }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 205,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: loadHistory, children: "Coba Lagi" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 208,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 203,
        columnNumber: 11
      }, this),
      !loading && !error && entries && entries.length > 0 && /* @__PURE__ */ jsxDEV("ol", { className: "relative ml-2 mt-4 border-l-2 border-slate-100", "aria-label": "Riwayat progress", children: entries.map((entry, index) => {
        const variant = STATUS_VARIANT[entry.status] || "neutral";
        const isLatest = index === entries.length - 1;
        const prevEntry = index > 0 ? entries[index - 1] : null;
        const phaseChanged = prevEntry && prevEntry.phase !== entry.phase;
        return /* @__PURE__ */ jsxDEV(Fragment2, { children: [
          phaseChanged && /* @__PURE__ */ jsxDEV("li", { className: "relative pb-3 pl-7", "aria-hidden": "true", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "absolute -left-[9px] top-1 h-4 w-4 rounded-full border-2 border-dashed border-slate-300 bg-white" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 225,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-slate-400", children: [
              "Phase: ",
              prevEntry.phase,
              " → ",
              entry.phase
            ] }, void 0, true, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 226,
              columnNumber: 27
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 224,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("li", { className: `relative ${phaseChanged ? "pt-1" : ""} pb-6 pl-7 last:pb-1`, children: [
            /* @__PURE__ */ jsxDEV(TimelineDot, { variant, isLatest }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 232,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `text-sm ${isLatest ? "font-semibold text-slate-800" : "text-slate-600"}`,
                  children: formatDate(entry.date)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/pages/HistoryPage.jsx",
                  lineNumber: 234,
                  columnNumber: 27
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-400", children: entry.phase }, void 0, false, {
                  fileName: "/app/src/pages/HistoryPage.jsx",
                  lineNumber: 242,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(StatusBadge, { status: entry.status }, void 0, false, {
                  fileName: "/app/src/pages/HistoryPage.jsx",
                  lineNumber: 243,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/pages/HistoryPage.jsx",
                lineNumber: 241,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 233,
              columnNumber: 25
            }, this),
            isLatest && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-slate-400", children: "Kondisi terakhir tugas ini." }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 247,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 231,
            columnNumber: 23
          }, this)
        ] }, `${entry.date}-${entry.status}`, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 222,
          columnNumber: 17
        }, this);
      }) }, void 0, false, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 215,
        columnNumber: 11
      }, this),
      !loading && !error && entries && entries.length === 0 && /* @__PURE__ */ jsxDEV("p", { className: "py-6 text-sm text-slate-500", children: "Task ini belum memiliki riwayat progress yang tercatat." }, void 0, false, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 257,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 190,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex justify-end border-t border-slate-100 pt-4", children: /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: onClose, children: "Tutup" }, void 0, false, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 262,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 261,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/pages/HistoryPage.jsx",
    lineNumber: 162,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/app/src/pages/HistoryPage.jsx",
    lineNumber: 160,
    columnNumber: 5
  }, this);
}
_s(DetailModal, "Z1cssbkz4LRIFSa5T8wo6tJl7K4=");
_c3 = DetailModal;
export default function HistoryPage() {
  _s2();
  const initialRange = useMemo(defaultRange, []);
  const [employees, setEmployees] = useState([]);
  const [employeeId, setEmployeeId] = useState("");
  const [from, setFrom] = useState(initialRange.from);
  const [to, setTo] = useState(initialRange.to);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [activePeriod, setActivePeriod] = useState("bulan-ini");
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedRow, setSelectedRow] = useState(null);
  const [exporting, setExporting] = useState(false);
  const { showToast } = useToast();
  useEffect(() => {
    let cancelled = false;
    getEmployees().then((res) => {
      if (!cancelled) setEmployees(res.data);
    }).catch(() => {
    });
    return () => {
      cancelled = true;
    };
  }, []);
  function loadHistory() {
    setLoading(true);
    setError(null);
    getHistory({ employee_id: employeeId || void 0, from: from || void 0, to: to || void 0 }).then((res) => setRows(res.data)).catch((err) => setError(err?.message || "Terjadi kesalahan tak terduga.")).finally(() => setLoading(false));
  }
  useEffect(() => {
    loadHistory();
  }, [employeeId, from, to]);
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(timer);
  }, [search]);
  const dateInvalid = Boolean(from && to && from > to);
  const employeeName = employees.find((e) => String(e.id) === employeeId)?.name;
  const filtered = useMemo(() => {
    const query = debouncedSearch.trim().toLowerCase();
    return rows.filter((row) => {
      if (employeeName && row.employee !== employeeName) return false;
      if (from && row.date < from) return false;
      if (to && row.date > to) return false;
      if (query) {
        const haystack = `${row.task} ${row.clickup_task_id} ${row.employee} ${row.phase} ${row.status}`.toLowerCase();
        if (!haystack.includes(query)) return false;
      }
      return true;
    }).sort((a, b) => b.date.localeCompare(a.date));
  }, [rows, employeeName, from, to, debouncedSearch]);
  const hasActiveFilter = Boolean(employeeId) || Boolean(search.trim()) || activePeriod !== "bulan-ini" || from !== initialRange.from || to !== initialRange.to;
  function resetFilters() {
    setEmployeeId("");
    setSearch("");
    setDebouncedSearch("");
    setActivePeriod("bulan-ini");
    setFrom(initialRange.from);
    setTo(initialRange.to);
  }
  function handlePeriodChange(period) {
    setActivePeriod(period);
    const range = getPeriodRange(period);
    setFrom(range.from);
    setTo(range.to);
  }
  function openDetail(row) {
    setSelectedRow(row);
  }
  function handleRowClick(event, row) {
    if (event.target.closest("button")) return;
    openDetail(row);
  }
  function handleExport() {
    setExporting(true);
    exportHistory({ employee_id: employeeId || void 0, from: from || void 0, to: to || void 0 }).then(() => {
      showToast({ type: "success", title: "Ekspor selesai", message: "File berhasil diunduh." });
    }).catch((err) => {
      showToast({ type: "error", title: "Gagal mengekspor", message: err?.message || "Terjadi kesalahan tak terduga." });
    }).finally(() => setExporting(false));
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-slate-50", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto max-w-5xl px-4 py-6 sm:px-8 sm:py-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end justify-between gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-slate-800", children: "History" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 390,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-slate-500", children: "Rekap progres LSPPT harian semua karyawan." }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 391,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 389,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: "/submit", className: "text-sm text-blue-600 hover:underline", children: "← Kembali ke Submit" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 395,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 388,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "mt-6 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-6", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: (e) => e.preventDefault(), className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1fr_1.4fr_auto] lg:items-end", children: [
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            label: "Karyawan",
            placeholder: "Semua karyawan",
            options: employees.map((e) => ({ value: String(e.id), label: e.name })),
            value: employeeId,
            onChange: (e) => setEmployeeId(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 402,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          DatePicker,
          {
            label: "Dari Tanggal",
            value: from,
            onChange: (e) => {
              setFrom(e.target.value);
              setActivePeriod("custom");
            },
            max: to || void 0,
            error: dateInvalid ? "Lebih besar dari tanggal akhir" : void 0
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 409,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          DatePicker,
          {
            label: "Sampai Tanggal",
            value: to,
            onChange: (e) => {
              setTo(e.target.value);
              setActivePeriod("custom");
            },
            min: from || void 0,
            error: dateInvalid ? "Lebih kecil dari tanggal mulai" : void 0
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 419,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            label: "Cari",
            type: "text",
            placeholder: "Cari tugas atau ClickUp ID…",
            value: search,
            onChange: (e) => setSearch(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 429,
            columnNumber: 13
          },
          this
        ),
        hasActiveFilter && /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "outline", onClick: resetFilters, children: "Reset Filter" }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 437,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 401,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 400,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "mt-4 rounded-xl border border-slate-200 bg-white shadow-sm", children: [
        !loading && !error && !dateInvalid && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 px-4 py-3 sm:px-6", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-slate-500", children: [
            filtered.length,
            " entri ditemukan"
          ] }, void 0, true, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 447,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "hidden sm:flex items-center gap-1 rounded-lg bg-slate-100 p-1", children: Object.entries(TIME_PERIODS).map(
              ([key, label]) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => handlePeriodChange(key),
                  className: `rounded-md px-3 py-1 text-xs font-medium text-center min-w-[72px] transition-colors ${activePeriod === key ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"}`,
                  children: label
                },
                key,
                false,
                {
                  fileName: "/app/src/pages/HistoryPage.jsx",
                  lineNumber: 453,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 451,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: `hidden text-xs text-slate-400 lg:block min-w-[140px] text-right ${!(from || to) && "invisible"}`, children: from || to ? `${formatDate(from)} – ${formatDate(to)}` : " " }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 467,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "sm",
                variant: "outline",
                loading: exporting,
                disabled: dateInvalid || loading || filtered.length === 0,
                onClick: handleExport,
                children: "Export Excel"
              },
              void 0,
              false,
              {
                fileName: "/app/src/pages/HistoryPage.jsx",
                lineNumber: 470,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 450,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 446,
          columnNumber: 11
        }, this),
        dateInvalid ? /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-[280px] flex-col items-center justify-center gap-2 px-6 py-12 text-center", role: "alert", children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "h-10 w-10 text-amber-400", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: "1.5", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 486,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 485,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-slate-700", children: "Rentang tanggal tidak valid" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 488,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "max-w-xs text-xs text-slate-400", children: "Tanggal akhir lebih awal dari tanggal mulai. Sesuaikan salah satu tanggal untuk melihat history." }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 489,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 484,
          columnNumber: 11
        }, this) : loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-[280px] flex-col items-center justify-center gap-3 px-6 py-12", role: "status", "aria-busy": "true", children: [
          /* @__PURE__ */ jsxDEV(Loading, { size: "lg" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 495,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500", children: "Memuat riwayat…" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 496,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 494,
          columnNumber: 11
        }, this) : error ? /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-[280px] flex-col items-center justify-center gap-3 px-6 py-12 text-center", role: "alert", children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "h-10 w-10 text-red-400", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: "1.5", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M12 9v3.75m0 3.75h.008v.008H12m-9.303-3.382c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 501,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 500,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-slate-700", children: "Gagal memuat data" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 503,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "max-w-xs text-xs text-slate-400", children: error }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 504,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: loadHistory, children: "Coba Lagi" }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 505,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 499,
          columnNumber: 11
        }, this) : filtered.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-4 sm:p-6", children: /* @__PURE__ */ jsxDEV(
          EmptyState,
          {
            title: "Belum ada data yang cocok",
            description: "Tidak ada entri history sesuai filter saat ini. Coba ubah karyawan, rentang tanggal, atau kata kunci pencarian.",
            action: hasActiveFilter ? /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: resetFilters, children: "Reset Filter" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 516,
              columnNumber: 15
            }, this) : void 0
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 511,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 510,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV(Table, { className: "min-w-[760px]", children: [
          /* @__PURE__ */ jsxDEV(THead, { children: /* @__PURE__ */ jsxDEV(Tr, { children: [
            /* @__PURE__ */ jsxDEV(Th, { children: "Karyawan" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 528,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Tanggal" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 529,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Tugas" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 530,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "ClickUp ID" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 531,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Phase" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 532,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Status" }, void 0, false, {
              fileName: "/app/src/pages/HistoryPage.jsx",
              lineNumber: 533,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 527,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 526,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TBody, { children: filtered.map(
            (row) => /* @__PURE__ */ jsxDEV(
              Tr,
              {
                tabIndex: 0,
                "aria-label": `Buka detail tugas ${row.task}`,
                onClick: (e) => handleRowClick(e, row),
                onKeyDown: (e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    openDetail(row);
                  }
                },
                className: "group cursor-pointer transition-colors duration-150 hover:bg-slate-50 focus-visible:bg-blue-50/60 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-blue-600",
                children: [
                  /* @__PURE__ */ jsxDEV(Td, { className: "whitespace-nowrap font-medium text-slate-800", children: row.employee }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 551,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Td, { className: "whitespace-nowrap", children: formatDate(row.date) }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 552,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => openDetail(row),
                      className: "text-left font-medium text-blue-600 group-hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "block max-w-[260px] truncate", title: row.task, children: row.task }, void 0, false, {
                        fileName: "/app/src/pages/HistoryPage.jsx",
                        lineNumber: 559,
                        columnNumber: 27
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/pages/HistoryPage.jsx",
                      lineNumber: 554,
                      columnNumber: 25
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 553,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Td, { className: "whitespace-nowrap font-mono text-xs text-slate-500", children: row.clickup_task_id }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 564,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Td, { children: row.phase }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 567,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV(StatusBadge, { status: row.status }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 569,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "/app/src/pages/HistoryPage.jsx",
                    lineNumber: 568,
                    columnNumber: 23
                  }, this)
                ]
              },
              row.id,
              true,
              {
                fileName: "/app/src/pages/HistoryPage.jsx",
                lineNumber: 538,
                columnNumber: 17
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/app/src/pages/HistoryPage.jsx",
            lineNumber: 536,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 525,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/app/src/pages/HistoryPage.jsx",
          lineNumber: 524,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/HistoryPage.jsx",
        lineNumber: 444,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 387,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DetailModal, { open: Boolean(selectedRow), onClose: () => setSelectedRow(null), row: selectedRow }, void 0, false, {
      fileName: "/app/src/pages/HistoryPage.jsx",
      lineNumber: 580,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/pages/HistoryPage.jsx",
    lineNumber: 386,
    columnNumber: 5
  }, this);
}
_s2(HistoryPage, "UoCKF0Rg6nfRqGD/sAleV8Fsdfk=", false, function() {
  return [useToast];
});
_c4 = HistoryPage;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "StatusBadge");
$RefreshReg$(_c2, "TimelineDot");
$RefreshReg$(_c3, "DetailModal");
$RefreshReg$(_c4, "HistoryPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/pages/HistoryPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/pages/HistoryPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0dTLFNBd0NELFVBeENDOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRHVCxTQUFTQSx1QkFBVUMsV0FBV0MsU0FBU0MsZ0JBQWdCO0FBQ3ZEO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGNBQWNDLFlBQVlDLGdCQUFnQkMscUJBQXFCO0FBRXhFLE1BQU1DLGlCQUFpQjtBQUFBLEVBQ3JCQyxXQUFXO0FBQUEsRUFDWCxxQkFBcUI7QUFBQSxFQUNyQkMsZUFBZTtBQUFBLEVBQ2YsZUFBZTtBQUFBLEVBQ2YsV0FBVztBQUFBLEVBQ1hDLE1BQU07QUFBQSxFQUNOLDJCQUEyQjtBQUFBLEVBQzNCQyxTQUFTO0FBQUEsRUFDVCxvQkFBb0I7QUFDdEI7QUFFQSxNQUFNQyxhQUFhO0FBQUEsRUFDakJDLFNBQVM7QUFBQSxFQUNUQyxNQUFNO0FBQUEsRUFDTkMsU0FBUztBQUFBLEVBQ1RDLFFBQVE7QUFBQSxFQUNSQyxTQUFTO0FBQ1g7QUFFQSxNQUFNQyxXQUFXO0FBQUEsRUFDZkwsU0FBUztBQUFBLEVBQ1RDLE1BQU07QUFBQSxFQUNOQyxTQUFTO0FBQUEsRUFDVEMsUUFBUTtBQUFBLEVBQ1JDLFNBQVM7QUFDWDtBQUVBLE1BQU1FLGVBQWU7QUFBQSxFQUNuQixjQUFjO0FBQUEsRUFDZCxhQUFhO0FBQUEsRUFDYixhQUFhO0FBQUEsRUFDYixTQUFTO0FBQ1g7QUFFQSxTQUFTQyxVQUFVQyxNQUFNO0FBQ3ZCLFFBQU1DLE9BQU9ELEtBQUtFLFlBQVk7QUFDOUIsUUFBTUMsUUFBUUMsT0FBT0osS0FBS0ssU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDekQsUUFBTUMsTUFBTUgsT0FBT0osS0FBS1EsUUFBUSxDQUFDLEVBQUVGLFNBQVMsR0FBRyxHQUFHO0FBQ2xELFNBQU8sR0FBR0wsSUFBSSxJQUFJRSxLQUFLLElBQUlJLEdBQUc7QUFDaEM7QUFFQSxTQUFTRSxlQUFlO0FBQ3RCLFFBQU1DLE1BQU0sb0JBQUlDLEtBQUs7QUFDckIsU0FBTztBQUFBLElBQ0xDLE1BQU1iLFVBQVUsSUFBSVksS0FBS0QsSUFBSVIsWUFBWSxHQUFHUSxJQUFJTCxTQUFTLEdBQUcsQ0FBQyxDQUFDO0FBQUEsSUFDOURRLElBQUlkLFVBQVVXLEdBQUc7QUFBQSxFQUNuQjtBQUNGO0FBRUEsU0FBU0ksZUFBZUMsUUFBUTtBQUM5QixRQUFNTCxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFVBQVFJLFFBQU07QUFBQSxJQUNaLEtBQUssY0FBYztBQUNqQixZQUFNQyxZQUFZTixJQUFJTyxPQUFPO0FBQzdCLFlBQU1DLGNBQWMsSUFBSVAsS0FBS0QsR0FBRztBQUNoQ1Esa0JBQVlDLFFBQVFULElBQUlGLFFBQVEsSUFBSVEsU0FBUztBQUM3QyxhQUFPLEVBQUVKLE1BQU1iLFVBQVVtQixXQUFXLEdBQUdMLElBQUlkLFVBQVVXLEdBQUcsRUFBRTtBQUFBLElBQzVEO0FBQUEsSUFDQSxLQUFLO0FBQ0gsYUFBTyxFQUFFRSxNQUFNYixVQUFVLElBQUlZLEtBQUtELElBQUlSLFlBQVksR0FBR1EsSUFBSUwsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHUSxJQUFJZCxVQUFVVyxHQUFHLEVBQUU7QUFBQSxJQUMvRixLQUFLO0FBQ0gsYUFBTyxFQUFFRSxNQUFNYixVQUFVLElBQUlZLEtBQUtELElBQUlSLFlBQVksR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHVyxJQUFJZCxVQUFVVyxHQUFHLEVBQUU7QUFBQSxJQUNsRixLQUFLO0FBQ0gsYUFBTyxFQUFFRSxNQUFNLElBQUlDLElBQUksR0FBRztBQUFBLElBQzVCO0FBQ0UsYUFBT0osYUFBYTtBQUFBLEVBQ3hCO0FBQ0Y7QUFFQSxNQUFNVyxXQUFXLElBQUlDLEtBQUtDLGVBQWUsU0FBUztBQUFBLEVBQ2hEZixLQUFLO0FBQUEsRUFDTEosT0FBTztBQUFBLEVBQ1BGLE1BQU07QUFDUixDQUFDO0FBRUQsU0FBU3NCLFdBQVdDLEtBQUs7QUFDdkIsTUFBSSxDQUFDQSxJQUFLLFFBQU87QUFDakIsU0FBT0osU0FBU0ssT0FBTyxJQUFJZCxLQUFLYSxHQUFHLENBQUM7QUFDdEM7QUFFQSxTQUFTRSxZQUFZLEVBQUVDLE9BQU8sR0FBRztBQUMvQixTQUFPLHVCQUFDLFNBQU0sU0FBU3pDLGVBQWV5QyxNQUFNLEtBQUssV0FBWUEsb0JBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkQ7QUFDdEU7QUFBQ0MsS0FGUUY7QUFJVCxTQUFTRyxZQUFZLEVBQUVDLFNBQVNDLFNBQVMsR0FBRztBQUMxQyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxlQUFZO0FBQUEsTUFDWixXQUFXLHFFQUNUeEMsV0FBV3VDLE9BQU8sQ0FBQyxJQUNqQkMsV0FBV2xDLFNBQVNpQyxPQUFPLElBQUksRUFBRTtBQUFBO0FBQUEsSUFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSTBDO0FBRzlDO0FBQUNFLE1BVFFIO0FBV1QsU0FBU0ksWUFBWSxFQUFFQyxNQUFNQyxTQUFTQyxJQUFJLEdBQUc7QUFBQUMsS0FBQTtBQUMzQyxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSXpFLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUMwRSxTQUFTQyxVQUFVLElBQUkzRSxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDNEUsT0FBT0MsUUFBUSxJQUFJN0UsU0FBUyxJQUFJO0FBRXZDLFdBQVM4RSxjQUFjO0FBQ3JCLFFBQUksQ0FBQ1IsSUFBSztBQUNWSyxlQUFXLElBQUk7QUFDZkUsYUFBUyxJQUFJO0FBQ2IzRCxtQkFBZW9ELElBQUlTLE9BQU8sRUFDdkJDLEtBQUssQ0FBQ0MsUUFBUVIsV0FBV1EsSUFBSUMsSUFBSSxDQUFDLEVBQ2xDQyxNQUFNLENBQUNDLFFBQVFQLFNBQVNPLEtBQUtDLFdBQVcsZ0NBQWdDLENBQUMsRUFDekVDLFFBQVEsTUFBTVgsV0FBVyxLQUFLLENBQUM7QUFBQSxFQUNwQztBQUVBN0UsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDc0UsUUFBUSxDQUFDRSxJQUFLLFFBQU9pQjtBQUMxQlQsZ0JBQVk7QUFDWixXQUFPLE1BQU07QUFBQSxJQUFDO0FBQUEsRUFDaEIsR0FBRyxDQUFDVixNQUFNRSxHQUFHLENBQUM7QUFFZCxRQUFNa0IsY0FBY2hCLFNBQVNpQixTQUFTakIsUUFBUUEsUUFBUWlCLFNBQVMsQ0FBQyxFQUFFdkQsT0FBTztBQUV6RSxTQUNFLHVCQUFDLFNBQU0sTUFBWSxTQUFrQixPQUFPb0MsTUFBTUEsSUFBSW9CLE9BQU8sZUFBZSxNQUFLLE1BQzlFcEIsaUJBQ0MsbUNBQ0U7QUFBQSwyQkFBQyxRQUFHLFdBQVUsbURBQ1o7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDBCQUF5Qix3QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQztBQUFBLFFBQy9DLHVCQUFDLFFBQUcsV0FBVSw2Q0FBNkNBLGNBQUlxQixZQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFO0FBQUEsV0FGMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDBCQUF5QiwwQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ2pELHVCQUFDLFFBQUcsV0FBVSwyQ0FBMkNyQixjQUFJc0IsbUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkU7QUFBQSxXQUYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsMEJBQXlCLDhCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsUUFDckQsdUJBQUMsUUFBRyxXQUFVLDJDQUEyQ3RCLGNBQUl1QixTQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsV0FGckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDBCQUF5QiwrQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFFBQ3RELHVCQUFDLFFBQUcsV0FBVSxRQUNaLGlDQUFDLGVBQVksUUFBUXZCLElBQUlULFVBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsMEJBQXlCLDRCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1EO0FBQUEsUUFDbkQsdUJBQUMsUUFBRyxXQUFVLDZDQUNYMkIsd0JBQWMvQixXQUFXK0IsV0FBVyxJQUFJLE9BRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsNkJBQUMsT0FBRSxXQUFVLGlFQUFnRSxnQ0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQ2QsV0FDQyx1QkFBQyxTQUFJLFdBQVUsMENBQXlDLE1BQUssVUFBUyxhQUFVLFFBQzlFO0FBQUEsK0JBQUMsV0FBUSxNQUFLLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQjtBQUFBLFFBQ2xCLHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsd0NBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEQ7QUFBQSxXQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUdELENBQUNBLFdBQVdFLFNBQ1gsdUJBQUMsU0FBSSxXQUFVLHlDQUF3QyxNQUFLLFNBQzFEO0FBQUEsK0JBQUMsT0FBRSxXQUFVLHdCQUF3QkEsbUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkM7QUFBQSxRQUMzQyx1QkFBQyxPQUFFLFdBQVUsMEJBQXlCLG9EQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsV0FBVSxTQUFTRSxhQUFhLHlCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BR0QsQ0FBQ0osV0FBVyxDQUFDRSxTQUFTSixXQUFXQSxRQUFRaUIsU0FBUyxLQUNqRCx1QkFBQyxRQUFHLFdBQVUsa0RBQWlELGNBQVcsb0JBQ3ZFakIsa0JBQVFzQixJQUFJLENBQUNDLE9BQU9DLFVBQVU7QUFDN0IsY0FBTWhDLFVBQVU1QyxlQUFlMkUsTUFBTWxDLE1BQU0sS0FBSztBQUNoRCxjQUFNSSxXQUFXK0IsVUFBVXhCLFFBQVFpQixTQUFTO0FBQzVDLGNBQU1RLFlBQVlELFFBQVEsSUFBSXhCLFFBQVF3QixRQUFRLENBQUMsSUFBSTtBQUNuRCxjQUFNRSxlQUFlRCxhQUFhQSxVQUFVSixVQUFVRSxNQUFNRjtBQUM1RCxlQUNFLHVCQUFDaEcsV0FBQSxFQUNFcUc7QUFBQUEsMEJBQ0MsdUJBQUMsUUFBRyxXQUFVLHNCQUFxQixlQUFZLFFBQzdDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHNHQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSDtBQUFBLFlBQ2xILHVCQUFDLFVBQUssV0FBVSx5SkFBd0o7QUFBQTtBQUFBLGNBQzlKRCxVQUFVSjtBQUFBQSxjQUFNO0FBQUEsY0FBSUUsTUFBTUY7QUFBQUEsaUJBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUVGLHVCQUFDLFFBQUcsV0FBVyxZQUFZSyxlQUFlLFNBQVMsRUFBRSx3QkFDbkQ7QUFBQSxtQ0FBQyxlQUFZLFNBQWtCLFlBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtEO0FBQUEsWUFDbEQsdUJBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxXQUNUakMsV0FBVyxpQ0FBaUMsZ0JBQWdCO0FBQUEsa0JBRzdEUixxQkFBV3NDLE1BQU03RCxJQUFJO0FBQUE7QUFBQSxnQkFMeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSwyQkFDZDtBQUFBLHVDQUFDLFVBQUssV0FBVSwwQkFBMEI2RCxnQkFBTUYsU0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0Q7QUFBQSxnQkFDdEQsdUJBQUMsZUFBWSxRQUFRRSxNQUFNbEMsVUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0M7QUFBQSxtQkFGcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUNDSSxZQUNDLHVCQUFDLE9BQUUsV0FBVSwrQkFBOEIsMkNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsZUFoQjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsYUEzQmEsR0FBRzhCLE1BQU03RCxJQUFJLElBQUk2RCxNQUFNbEMsTUFBTSxJQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBO0FBQUEsTUFFSixDQUFDLEtBckNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQ0E7QUFBQSxNQUdELENBQUNhLFdBQVcsQ0FBQ0UsU0FBU0osV0FBV0EsUUFBUWlCLFdBQVcsS0FDbkQsdUJBQUMsT0FBRSxXQUFVLCtCQUE4Qix1RUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRztBQUFBLFNBbkV0RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2IsaUNBQUMsVUFBTyxTQUFRLFdBQVUsU0FBU3BCLFNBQVMscUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLE9BdkdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3R0EsS0ExR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRHQTtBQUVKO0FBQUNFLEdBdElRSixhQUFXO0FBQUEsTUFBWEE7QUF3SVQsd0JBQXdCZ0MsY0FBYztBQUFBQyxNQUFBO0FBQ3BDLFFBQU1DLGVBQWV0RyxRQUFRNEMsY0FBYyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzJELFdBQVdDLFlBQVksSUFBSXZHLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUN3RyxZQUFZQyxhQUFhLElBQUl6RyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDOEMsTUFBTTRELE9BQU8sSUFBSTFHLFNBQVNxRyxhQUFhdkQsSUFBSTtBQUNsRCxRQUFNLENBQUNDLElBQUk0RCxLQUFLLElBQUkzRyxTQUFTcUcsYUFBYXRELEVBQUU7QUFDNUMsUUFBTSxDQUFDNkQsUUFBUUMsU0FBUyxJQUFJN0csU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzhHLGlCQUFpQkMsa0JBQWtCLElBQUkvRyxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDZ0gsY0FBY0MsZUFBZSxJQUFJakgsU0FBUyxXQUFXO0FBRTVELFFBQU0sQ0FBQ2tILE1BQU1DLE9BQU8sSUFBSW5ILFNBQVMsRUFBRTtBQUNuQyxRQUFNLENBQUMwRSxTQUFTQyxVQUFVLElBQUkzRSxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDNEUsT0FBT0MsUUFBUSxJQUFJN0UsU0FBUyxJQUFJO0FBRXZDLFFBQU0sQ0FBQ29ILGFBQWFDLGNBQWMsSUFBSXJILFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUNzSCxXQUFXQyxZQUFZLElBQUl2SCxTQUFTLEtBQUs7QUFDaEQsUUFBTSxFQUFFd0gsVUFBVSxJQUFJekcsU0FBUztBQUUvQmpCLFlBQVUsTUFBTTtBQUNkLFFBQUkySCxZQUFZO0FBQ2hCekcsaUJBQWEsRUFDVmdFLEtBQUssQ0FBQ0MsUUFBUTtBQUNiLFVBQUksQ0FBQ3dDLFVBQVdsQixjQUFhdEIsSUFBSUMsSUFBSTtBQUFBLElBQ3ZDLENBQUMsRUFDQUMsTUFBTSxNQUFNO0FBQUEsSUFBQyxDQUFDO0FBQ2pCLFdBQU8sTUFBTTtBQUNYc0Msa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxXQUFTM0MsY0FBYztBQUNyQkgsZUFBVyxJQUFJO0FBQ2ZFLGFBQVMsSUFBSTtBQUNiNUQsZUFBVyxFQUFFeUcsYUFBYWxCLGNBQWNqQixRQUFXekMsTUFBTUEsUUFBUXlDLFFBQVd4QyxJQUFJQSxNQUFNd0MsT0FBVSxDQUFDLEVBQzlGUCxLQUFLLENBQUNDLFFBQVFrQyxRQUFRbEMsSUFBSUMsSUFBSSxDQUFDLEVBQy9CQyxNQUFNLENBQUNDLFFBQVFQLFNBQVNPLEtBQUtDLFdBQVcsZ0NBQWdDLENBQUMsRUFDekVDLFFBQVEsTUFBTVgsV0FBVyxLQUFLLENBQUM7QUFBQSxFQUNwQztBQUVBN0UsWUFBVSxNQUFNO0FBQ2RnRixnQkFBWTtBQUFBLEVBRWQsR0FBRyxDQUFDMEIsWUFBWTFELE1BQU1DLEVBQUUsQ0FBQztBQUV6QmpELFlBQVUsTUFBTTtBQUNkLFVBQU02SCxRQUFRQyxXQUFXLE1BQU1iLG1CQUFtQkgsTUFBTSxHQUFHLEdBQUc7QUFDOUQsV0FBTyxNQUFNaUIsYUFBYUYsS0FBSztBQUFBLEVBQ2pDLEdBQUcsQ0FBQ2YsTUFBTSxDQUFDO0FBRVgsUUFBTWtCLGNBQWNDLFFBQVFqRixRQUFRQyxNQUFNRCxPQUFPQyxFQUFFO0FBRW5ELFFBQU1pRixlQUFlMUIsVUFBVTJCLEtBQUssQ0FBQ0MsTUFBTTVGLE9BQU80RixFQUFFQyxFQUFFLE1BQU0zQixVQUFVLEdBQUc0QjtBQUV6RSxRQUFNQyxXQUFXdEksUUFBUSxNQUFNO0FBQzdCLFVBQU11SSxRQUFReEIsZ0JBQWdCeUIsS0FBSyxFQUFFQyxZQUFZO0FBQ2pELFdBQU90QixLQUNKdUIsT0FBTyxDQUFDbkUsUUFBUTtBQUNmLFVBQUkwRCxnQkFBZ0IxRCxJQUFJcUIsYUFBYXFDLGFBQWMsUUFBTztBQUMxRCxVQUFJbEYsUUFBUXdCLElBQUlwQyxPQUFPWSxLQUFNLFFBQU87QUFDcEMsVUFBSUMsTUFBTXVCLElBQUlwQyxPQUFPYSxHQUFJLFFBQU87QUFDaEMsVUFBSXVGLE9BQU87QUFDVCxjQUFNSSxXQUFXLEdBQUdwRSxJQUFJb0IsSUFBSSxJQUFJcEIsSUFBSXNCLGVBQWUsSUFBSXRCLElBQUlxQixRQUFRLElBQUlyQixJQUFJdUIsS0FBSyxJQUFJdkIsSUFBSVQsTUFBTSxHQUFHMkUsWUFBWTtBQUM3RyxZQUFJLENBQUNFLFNBQVNDLFNBQVNMLEtBQUssRUFBRyxRQUFPO0FBQUEsTUFDeEM7QUFDQSxhQUFPO0FBQUEsSUFDVCxDQUFDLEVBQ0FNLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRTVHLEtBQUs2RyxjQUFjRixFQUFFM0csSUFBSSxDQUFDO0FBQUEsRUFDaEQsR0FBRyxDQUFDZ0YsTUFBTWMsY0FBY2xGLE1BQU1DLElBQUkrRCxlQUFlLENBQUM7QUFFbEQsUUFBTWtDLGtCQUNKakIsUUFBUXZCLFVBQVUsS0FDbEJ1QixRQUFRbkIsT0FBTzJCLEtBQUssQ0FBQyxLQUNyQnZCLGlCQUFpQixlQUNqQmxFLFNBQVN1RCxhQUFhdkQsUUFDdEJDLE9BQU9zRCxhQUFhdEQ7QUFFdEIsV0FBU2tHLGVBQWU7QUFDdEJ4QyxrQkFBYyxFQUFFO0FBQ2hCSSxjQUFVLEVBQUU7QUFDWkUsdUJBQW1CLEVBQUU7QUFDckJFLG9CQUFnQixXQUFXO0FBQzNCUCxZQUFRTCxhQUFhdkQsSUFBSTtBQUN6QjZELFVBQU1OLGFBQWF0RCxFQUFFO0FBQUEsRUFDdkI7QUFFQSxXQUFTbUcsbUJBQW1CakcsUUFBUTtBQUNsQ2dFLG9CQUFnQmhFLE1BQU07QUFDdEIsVUFBTWtHLFFBQVFuRyxlQUFlQyxNQUFNO0FBQ25DeUQsWUFBUXlDLE1BQU1yRyxJQUFJO0FBQ2xCNkQsVUFBTXdDLE1BQU1wRyxFQUFFO0FBQUEsRUFDaEI7QUFFQSxXQUFTcUcsV0FBVzlFLEtBQUs7QUFDdkIrQyxtQkFBZS9DLEdBQUc7QUFBQSxFQUNwQjtBQUVBLFdBQVMrRSxlQUFlQyxPQUFPaEYsS0FBSztBQUNsQyxRQUFJZ0YsTUFBTUMsT0FBT0MsUUFBUSxRQUFRLEVBQUc7QUFDcENKLGVBQVc5RSxHQUFHO0FBQUEsRUFDaEI7QUFFQSxXQUFTbUYsZUFBZTtBQUN0QmxDLGlCQUFhLElBQUk7QUFDakJwRyxrQkFBYyxFQUFFdUcsYUFBYWxCLGNBQWNqQixRQUFXekMsTUFBTUEsUUFBUXlDLFFBQVd4QyxJQUFJQSxNQUFNd0MsT0FBVSxDQUFDLEVBQ2pHUCxLQUFLLE1BQU07QUFDVndDLGdCQUFVLEVBQUVrQyxNQUFNLFdBQVdDLE9BQU8sa0JBQWtCdEUsU0FBUyx5QkFBeUIsQ0FBQztBQUFBLElBQzNGLENBQUMsRUFDQUYsTUFBTSxDQUFDQyxRQUFRO0FBQ2RvQyxnQkFBVSxFQUFFa0MsTUFBTSxTQUFTQyxPQUFPLG9CQUFvQnRFLFNBQVNELEtBQUtDLFdBQVcsaUNBQWlDLENBQUM7QUFBQSxJQUNuSCxDQUFDLEVBQ0FDLFFBQVEsTUFBTWlDLGFBQWEsS0FBSyxDQUFDO0FBQUEsRUFDdEM7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxRQUFHLFdBQVUscUNBQW9DLHVCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLFVBQ3pELHVCQUFDLE9BQUUsV0FBVSwrQkFBOEIsMERBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxNQUFLLFdBQVUsV0FBVSx5Q0FBd0MsbUNBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFFQSx1QkFBQyxhQUFRLFdBQVUseUVBQ2pCLGlDQUFDLFVBQUssVUFBVSxDQUFDVyxNQUFNQSxFQUFFMEIsZUFBZSxHQUFHLFdBQVUsZ0ZBQ25EO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLGFBQVk7QUFBQSxZQUNaLFNBQVN0RCxVQUFVUixJQUFJLENBQUNvQyxPQUFPLEVBQUUyQixPQUFPdkgsT0FBTzRGLEVBQUVDLEVBQUUsR0FBRzJCLE9BQU81QixFQUFFRSxLQUFLLEVBQUU7QUFBQSxZQUN0RSxPQUFPNUI7QUFBQUEsWUFDUCxVQUFVLENBQUMwQixNQUFNekIsY0FBY3lCLEVBQUVxQixPQUFPTSxLQUFLO0FBQUE7QUFBQSxVQUwvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLaUQ7QUFBQSxRQUVqRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FBTy9HO0FBQUFBLFlBQ1AsVUFBVSxDQUFDb0YsTUFBTTtBQUNmeEIsc0JBQVF3QixFQUFFcUIsT0FBT00sS0FBSztBQUN0QjVDLDhCQUFnQixRQUFRO0FBQUEsWUFDMUI7QUFBQSxZQUNBLEtBQUtsRSxNQUFNd0M7QUFBQUEsWUFDWCxPQUFPdUMsY0FBYyxtQ0FBbUN2QztBQUFBQTtBQUFBQSxVQVIxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRb0U7QUFBQSxRQUVwRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FBT3hDO0FBQUFBLFlBQ1AsVUFBVSxDQUFDbUYsTUFBTTtBQUNmdkIsb0JBQU11QixFQUFFcUIsT0FBT00sS0FBSztBQUNwQjVDLDhCQUFnQixRQUFRO0FBQUEsWUFDMUI7QUFBQSxZQUNBLEtBQUtuRSxRQUFReUM7QUFBQUEsWUFDYixPQUFPdUMsY0FBYyxtQ0FBbUN2QztBQUFBQTtBQUFBQSxVQVIxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRb0U7QUFBQSxRQUVwRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sTUFBSztBQUFBLFlBQ0wsYUFBWTtBQUFBLFlBQ1osT0FBT3FCO0FBQUFBLFlBQ1AsVUFBVSxDQUFDc0IsTUFBTXJCLFVBQVVxQixFQUFFcUIsT0FBT00sS0FBSztBQUFBO0FBQUEsVUFMM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSzZDO0FBQUEsUUFFNUNiLG1CQUNDLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVEsV0FBVSxTQUFTQyxjQUFjLDRCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQXRDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0NBLEtBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQ0E7QUFBQSxNQUVBLHVCQUFDLGFBQVEsV0FBVSw4REFDaEI7QUFBQSxTQUFDdkUsV0FBVyxDQUFDRSxTQUFTLENBQUNrRCxlQUN0Qix1QkFBQyxTQUFJLFdBQVUsaUdBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsc0NBQ1ZPO0FBQUFBLHFCQUFTNUM7QUFBQUEsWUFBTztBQUFBLGVBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxpRUFDWnNFLGlCQUFPdkYsUUFBUXhDLFlBQVksRUFBRThEO0FBQUFBLGNBQUksQ0FBQyxDQUFDa0UsS0FBS0YsS0FBSyxNQUM1QztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNWixtQkFBbUJjLEdBQUc7QUFBQSxrQkFDckMsV0FBVyx1RkFDVGhELGlCQUFpQmdELE1BQ2Isc0NBQ0EscUNBQXFDO0FBQUEsa0JBRzFDRjtBQUFBQTtBQUFBQSxnQkFUSUU7QUFBQUEsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBO0FBQUEsWUFDRCxLQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVyxtRUFBbUUsRUFBRWxILFFBQVFDLE9BQU8sV0FBVyxJQUMxR0Qsa0JBQVFDLEtBQUssR0FBR1UsV0FBV1gsSUFBSSxDQUFDLE1BQU1XLFdBQVdWLEVBQUUsQ0FBQyxLQUFLLE9BRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVE7QUFBQSxnQkFDUixTQUFTdUU7QUFBQUEsZ0JBQ1QsVUFBVVEsZUFBZXBELFdBQVcyRCxTQUFTNUMsV0FBVztBQUFBLGdCQUN4RCxTQUFTZ0U7QUFBQUEsZ0JBQWE7QUFBQTtBQUFBLGNBTHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsZUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxhQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0NBO0FBQUEsUUFHRDNCLGNBQ0MsdUJBQUMsU0FBSSxXQUFVLHdGQUF1RixNQUFLLFNBQ3pHO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRCQUEyQixNQUFLLFFBQU8sU0FBUSxhQUFZLFFBQU8sZ0JBQWUsYUFBWSxPQUMxRyxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLEdBQUUsc0xBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVPLEtBRHpPO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxzQ0FBcUMsMkNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZFO0FBQUEsVUFDN0UsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQyxnSEFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLElBQ0VwRCxVQUNGLHVCQUFDLFNBQUksV0FBVSw0RUFBMkUsTUFBSyxVQUFTLGFBQVUsUUFDaEg7QUFBQSxpQ0FBQyxXQUFRLE1BQUssUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQjtBQUFBLFVBQ2xCLHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsK0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsYUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBQ0VFLFFBQ0YsdUJBQUMsU0FBSSxXQUFVLHdGQUF1RixNQUFLLFNBQ3pHO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBCQUF5QixNQUFLLFFBQU8sU0FBUSxhQUFZLFFBQU8sZ0JBQWUsYUFBWSxPQUN4RyxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLEdBQUUsME1BQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJQLEtBRDdQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxzQ0FBcUMsaUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFDbkUsdUJBQUMsT0FBRSxXQUFVLG1DQUFtQ0EsbUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNEO0FBQUEsVUFDdEQsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxXQUFVLFNBQVNFLGFBQWEseUJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQSxJQUNFdUQsU0FBUzVDLFdBQVcsSUFDdEIsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLGFBQVk7QUFBQSxZQUNaLFFBQ0V1RCxrQkFDRSx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFdBQVUsU0FBU0MsY0FBYyw0QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxJQUNFMUQ7QUFBQUE7QUFBQUEsVUFSUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTRyxLQVZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxTQUFNLFdBQVUsaUJBQ2Y7QUFBQSxpQ0FBQyxTQUNDLGlDQUFDLE1BQ0M7QUFBQSxtQ0FBQyxNQUFHLHdCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVk7QUFBQSxZQUNaLHVCQUFDLE1BQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBVztBQUFBLFlBQ1gsdUJBQUMsTUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFTO0FBQUEsWUFDVCx1QkFBQyxNQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWM7QUFBQSxZQUNkLHVCQUFDLE1BQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUztBQUFBLFlBQ1QsdUJBQUMsTUFBRyxzQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFVO0FBQUEsZUFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBQ0EsdUJBQUMsU0FDRThDLG1CQUFTdkM7QUFBQUEsWUFBSSxDQUFDeEIsUUFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDLFVBQVU7QUFBQSxnQkFDVixjQUFZLHFCQUFxQkEsSUFBSW9CLElBQUk7QUFBQSxnQkFDekMsU0FBUyxDQUFDd0MsTUFBTW1CLGVBQWVuQixHQUFHNUQsR0FBRztBQUFBLGdCQUNyQyxXQUFXLENBQUM0RCxNQUFNO0FBQ2hCLHNCQUFJQSxFQUFFOEIsUUFBUSxXQUFXOUIsRUFBRThCLFFBQVEsS0FBSztBQUN0QzlCLHNCQUFFMEIsZUFBZTtBQUNqQlIsK0JBQVc5RSxHQUFHO0FBQUEsa0JBQ2hCO0FBQUEsZ0JBQ0Y7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxNQUFHLFdBQVUsZ0RBQWdEQSxjQUFJcUIsWUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkU7QUFBQSxrQkFDM0UsdUJBQUMsTUFBRyxXQUFVLHFCQUFxQmxDLHFCQUFXYSxJQUFJcEMsSUFBSSxLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLGtCQUN4RCx1QkFBQyxNQUNDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLE1BQU1rSCxXQUFXOUUsR0FBRztBQUFBLHNCQUM3QixXQUFVO0FBQUEsc0JBRVYsaUNBQUMsVUFBSyxXQUFVLGdDQUErQixPQUFPQSxJQUFJb0IsTUFDdkRwQixjQUFJb0IsUUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUE7QUFBQSxvQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVVBO0FBQUEsa0JBQ0EsdUJBQUMsTUFBRyxXQUFVLHNEQUNYcEIsY0FBSXNCLG1CQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxNQUFJdEIsY0FBSXVCLFNBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZTtBQUFBLGtCQUNmLHVCQUFDLE1BQ0MsaUNBQUMsZUFBWSxRQUFRdkIsSUFBSVQsVUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0MsS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBO0FBQUE7QUFBQSxjQS9CS1MsSUFBSTZEO0FBQUFBLGNBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlDQTtBQUFBLFVBQ0QsS0FwQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQ0E7QUFBQSxhQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaURBLEtBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtREE7QUFBQSxXQW5JSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUlBO0FBQUEsU0E5TEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStMQTtBQUFBLElBRUEsdUJBQUMsZUFBWSxNQUFNSixRQUFRWCxXQUFXLEdBQUcsU0FBUyxNQUFNQyxlQUFlLElBQUksR0FBRyxLQUFLRCxlQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStGO0FBQUEsT0FsTWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtTUE7QUFFSjtBQUFDaEIsSUF2VHVCRCxhQUFXO0FBQUEsVUFnQlhwRixRQUFRO0FBQUE7QUFBQSxNQWhCUm9GO0FBQVcsSUFBQXJDLElBQUFJLEtBQUErRixLQUFBQztBQUFBLGFBQUFwRyxJQUFBO0FBQUEsYUFBQUksS0FBQTtBQUFBLGFBQUErRixLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbIkZyYWdtZW50IiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiQmFkZ2UiLCJCdXR0b24iLCJEYXRlUGlja2VyIiwiRW1wdHlTdGF0ZSIsIklucHV0IiwiTG9hZGluZyIsIk1vZGFsIiwiU2VsZWN0IiwiVGFibGUiLCJUQm9keSIsIlRkIiwiVGgiLCJUSGVhZCIsIlRyIiwidXNlVG9hc3QiLCJnZXRFbXBsb3llZXMiLCJnZXRIaXN0b3J5IiwiZ2V0VGFza0hpc3RvcnkiLCJleHBvcnRIaXN0b3J5IiwiU1RBVFVTX1ZBUklBTlQiLCJDb21wbGV0ZWQiLCJEb2N1bWVudGF0aW9uIiwiUGxhbiIsIlRlc3RpbmciLCJET1RfQk9SREVSIiwic3VjY2VzcyIsImluZm8iLCJ3YXJuaW5nIiwiZGFuZ2VyIiwibmV1dHJhbCIsIkRPVF9GSUxMIiwiVElNRV9QRVJJT0RTIiwidG9JU09EYXRlIiwiZGF0ZSIsInllYXIiLCJnZXRGdWxsWWVhciIsIm1vbnRoIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsImRheSIsImdldERhdGUiLCJkZWZhdWx0UmFuZ2UiLCJub3ciLCJEYXRlIiwiZnJvbSIsInRvIiwiZ2V0UGVyaW9kUmFuZ2UiLCJwZXJpb2QiLCJkYXlPZldlZWsiLCJnZXREYXkiLCJzdGFydE9mV2VlayIsInNldERhdGUiLCJEQVRFX0ZNVCIsIkludGwiLCJEYXRlVGltZUZvcm1hdCIsImZvcm1hdERhdGUiLCJpc28iLCJmb3JtYXQiLCJTdGF0dXNCYWRnZSIsInN0YXR1cyIsIl9jIiwiVGltZWxpbmVEb3QiLCJ2YXJpYW50IiwiaXNMYXRlc3QiLCJfYzIiLCJEZXRhaWxNb2RhbCIsIm9wZW4iLCJvbkNsb3NlIiwicm93IiwiX3MiLCJlbnRyaWVzIiwic2V0RW50cmllcyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsImxvYWRIaXN0b3J5IiwidGFza19pZCIsInRoZW4iLCJyZXMiLCJkYXRhIiwiY2F0Y2giLCJlcnIiLCJtZXNzYWdlIiwiZmluYWxseSIsInVuZGVmaW5lZCIsImxhc3RVcGRhdGVkIiwibGVuZ3RoIiwidGFzayIsImVtcGxveWVlIiwiY2xpY2t1cF90YXNrX2lkIiwicGhhc2UiLCJtYXAiLCJlbnRyeSIsImluZGV4IiwicHJldkVudHJ5IiwicGhhc2VDaGFuZ2VkIiwiSGlzdG9yeVBhZ2UiLCJfczIiLCJpbml0aWFsUmFuZ2UiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJlbXBsb3llZUlkIiwic2V0RW1wbG95ZWVJZCIsInNldEZyb20iLCJzZXRUbyIsInNlYXJjaCIsInNldFNlYXJjaCIsImRlYm91bmNlZFNlYXJjaCIsInNldERlYm91bmNlZFNlYXJjaCIsImFjdGl2ZVBlcmlvZCIsInNldEFjdGl2ZVBlcmlvZCIsInJvd3MiLCJzZXRSb3dzIiwic2VsZWN0ZWRSb3ciLCJzZXRTZWxlY3RlZFJvdyIsImV4cG9ydGluZyIsInNldEV4cG9ydGluZyIsInNob3dUb2FzdCIsImNhbmNlbGxlZCIsImVtcGxveWVlX2lkIiwidGltZXIiLCJzZXRUaW1lb3V0IiwiY2xlYXJUaW1lb3V0IiwiZGF0ZUludmFsaWQiLCJCb29sZWFuIiwiZW1wbG95ZWVOYW1lIiwiZmluZCIsImUiLCJpZCIsIm5hbWUiLCJmaWx0ZXJlZCIsInF1ZXJ5IiwidHJpbSIsInRvTG93ZXJDYXNlIiwiZmlsdGVyIiwiaGF5c3RhY2siLCJpbmNsdWRlcyIsInNvcnQiLCJhIiwiYiIsImxvY2FsZUNvbXBhcmUiLCJoYXNBY3RpdmVGaWx0ZXIiLCJyZXNldEZpbHRlcnMiLCJoYW5kbGVQZXJpb2RDaGFuZ2UiLCJyYW5nZSIsIm9wZW5EZXRhaWwiLCJoYW5kbGVSb3dDbGljayIsImV2ZW50IiwidGFyZ2V0IiwiY2xvc2VzdCIsImhhbmRsZUV4cG9ydCIsInR5cGUiLCJ0aXRsZSIsInByZXZlbnREZWZhdWx0IiwidmFsdWUiLCJsYWJlbCIsIk9iamVjdCIsImtleSIsIl9jMyIsIl9jNCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJIaXN0b3J5UGFnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRnJhZ21lbnQsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7XHJcbiAgQmFkZ2UsXHJcbiAgQnV0dG9uLFxyXG4gIERhdGVQaWNrZXIsXHJcbiAgRW1wdHlTdGF0ZSxcclxuICBJbnB1dCxcclxuICBMb2FkaW5nLFxyXG4gIE1vZGFsLFxyXG4gIFNlbGVjdCxcclxuICBUYWJsZSxcclxuICBUQm9keSxcclxuICBUZCxcclxuICBUaCxcclxuICBUSGVhZCxcclxuICBUcixcclxuICB1c2VUb2FzdCxcclxufSBmcm9tICcuLi9jb21wb25lbnRzL3VpJztcclxuaW1wb3J0IHsgZ2V0RW1wbG95ZWVzLCBnZXRIaXN0b3J5LCBnZXRUYXNrSGlzdG9yeSwgZXhwb3J0SGlzdG9yeSB9IGZyb20gJy4uL2FwaS9sc3BwdCc7XHJcblxyXG5jb25zdCBTVEFUVVNfVkFSSUFOVCA9IHtcclxuICBDb21wbGV0ZWQ6ICdzdWNjZXNzJyxcclxuICAnQ29tcGxldGVkIFRlc3RpbmcnOiAnc3VjY2VzcycsXHJcbiAgRG9jdW1lbnRhdGlvbjogJ2luZm8nLFxyXG4gICdJbiBQcm9ncmVzcyc6ICdpbmZvJyxcclxuICAnT24gSG9sZCc6ICdkYW5nZXInLFxyXG4gIFBsYW46ICduZXV0cmFsJyxcclxuICAnQ29tcGxldGVkIHdpdGggRmVlZGJhY2snOiAnd2FybmluZycsXHJcbiAgVGVzdGluZzogJ3dhcm5pbmcnLFxyXG4gICdPbiBRdWV1ZSBUZXN0aW5nJzogJ3dhcm5pbmcnLFxyXG59O1xyXG5cclxuY29uc3QgRE9UX0JPUkRFUiA9IHtcclxuICBzdWNjZXNzOiAnYm9yZGVyLWdyZWVuLTUwMCcsXHJcbiAgaW5mbzogJ2JvcmRlci1ibHVlLTUwMCcsXHJcbiAgd2FybmluZzogJ2JvcmRlci1hbWJlci01MDAnLFxyXG4gIGRhbmdlcjogJ2JvcmRlci1yZWQtNTAwJyxcclxuICBuZXV0cmFsOiAnYm9yZGVyLXNsYXRlLTQwMCcsXHJcbn07XHJcblxyXG5jb25zdCBET1RfRklMTCA9IHtcclxuICBzdWNjZXNzOiAnYmctZ3JlZW4tNTAwJyxcclxuICBpbmZvOiAnYmctYmx1ZS01MDAnLFxyXG4gIHdhcm5pbmc6ICdiZy1hbWJlci01MDAnLFxyXG4gIGRhbmdlcjogJ2JnLXJlZC01MDAnLFxyXG4gIG5ldXRyYWw6ICdiZy1zbGF0ZS00MDAnLFxyXG59O1xyXG5cclxuY29uc3QgVElNRV9QRVJJT0RTID0ge1xyXG4gICdtaW5nZ3UtaW5pJzogJ01pbmdndSBJbmknLFxyXG4gICdidWxhbi1pbmknOiAnQnVsYW4gSW5pJyxcclxuICAndGFodW4taW5pJzogJ1RhaHVuIEluaScsXHJcbiAgJ3NlbXVhJzogJ1NlbXVhJyxcclxufTtcclxuXHJcbmZ1bmN0aW9uIHRvSVNPRGF0ZShkYXRlKSB7XHJcbiAgY29uc3QgeWVhciA9IGRhdGUuZ2V0RnVsbFllYXIoKTtcclxuICBjb25zdCBtb250aCA9IFN0cmluZyhkYXRlLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gIGNvbnN0IGRheSA9IFN0cmluZyhkYXRlLmdldERhdGUoKSkucGFkU3RhcnQoMiwgJzAnKTtcclxuICByZXR1cm4gYCR7eWVhcn0tJHttb250aH0tJHtkYXl9YDtcclxufVxyXG5cclxuZnVuY3Rpb24gZGVmYXVsdFJhbmdlKCkge1xyXG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgcmV0dXJuIHtcclxuICAgIGZyb206IHRvSVNPRGF0ZShuZXcgRGF0ZShub3cuZ2V0RnVsbFllYXIoKSwgbm93LmdldE1vbnRoKCksIDEpKSxcclxuICAgIHRvOiB0b0lTT0RhdGUobm93KSxcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRQZXJpb2RSYW5nZShwZXJpb2QpIHtcclxuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gIHN3aXRjaCAocGVyaW9kKSB7XHJcbiAgICBjYXNlICdtaW5nZ3UtaW5pJzoge1xyXG4gICAgICBjb25zdCBkYXlPZldlZWsgPSBub3cuZ2V0RGF5KCk7XHJcbiAgICAgIGNvbnN0IHN0YXJ0T2ZXZWVrID0gbmV3IERhdGUobm93KTtcclxuICAgICAgc3RhcnRPZldlZWsuc2V0RGF0ZShub3cuZ2V0RGF0ZSgpIC0gZGF5T2ZXZWVrKTtcclxuICAgICAgcmV0dXJuIHsgZnJvbTogdG9JU09EYXRlKHN0YXJ0T2ZXZWVrKSwgdG86IHRvSVNPRGF0ZShub3cpIH07XHJcbiAgICB9XHJcbiAgICBjYXNlICdidWxhbi1pbmknOlxyXG4gICAgICByZXR1cm4geyBmcm9tOiB0b0lTT0RhdGUobmV3IERhdGUobm93LmdldEZ1bGxZZWFyKCksIG5vdy5nZXRNb250aCgpLCAxKSksIHRvOiB0b0lTT0RhdGUobm93KSB9O1xyXG4gICAgY2FzZSAndGFodW4taW5pJzpcclxuICAgICAgcmV0dXJuIHsgZnJvbTogdG9JU09EYXRlKG5ldyBEYXRlKG5vdy5nZXRGdWxsWWVhcigpLCAwLCAxKSksIHRvOiB0b0lTT0RhdGUobm93KSB9O1xyXG4gICAgY2FzZSAnc2VtdWEnOlxyXG4gICAgICByZXR1cm4geyBmcm9tOiAnJywgdG86ICcnIH07XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICByZXR1cm4gZGVmYXVsdFJhbmdlKCk7XHJcbiAgfVxyXG59XHJcblxyXG5jb25zdCBEQVRFX0ZNVCA9IG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KCdpZC1JRCcsIHtcclxuICBkYXk6ICdudW1lcmljJyxcclxuICBtb250aDogJ3Nob3J0JyxcclxuICB5ZWFyOiAnbnVtZXJpYycsXHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gZm9ybWF0RGF0ZShpc28pIHtcclxuICBpZiAoIWlzbykgcmV0dXJuICctJztcclxuICByZXR1cm4gREFURV9GTVQuZm9ybWF0KG5ldyBEYXRlKGlzbykpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBTdGF0dXNCYWRnZSh7IHN0YXR1cyB9KSB7XHJcbiAgcmV0dXJuIDxCYWRnZSB2YXJpYW50PXtTVEFUVVNfVkFSSUFOVFtzdGF0dXNdIHx8ICduZXV0cmFsJ30+e3N0YXR1c308L0JhZGdlPjtcclxufVxyXG5cclxuZnVuY3Rpb24gVGltZWxpbmVEb3QoeyB2YXJpYW50LCBpc0xhdGVzdCB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzcGFuXHJcbiAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgIGNsYXNzTmFtZT17YGFic29sdXRlIC1sZWZ0LVs5cHhdIHRvcC0xIGgtNCB3LTQgcm91bmRlZC1mdWxsIGJvcmRlci0yIGJnLXdoaXRlICR7XHJcbiAgICAgICAgRE9UX0JPUkRFUlt2YXJpYW50XVxyXG4gICAgICB9ICR7aXNMYXRlc3QgPyBET1RfRklMTFt2YXJpYW50XSA6ICcnfWB9XHJcbiAgICAvPlxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIERldGFpbE1vZGFsKHsgb3Blbiwgb25DbG9zZSwgcm93IH0pIHtcclxuICBjb25zdCBbZW50cmllcywgc2V0RW50cmllc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgZnVuY3Rpb24gbG9hZEhpc3RvcnkoKSB7XHJcbiAgICBpZiAoIXJvdykgcmV0dXJuO1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgZ2V0VGFza0hpc3Rvcnkocm93LnRhc2tfaWQpXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHNldEVudHJpZXMocmVzLmRhdGEpKVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gc2V0RXJyb3IoZXJyPy5tZXNzYWdlIHx8ICdUZXJqYWRpIGtlc2FsYWhhbiB0YWsgdGVyZHVnYS4nKSlcclxuICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpO1xyXG4gIH1cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghb3BlbiB8fCAhcm93KSByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgbG9hZEhpc3RvcnkoKTtcclxuICAgIHJldHVybiAoKSA9PiB7fTtcclxuICB9LCBbb3Blbiwgcm93XSk7XHJcblxyXG4gIGNvbnN0IGxhc3RVcGRhdGVkID0gZW50cmllcz8ubGVuZ3RoID8gZW50cmllc1tlbnRyaWVzLmxlbmd0aCAtIDFdLmRhdGUgOiBudWxsO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE1vZGFsIG9wZW49e29wZW59IG9uQ2xvc2U9e29uQ2xvc2V9IHRpdGxlPXtyb3cgPyByb3cudGFzayA6ICdEZXRhaWwgVGFzayd9IHNpemU9XCJsZ1wiPlxyXG4gICAgICB7cm93ICYmIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgPGRsIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLXgtNiBnYXAteS0zIHNtOmdyaWQtY29scy01XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5LYXJ5YXdhbjwvZHQ+XHJcbiAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTAuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwXCI+e3Jvdy5lbXBsb3llZX08L2RkPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPkNsaWNrVXAgSUQ8L2R0PlxyXG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0wLjUgZm9udC1tb25vIHRleHQteHMgdGV4dC1zbGF0ZS03MDBcIj57cm93LmNsaWNrdXBfdGFza19pZH08L2RkPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlBoYXNlIHNhYXQgaW5pPC9kdD5cclxuICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwXCI+e3Jvdy5waGFzZX08L2RkPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlN0YXR1cyBzYWF0IGluaTwvZHQ+XHJcbiAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTFcIj5cclxuICAgICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSBzdGF0dXM9e3Jvdy5zdGF0dXN9IC8+XHJcbiAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5MYXN0IFVwZGF0ZWQ8L2R0PlxyXG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0wLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge2xhc3RVcGRhdGVkID8gZm9ybWF0RGF0ZShsYXN0VXBkYXRlZCkgOiAnLSd9XHJcbiAgICAgICAgICAgICAgPC9kZD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2RsPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIHB0LTVcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgIFJpd2F5YXQgUHJvZ3Jlc3NcclxuICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAge2xvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHktMTBcIiByb2xlPVwic3RhdHVzXCIgYXJpYS1idXN5PVwidHJ1ZVwiPlxyXG4gICAgICAgICAgICAgICAgPExvYWRpbmcgc2l6ZT1cIm1kXCIgLz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS01MDBcIj5NZW11YXQgcml3YXlhdCBwcm9ncmVzc+KApjwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHshbG9hZGluZyAmJiBlcnJvciAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMyBweS04XCIgcm9sZT1cImFsZXJ0XCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcn08L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFJpd2F5YXQgcHJvZ3Jlc3MgdGlkYWsgZGFwYXQgZGltdWF0LlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e2xvYWRIaXN0b3J5fT5cclxuICAgICAgICAgICAgICAgICAgQ29iYSBMYWdpXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHshbG9hZGluZyAmJiAhZXJyb3IgJiYgZW50cmllcyAmJiBlbnRyaWVzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxvbCBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtbC0yIG10LTQgYm9yZGVyLWwtMiBib3JkZXItc2xhdGUtMTAwXCIgYXJpYS1sYWJlbD1cIlJpd2F5YXQgcHJvZ3Jlc3NcIj5cclxuICAgICAgICAgICAgICAgIHtlbnRyaWVzLm1hcCgoZW50cnksIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHZhcmlhbnQgPSBTVEFUVVNfVkFSSUFOVFtlbnRyeS5zdGF0dXNdIHx8ICduZXV0cmFsJztcclxuICAgICAgICAgICAgICAgICAgY29uc3QgaXNMYXRlc3QgPSBpbmRleCA9PT0gZW50cmllcy5sZW5ndGggLSAxO1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBwcmV2RW50cnkgPSBpbmRleCA+IDAgPyBlbnRyaWVzW2luZGV4IC0gMV0gOiBudWxsO1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBwaGFzZUNoYW5nZWQgPSBwcmV2RW50cnkgJiYgcHJldkVudHJ5LnBoYXNlICE9PSBlbnRyeS5waGFzZTtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICA8RnJhZ21lbnQga2V5PXtgJHtlbnRyeS5kYXRlfS0ke2VudHJ5LnN0YXR1c31gfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwaGFzZUNoYW5nZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwicmVsYXRpdmUgcGItMyBwbC03XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWxlZnQtWzlweF0gdG9wLTEgaC00IHctNCByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXNsYXRlLTUwIHB4LTIgcHktMC41IHRleHQtWzEwcHhdIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGhhc2U6IHtwcmV2RW50cnkucGhhc2V9IOKGkiB7ZW50cnkucGhhc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9e2ByZWxhdGl2ZSAke3BoYXNlQ2hhbmdlZCA/ICdwdC0xJyA6ICcnfSBwYi02IHBsLTcgbGFzdDpwYi0xYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUaW1lbGluZURvdCB2YXJpYW50PXt2YXJpYW50fSBpc0xhdGVzdD17aXNMYXRlc3R9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXNtICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTGF0ZXN0ID8gJ2ZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDAnIDogJ3RleHQtc2xhdGUtNjAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUoZW50cnkuZGF0ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+e2VudHJ5LnBoYXNlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSBzdGF0dXM9e2VudHJ5LnN0YXR1c30gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNMYXRlc3QgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPktvbmRpc2kgdGVyYWtoaXIgdHVnYXMgaW5pLjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9GcmFnbWVudD5cclxuICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIDwvb2w+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7IWxvYWRpbmcgJiYgIWVycm9yICYmIGVudHJpZXMgJiYgZW50cmllcy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInB5LTYgdGV4dC1zbSB0ZXh0LXNsYXRlLTUwMFwiPlRhc2sgaW5pIGJlbHVtIG1lbWlsaWtpIHJpd2F5YXQgcHJvZ3Jlc3MgeWFuZyB0ZXJjYXRhdC48L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgZmxleCBqdXN0aWZ5LWVuZCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIHB0LTRcIj5cclxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgICAgIFR1dHVwXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcbiAgICA8L01vZGFsPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhpc3RvcnlQYWdlKCkge1xyXG4gIGNvbnN0IGluaXRpYWxSYW5nZSA9IHVzZU1lbW8oZGVmYXVsdFJhbmdlLCBbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZW1wbG95ZWVJZCwgc2V0RW1wbG95ZWVJZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2Zyb20sIHNldEZyb21dID0gdXNlU3RhdGUoaW5pdGlhbFJhbmdlLmZyb20pO1xyXG4gIGNvbnN0IFt0bywgc2V0VG9dID0gdXNlU3RhdGUoaW5pdGlhbFJhbmdlLnRvKTtcclxuICBjb25zdCBbc2VhcmNoLCBzZXRTZWFyY2hdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtkZWJvdW5jZWRTZWFyY2gsIHNldERlYm91bmNlZFNlYXJjaF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2FjdGl2ZVBlcmlvZCwgc2V0QWN0aXZlUGVyaW9kXSA9IHVzZVN0YXRlKCdidWxhbi1pbmknKTtcclxuXHJcbiAgY29uc3QgW3Jvd3MsIHNldFJvd3NdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IFtzZWxlY3RlZFJvdywgc2V0U2VsZWN0ZWRSb3ddID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2V4cG9ydGluZywgc2V0RXhwb3J0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCB7IHNob3dUb2FzdCB9ID0gdXNlVG9hc3QoKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZTtcclxuICAgIGdldEVtcGxveWVlcygpXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHtcclxuICAgICAgICBpZiAoIWNhbmNlbGxlZCkgc2V0RW1wbG95ZWVzKHJlcy5kYXRhKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKCgpID0+IHt9KTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNhbmNlbGxlZCA9IHRydWU7XHJcbiAgICB9O1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgZnVuY3Rpb24gbG9hZEhpc3RvcnkoKSB7XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICBnZXRIaXN0b3J5KHsgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQgfHwgdW5kZWZpbmVkLCBmcm9tOiBmcm9tIHx8IHVuZGVmaW5lZCwgdG86IHRvIHx8IHVuZGVmaW5lZCB9KVxyXG4gICAgICAudGhlbigocmVzKSA9PiBzZXRSb3dzKHJlcy5kYXRhKSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IHNldEVycm9yKGVycj8ubWVzc2FnZSB8fCAnVGVyamFkaSBrZXNhbGFoYW4gdGFrIHRlcmR1Z2EuJykpXHJcbiAgICAgIC5maW5hbGx5KCgpID0+IHNldExvYWRpbmcoZmFsc2UpKTtcclxuICB9XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsb2FkSGlzdG9yeSgpO1xyXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xyXG4gIH0sIFtlbXBsb3llZUlkLCBmcm9tLCB0b10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHNldERlYm91bmNlZFNlYXJjaChzZWFyY2gpLCAzMDApO1xyXG4gICAgcmV0dXJuICgpID0+IGNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgfSwgW3NlYXJjaF0pO1xyXG5cclxuICBjb25zdCBkYXRlSW52YWxpZCA9IEJvb2xlYW4oZnJvbSAmJiB0byAmJiBmcm9tID4gdG8pO1xyXG5cclxuICBjb25zdCBlbXBsb3llZU5hbWUgPSBlbXBsb3llZXMuZmluZCgoZSkgPT4gU3RyaW5nKGUuaWQpID09PSBlbXBsb3llZUlkKT8ubmFtZTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IHF1ZXJ5ID0gZGVib3VuY2VkU2VhcmNoLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgcmV0dXJuIHJvd3NcclxuICAgICAgLmZpbHRlcigocm93KSA9PiB7XHJcbiAgICAgICAgaWYgKGVtcGxveWVlTmFtZSAmJiByb3cuZW1wbG95ZWUgIT09IGVtcGxveWVlTmFtZSkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIGlmIChmcm9tICYmIHJvdy5kYXRlIDwgZnJvbSkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIGlmICh0byAmJiByb3cuZGF0ZSA+IHRvKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgaWYgKHF1ZXJ5KSB7XHJcbiAgICAgICAgICBjb25zdCBoYXlzdGFjayA9IGAke3Jvdy50YXNrfSAke3Jvdy5jbGlja3VwX3Rhc2tfaWR9ICR7cm93LmVtcGxveWVlfSAke3Jvdy5waGFzZX0gJHtyb3cuc3RhdHVzfWAudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgIGlmICghaGF5c3RhY2suaW5jbHVkZXMocXVlcnkpKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICB9KVxyXG4gICAgICAuc29ydCgoYSwgYikgPT4gYi5kYXRlLmxvY2FsZUNvbXBhcmUoYS5kYXRlKSk7XHJcbiAgfSwgW3Jvd3MsIGVtcGxveWVlTmFtZSwgZnJvbSwgdG8sIGRlYm91bmNlZFNlYXJjaF0pO1xyXG5cclxuICBjb25zdCBoYXNBY3RpdmVGaWx0ZXIgPVxyXG4gICAgQm9vbGVhbihlbXBsb3llZUlkKSB8fFxyXG4gICAgQm9vbGVhbihzZWFyY2gudHJpbSgpKSB8fFxyXG4gICAgYWN0aXZlUGVyaW9kICE9PSAnYnVsYW4taW5pJyB8fFxyXG4gICAgZnJvbSAhPT0gaW5pdGlhbFJhbmdlLmZyb20gfHxcclxuICAgIHRvICE9PSBpbml0aWFsUmFuZ2UudG87XHJcblxyXG4gIGZ1bmN0aW9uIHJlc2V0RmlsdGVycygpIHtcclxuICAgIHNldEVtcGxveWVlSWQoJycpO1xyXG4gICAgc2V0U2VhcmNoKCcnKTtcclxuICAgIHNldERlYm91bmNlZFNlYXJjaCgnJyk7XHJcbiAgICBzZXRBY3RpdmVQZXJpb2QoJ2J1bGFuLWluaScpO1xyXG4gICAgc2V0RnJvbShpbml0aWFsUmFuZ2UuZnJvbSk7XHJcbiAgICBzZXRUbyhpbml0aWFsUmFuZ2UudG8pO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlUGVyaW9kQ2hhbmdlKHBlcmlvZCkge1xyXG4gICAgc2V0QWN0aXZlUGVyaW9kKHBlcmlvZCk7XHJcbiAgICBjb25zdCByYW5nZSA9IGdldFBlcmlvZFJhbmdlKHBlcmlvZCk7XHJcbiAgICBzZXRGcm9tKHJhbmdlLmZyb20pO1xyXG4gICAgc2V0VG8ocmFuZ2UudG8pO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gb3BlbkRldGFpbChyb3cpIHtcclxuICAgIHNldFNlbGVjdGVkUm93KHJvdyk7XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBoYW5kbGVSb3dDbGljayhldmVudCwgcm93KSB7XHJcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmNsb3Nlc3QoJ2J1dHRvbicpKSByZXR1cm47XHJcbiAgICBvcGVuRGV0YWlsKHJvdyk7XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBoYW5kbGVFeHBvcnQoKSB7XHJcbiAgICBzZXRFeHBvcnRpbmcodHJ1ZSk7XHJcbiAgICBleHBvcnRIaXN0b3J5KHsgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQgfHwgdW5kZWZpbmVkLCBmcm9tOiBmcm9tIHx8IHVuZGVmaW5lZCwgdG86IHRvIHx8IHVuZGVmaW5lZCB9KVxyXG4gICAgICAudGhlbigoKSA9PiB7XHJcbiAgICAgICAgc2hvd1RvYXN0KHsgdHlwZTogJ3N1Y2Nlc3MnLCB0aXRsZTogJ0Vrc3BvciBzZWxlc2FpJywgbWVzc2FnZTogJ0ZpbGUgYmVyaGFzaWwgZGl1bmR1aC4nIH0pO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICAgIHNob3dUb2FzdCh7IHR5cGU6ICdlcnJvcicsIHRpdGxlOiAnR2FnYWwgbWVuZ2Vrc3BvcicsIG1lc3NhZ2U6IGVycj8ubWVzc2FnZSB8fCAnVGVyamFkaSBrZXNhbGFoYW4gdGFrIHRlcmR1Z2EuJyB9KTtcclxuICAgICAgfSlcclxuICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0RXhwb3J0aW5nKGZhbHNlKSk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtNTBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTV4bCBweC00IHB5LTYgc206cHgtOCBzbTpweS04XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1lbmQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+SGlzdG9yeTwvaDE+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICAgIFJla2FwIHByb2dyZXMgTFNQUFQgaGFyaWFuIHNlbXVhIGthcnlhd2FuLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxhIGhyZWY9XCIvc3VibWl0XCIgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWJsdWUtNjAwIGhvdmVyOnVuZGVybGluZVwiPlxyXG4gICAgICAgICAgICAmbGFycjsgS2VtYmFsaSBrZSBTdWJtaXRcclxuICAgICAgICAgIDwvYT5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibXQtNiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHAtNCBzaGFkb3ctc20gc206cC02XCI+XHJcbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17KGUpID0+IGUucHJldmVudERlZmF1bHQoKX0gY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNCBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtWzFmcl8xZnJfMWZyXzEuNGZyX2F1dG9dIGxnOml0ZW1zLWVuZFwiPlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJLYXJ5YXdhblwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZW11YSBrYXJ5YXdhblwiXHJcbiAgICAgICAgICAgICAgb3B0aW9ucz17ZW1wbG95ZWVzLm1hcCgoZSkgPT4gKHsgdmFsdWU6IFN0cmluZyhlLmlkKSwgbGFiZWw6IGUubmFtZSB9KSl9XHJcbiAgICAgICAgICAgICAgdmFsdWU9e2VtcGxveWVlSWR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbXBsb3llZUlkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgICAgICBsYWJlbD1cIkRhcmkgVGFuZ2dhbFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zyb219XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRGcm9tKGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgICAgIHNldEFjdGl2ZVBlcmlvZCgnY3VzdG9tJyk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBtYXg9e3RvIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICBlcnJvcj17ZGF0ZUludmFsaWQgPyAnTGViaWggYmVzYXIgZGFyaSB0YW5nZ2FsIGFraGlyJyA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgICAgICBsYWJlbD1cIlNhbXBhaSBUYW5nZ2FsXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17dG99XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRUbyhlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICBzZXRBY3RpdmVQZXJpb2QoJ2N1c3RvbScpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgbWluPXtmcm9tIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICBlcnJvcj17ZGF0ZUludmFsaWQgPyAnTGViaWgga2VjaWwgZGFyaSB0YW5nZ2FsIG11bGFpJyA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJDYXJpXCJcclxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDYXJpIHR1Z2FzIGF0YXUgQ2xpY2tVcCBJROKAplwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIHtoYXNBY3RpdmVGaWx0ZXIgJiYgKFxyXG4gICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17cmVzZXRGaWx0ZXJzfT5cclxuICAgICAgICAgICAgICAgIFJlc2V0IEZpbHRlclxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibXQtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgeyFsb2FkaW5nICYmICFlcnJvciAmJiAhZGF0ZUludmFsaWQgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBweC00IHB5LTMgc206cHgtNlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgIHtmaWx0ZXJlZC5sZW5ndGh9IGVudHJpIGRpdGVtdWthblxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSByb3VuZGVkLWxnIGJnLXNsYXRlLTEwMCBwLTFcIj5cclxuICAgICAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKFRJTUVfUEVSSU9EUykubWFwKChba2V5LCBsYWJlbF0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2tleX1cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUGVyaW9kQ2hhbmdlKGtleSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Byb3VuZGVkLW1kIHB4LTMgcHktMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtY2VudGVyIG1pbi13LVs3MnB4XSB0cmFuc2l0aW9uLWNvbG9ycyAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVQZXJpb2QgPT09IGtleVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIHRleHQtc2xhdGUtODAwIHNoYWRvdy1zbSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTcwMCdcclxuICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtsYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17YGhpZGRlbiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGxnOmJsb2NrIG1pbi13LVsxNDBweF0gdGV4dC1yaWdodCAkeyEoZnJvbSB8fCB0bykgJiYgJ2ludmlzaWJsZSd9YH0+XHJcbiAgICAgICAgICAgICAgICAgIHtmcm9tIHx8IHRvID8gYCR7Zm9ybWF0RGF0ZShmcm9tKX0g4oCTICR7Zm9ybWF0RGF0ZSh0byl9YCA6ICdcXHUwMEEwJ31cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtleHBvcnRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkYXRlSW52YWxpZCB8fCBsb2FkaW5nIHx8IGZpbHRlcmVkLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBFeHBvcnQgRXhjZWxcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAge2RhdGVJbnZhbGlkID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtWzI4MHB4XSBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHgtNiBweS0xMiB0ZXh0LWNlbnRlclwiIHJvbGU9XCJhbGVydFwiPlxyXG4gICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC0xMCB3LTEwIHRleHQtYW1iZXItNDAwXCIgZmlsbD1cIm5vbmVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIxLjVcIj5cclxuICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBkPVwiTTEyIDl2My43NW0tOS4zMDMgMy4zNzZjLS44NjYgMS41LjIxNyAzLjM3NCAxLjk0OCAzLjM3NGgxNC43MWMxLjczIDAgMi44MTMtMS44NzQgMS45NDgtMy4zNzRMMTMuOTQ5IDMuMzc4Yy0uODY2LTEuNS0zLjAzMi0xLjUtMy44OTggMEwyLjY5NyAxNi4xMjZ6TTEyIDE1Ljc1aC4wMDd2LjAwOEgxMnYtLjAwOHpcIiAvPlxyXG4gICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5SZW50YW5nIHRhbmdnYWwgdGlkYWsgdmFsaWQ8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWF4LXcteHMgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgVGFuZ2dhbCBha2hpciBsZWJpaCBhd2FsIGRhcmkgdGFuZ2dhbCBtdWxhaS4gU2VzdWFpa2FuIHNhbGFoIHNhdHUgdGFuZ2dhbCB1bnR1ayBtZWxpaGF0IGhpc3RvcnkuXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiBsb2FkaW5nID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtWzI4MHB4XSBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMgcHgtNiBweS0xMlwiIHJvbGU9XCJzdGF0dXNcIiBhcmlhLWJ1c3k9XCJ0cnVlXCI+XHJcbiAgICAgICAgICAgICAgPExvYWRpbmcgc2l6ZT1cImxnXCIgLz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwXCI+TWVtdWF0IHJpd2F5YXTigKY8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSA6IGVycm9yID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtWzI4MHB4XSBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMgcHgtNiBweS0xMiB0ZXh0LWNlbnRlclwiIHJvbGU9XCJhbGVydFwiPlxyXG4gICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC0xMCB3LTEwIHRleHQtcmVkLTQwMFwiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMS41XCI+XHJcbiAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgZD1cIk0xMiA5djMuNzVtMCAzLjc1aC4wMDh2LjAwOEgxMm0tOS4zMDMtMy4zODJjLS44NjYgMS41LjIxNyAzLjM3NCAxLjk0OCAzLjM3NGgxNC43MWMxLjczIDAgMi44MTMtMS44NzQgMS45NDgtMy4zNzRMMTMuOTQ5IDMuMzc4Yy0uODY2LTEuNS0zLjAzMi0xLjUtMy44OTggMEwyLjY5NyAxNi4xMjZ6TTEyIDE1Ljc1aC4wMDd2LjAwOEgxMnYtLjAwOHpcIiAvPlxyXG4gICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5HYWdhbCBtZW11YXQgZGF0YTwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYXgtdy14cyB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+e2Vycm9yfTwvcD5cclxuICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17bG9hZEhpc3Rvcnl9PlxyXG4gICAgICAgICAgICAgICAgQ29iYSBMYWdpXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSA6IGZpbHRlcmVkLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgc206cC02XCI+XHJcbiAgICAgICAgICAgICAgPEVtcHR5U3RhdGVcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiQmVsdW0gYWRhIGRhdGEgeWFuZyBjb2Nva1wiXHJcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbj1cIlRpZGFrIGFkYSBlbnRyaSBoaXN0b3J5IHNlc3VhaSBmaWx0ZXIgc2FhdCBpbmkuIENvYmEgdWJhaCBrYXJ5YXdhbiwgcmVudGFuZyB0YW5nZ2FsLCBhdGF1IGthdGEga3VuY2kgcGVuY2FyaWFuLlwiXHJcbiAgICAgICAgICAgICAgICBhY3Rpb249e1xyXG4gICAgICAgICAgICAgICAgICBoYXNBY3RpdmVGaWx0ZXIgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e3Jlc2V0RmlsdGVyc30+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZXNldCBGaWx0ZXJcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgKSA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgICA8VGFibGUgY2xhc3NOYW1lPVwibWluLXctWzc2MHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgPFRIZWFkPlxyXG4gICAgICAgICAgICAgICAgICA8VHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRoPkthcnlhd2FuPC9UaD5cclxuICAgICAgICAgICAgICAgICAgICA8VGg+VGFuZ2dhbDwvVGg+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRoPlR1Z2FzPC9UaD5cclxuICAgICAgICAgICAgICAgICAgICA8VGg+Q2xpY2tVcCBJRDwvVGg+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRoPlBoYXNlPC9UaD5cclxuICAgICAgICAgICAgICAgICAgICA8VGg+U3RhdHVzPC9UaD5cclxuICAgICAgICAgICAgICAgICAgPC9Ucj5cclxuICAgICAgICAgICAgICAgIDwvVEhlYWQ+XHJcbiAgICAgICAgICAgICAgICA8VEJvZHk+XHJcbiAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZC5tYXAoKHJvdykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxUclxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtyb3cuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICB0YWJJbmRleD17MH1cclxuICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BCdWthIGRldGFpbCB0dWdhcyAke3Jvdy50YXNrfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlUm93Q2xpY2soZSwgcm93KX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGUua2V5ID09PSAnRW50ZXInIHx8IGUua2V5ID09PSAnICcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3BlbkRldGFpbChyb3cpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGhvdmVyOmJnLXNsYXRlLTUwIGZvY3VzLXZpc2libGU6YmctYmx1ZS01MC82MCBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOi1vdXRsaW5lLW9mZnNldC0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRkIGNsYXNzTmFtZT1cIndoaXRlc3BhY2Utbm93cmFwIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwXCI+e3Jvdy5lbXBsb3llZX08L1RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRkIGNsYXNzTmFtZT1cIndoaXRlc3BhY2Utbm93cmFwXCI+e2Zvcm1hdERhdGUocm93LmRhdGUpfTwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuRGV0YWlsKHJvdyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IGZvbnQtbWVkaXVtIHRleHQtYmx1ZS02MDAgZ3JvdXAtaG92ZXI6dW5kZXJsaW5lIGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1vZmZzZXQtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgbWF4LXctWzI2MHB4XSB0cnVuY2F0ZVwiIHRpdGxlPXtyb3cudGFza30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cm93LnRhc2t9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGQgY2xhc3NOYW1lPVwid2hpdGVzcGFjZS1ub3dyYXAgZm9udC1tb25vIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Jvdy5jbGlja3VwX3Rhc2tfaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRkPntyb3cucGhhc2V9PC9UZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFN0YXR1c0JhZGdlIHN0YXR1cz17cm93LnN0YXR1c30gLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Ucj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1RCb2R5PlxyXG4gICAgICAgICAgICAgIDwvVGFibGU+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPERldGFpbE1vZGFsIG9wZW49e0Jvb2xlYW4oc2VsZWN0ZWRSb3cpfSBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZFJvdyhudWxsKX0gcm93PXtzZWxlY3RlZFJvd30gLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiIvYXBwL3NyYy9wYWdlcy9IaXN0b3J5UGFnZS5qc3gifQ==