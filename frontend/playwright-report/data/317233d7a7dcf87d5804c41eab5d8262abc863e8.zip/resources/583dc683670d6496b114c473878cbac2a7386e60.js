import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Badge.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6eb1056b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/Badge.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const VARIANTS = {
  success: "bg-green-100 text-green-700",
  warning: "bg-amber-100 text-amber-700",
  danger: "bg-red-100 text-red-700",
  info: "bg-blue-100 text-blue-700",
  neutral: "bg-slate-100 text-slate-600"
};
export default function Badge({ variant = "neutral", className = "", children, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "span",
    {
      className: `inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${VARIANTS[variant]} ${className}`,
      ...props,
      children
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/ui/Badge.jsx",
      lineNumber: 30,
      columnNumber: 5
    },
    this
  );
}
_c = Badge;
var _c;
$RefreshReg$(_c, "Badge");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/Badge.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/Badge.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFWSixNQUFNQSxXQUFXO0FBQUEsRUFDZkMsU0FBUztBQUFBLEVBQ1RDLFNBQVM7QUFBQSxFQUNUQyxRQUFRO0FBQUEsRUFDUkMsTUFBTTtBQUFBLEVBQ05DLFNBQVM7QUFDWDtBQUVBLHdCQUF3QkMsTUFBTSxFQUFFQyxVQUFVLFdBQVdDLFlBQVksSUFBSUMsVUFBVSxHQUFHQyxNQUFNLEdBQUc7QUFDekYsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVywyRUFBMkVWLFNBQVNPLE9BQU8sQ0FBQyxJQUFJQyxTQUFTO0FBQUEsTUFDcEgsR0FBSUU7QUFBQUEsTUFFSEQ7QUFBQUE7QUFBQUEsSUFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQTtBQUVKO0FBQUNFLEtBVHVCTDtBQUFLLElBQUFLO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlZBUklBTlRTIiwic3VjY2VzcyIsIndhcm5pbmciLCJkYW5nZXIiLCJpbmZvIiwibmV1dHJhbCIsIkJhZGdlIiwidmFyaWFudCIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwicHJvcHMiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCYWRnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgVkFSSUFOVFMgPSB7XG4gIHN1Y2Nlc3M6ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi03MDAnLFxuICB3YXJuaW5nOiAnYmctYW1iZXItMTAwIHRleHQtYW1iZXItNzAwJyxcbiAgZGFuZ2VyOiAnYmctcmVkLTEwMCB0ZXh0LXJlZC03MDAnLFxuICBpbmZvOiAnYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMCcsXG4gIG5ldXRyYWw6ICdiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAnLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQmFkZ2UoeyB2YXJpYW50ID0gJ25ldXRyYWwnLCBjbGFzc05hbWUgPSAnJywgY2hpbGRyZW4sIC4uLnByb3BzIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8c3BhblxuICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHJvdW5kZWQtZnVsbCBweC0yLjUgcHktMC41IHRleHQteHMgZm9udC1tZWRpdW0gJHtWQVJJQU5UU1t2YXJpYW50XX0gJHtjbGFzc05hbWV9YH1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9zcGFuPlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL3VpL0JhZGdlLmpzeCJ9