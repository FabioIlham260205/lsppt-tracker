import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/EmptyState.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6eb1056b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/EmptyState.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export default function EmptyState({
  title = "No data available",
  description,
  action,
  className = ""
}) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `flex flex-col items-center justify-center rounded-lg border border-dashed border-slate-300 bg-white px-6 py-12 text-center ${className}`,
      children: [
        /* @__PURE__ */ jsxDEV(
          "svg",
          {
            className: "mb-3 h-10 w-10 text-slate-300",
            fill: "none",
            viewBox: "0 0 24 24",
            stroke: "currentColor",
            strokeWidth: "1.5",
            children: /* @__PURE__ */ jsxDEV(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-4l-1 2h-6l-1-2H4"
              },
              void 0,
              false,
              {
                fileName: "/app/src/components/ui/EmptyState.jsx",
                lineNumber: 37,
                columnNumber: 9
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/ui/EmptyState.jsx",
            lineNumber: 30,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-slate-700", children: title }, void 0, false, {
          fileName: "/app/src/components/ui/EmptyState.jsx",
          lineNumber: 43,
          columnNumber: 7
        }, this),
        description && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 max-w-xs text-xs text-slate-400", children: description }, void 0, false, {
          fileName: "/app/src/components/ui/EmptyState.jsx",
          lineNumber: 44,
          columnNumber: 23
        }, this),
        action && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: action }, void 0, false, {
          fileName: "/app/src/components/ui/EmptyState.jsx",
          lineNumber: 45,
          columnNumber: 18
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/app/src/components/ui/EmptyState.jsx",
      lineNumber: 27,
      columnNumber: 5
    },
    this
  );
}
_c = EmptyState;
var _c;
$RefreshReg$(_c, "EmptyState");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/EmptyState.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/EmptyState.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJROzs7Ozs7Ozs7Ozs7Ozs7O0FBakJSLHdCQUF3QkEsV0FBVztBQUFBLEVBQ2pDQyxRQUFRO0FBQUEsRUFDUkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsWUFBWTtBQUNkLEdBQUc7QUFDRCxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXLDhIQUE4SEEsU0FBUztBQUFBLE1BRWxKO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLFNBQVE7QUFBQSxZQUNSLFFBQU87QUFBQSxZQUNQLGFBQVk7QUFBQSxZQUVaO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsZUFBYztBQUFBLGdCQUNkLGdCQUFlO0FBQUEsZ0JBQ2YsR0FBRTtBQUFBO0FBQUEsY0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHeUc7QUFBQTtBQUFBLFVBVjNHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVlBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsc0NBQXNDSCxtQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RDtBQUFBLFFBQ3hEQyxlQUFlLHVCQUFDLE9BQUUsV0FBVSx3Q0FBd0NBLHlCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsUUFDaEZDLFVBQVUsdUJBQUMsU0FBSSxXQUFVLFFBQVFBLG9CQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCO0FBQUE7QUFBQTtBQUFBLElBbEIzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFtQkE7QUFFSjtBQUFDRSxLQTVCdUJMO0FBQVUsSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRW1wdHlTdGF0ZSIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJhY3Rpb24iLCJjbGFzc05hbWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJFbXB0eVN0YXRlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBFbXB0eVN0YXRlKHtcbiAgdGl0bGUgPSAnTm8gZGF0YSBhdmFpbGFibGUnLFxuICBkZXNjcmlwdGlvbixcbiAgYWN0aW9uLFxuICBjbGFzc05hbWUgPSAnJyxcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBjbGFzc05hbWU9e2BmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS0zMDAgYmctd2hpdGUgcHgtNiBweS0xMiB0ZXh0LWNlbnRlciAke2NsYXNzTmFtZX1gfVxuICAgID5cbiAgICAgIDxzdmdcbiAgICAgICAgY2xhc3NOYW1lPVwibWItMyBoLTEwIHctMTAgdGV4dC1zbGF0ZS0zMDBcIlxuICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXG4gICAgICA+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICBkPVwiTTIwIDEzVjZhMiAyIDAgMDAtMi0ySDZhMiAyIDAgMDAtMiAydjdtMTYgMHY1YTIgMiAwIDAxLTIgMkg2YTIgMiAwIDAxLTItMnYtNW0xNiAwaC00bC0xIDJoLTZsLTEtMkg0XCJcbiAgICAgICAgLz5cbiAgICAgIDwvc3ZnPlxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPnt0aXRsZX08L3A+XG4gICAgICB7ZGVzY3JpcHRpb24gJiYgPHAgY2xhc3NOYW1lPVwibXQtMSBtYXgtdy14cyB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+e2Rlc2NyaXB0aW9ufTwvcD59XG4gICAgICB7YWN0aW9uICYmIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPnthY3Rpb259PC9kaXY+fVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL3VpL0VtcHR5U3RhdGUuanN4In0=