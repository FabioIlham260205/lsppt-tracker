import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SubmitPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6eb1056b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/pages/SubmitPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6eb1056b"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=6eb1056b";
import {
  Badge,
  Button,
  DatePicker,
  EmptyState,
  Input,
  Loading,
  Modal,
  Select,
  Table,
  TBody,
  Td,
  Th,
  THead,
  Tr,
  useToast
} from "/src/components/ui/index.js";
import {
  getEmployees,
  getPhases,
  saveLsppt,
  createEmployee,
  updateEmployee,
  deleteEmployee
} from "/src/api/lsppt.js?t=1787813471073";
const CLICKUP_ID_PATTERN = /\/([a-z0-9]+)\/?$/i;
const EMPTY_TASK_FORM = {
  title: "",
  clickupUrl: "",
  clickupTaskId: "",
  phase: "",
  status: ""
};
let taskSeq = 0;
function extractClickUpId(url) {
  const match = url.match(CLICKUP_ID_PATTERN);
  return match ? match[1] : null;
}
function statusBadgeVariant(status) {
  const s = status.toLowerCase();
  if (s.startsWith("completed")) return "success";
  if (s.includes("progress") || s.includes("testing") || s.includes("documentation")) return "info";
  if (s.includes("hold") || s.includes("feedback")) return "warning";
  return "neutral";
}
export default function SubmitPage() {
  _s();
  const { showToast } = useToast();
  const [employees, setEmployees] = useState([]);
  const [phases, setPhases] = useState({});
  const [metaLoading, setMetaLoading] = useState(true);
  const [employeeId, setEmployeeId] = useState("");
  const [date, setDate] = useState("");
  const [formErrors, setFormErrors] = useState({});
  const [taskForm, setTaskForm] = useState(EMPTY_TASK_FORM);
  const [rowErrors, setRowErrors] = useState({});
  const [tasks, setTasks] = useState([]);
  const [saving, setSaving] = useState(false);
  const [empModalOpen, setEmpModalOpen] = useState(false);
  const [empView, setEmpView] = useState("list");
  const [empEditId, setEmpEditId] = useState(null);
  const [empName, setEmpName] = useState("");
  const [empSaving, setEmpSaving] = useState(false);
  useEffect(() => {
    let cancelled = false;
    Promise.all([getEmployees(), getPhases()]).then(([empRes, phaseRes]) => {
      if (cancelled) return;
      setEmployees(empRes.data);
      setPhases(phaseRes.data);
    }).catch((err) => {
      if (cancelled) return;
      showToast({
        type: "error",
        title: "Gagal memuat data",
        message: err.response?.data?.message || err.message
      });
    }).finally(() => {
      if (!cancelled) setMetaLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [showToast]);
  const loadEmployees = () => {
    getEmployees().then((res) => setEmployees(res.data)).catch(() => {
    });
  };
  const openEmpModal = () => {
    setEmpView("list");
    setEmpEditId(null);
    setEmpName("");
    setEmpModalOpen(true);
  };
  const handleEmpCreate = async () => {
    if (!empName.trim()) return;
    setEmpSaving(true);
    try {
      await createEmployee(empName.trim());
      showToast({ type: "success", title: "Berhasil", message: "Karyawan ditambahkan" });
      loadEmployees();
      setEmpView("list");
      setEmpName("");
    } catch (err) {
      showToast({ type: "error", title: "Gagal", message: err.message });
    } finally {
      setEmpSaving(false);
    }
  };
  const handleEmpUpdate = async () => {
    if (!empName.trim() || !empEditId) return;
    setEmpSaving(true);
    try {
      await updateEmployee(empEditId, empName.trim());
      showToast({ type: "success", title: "Berhasil", message: "Karyawan diperbarui" });
      loadEmployees();
      setEmpView("list");
      setEmpEditId(null);
      setEmpName("");
    } catch (err) {
      showToast({ type: "error", title: "Gagal", message: err.message });
    } finally {
      setEmpSaving(false);
    }
  };
  const handleEmpDelete = async () => {
    if (!empEditId) return;
    setEmpSaving(true);
    try {
      await deleteEmployee(empEditId);
      showToast({ type: "success", title: "Berhasil", message: "Karyawan dihapus" });
      loadEmployees();
      setEmpView("list");
      setEmpEditId(null);
      setEmpName("");
    } catch (err) {
      showToast({ type: "error", title: "Gagal menghapus", message: err.message });
    } finally {
      setEmpSaving(false);
    }
  };
  const phaseOptions = Object.keys(phases);
  const statusOptions = taskForm.phase ? phases[taskForm.phase] ?? [] : [];
  const handleTaskFormChange = (field) => (e) => {
    const { value } = e.target;
    if (field === "phase") {
      setTaskForm((prev) => ({ ...prev, phase: value, status: "" }));
      setRowErrors((prev) => ({ ...prev, phase: void 0, status: void 0 }));
      return;
    }
    if (field === "clickupUrl") {
      const extracted = extractClickUpId(value);
      setTaskForm((prev) => ({
        ...prev,
        clickupUrl: value,
        ...extracted ? { clickupTaskId: extracted } : {}
      }));
      setRowErrors(
        (prev) => extracted ? { ...prev, clickupUrl: void 0, clickupTaskId: void 0 } : { ...prev, clickupUrl: void 0 }
      );
      return;
    }
    setTaskForm((prev) => ({ ...prev, [field]: value }));
    setRowErrors((prev) => ({ ...prev, [field]: void 0 }));
  };
  const validateTaskForm = () => {
    const errs = {};
    if (!employeeId) errs.employeeId = "Pilih karyawan";
    if (!date) errs.date = "Pilih tanggal";
    if (!taskForm.title.trim()) errs.title = "Judul tugas wajib diisi";
    if (!taskForm.clickupUrl.trim()) errs.clickupUrl = "ClickUp URL wajib diisi";
    else if (!extractClickUpId(taskForm.clickupUrl.trim()))
      errs.clickupUrl = "Format URL tidak valid (contoh: https://app.clickup.com/t/9003006723/86d41c8ur)";
    if (!taskForm.clickupTaskId.trim()) errs.clickupTaskId = "ClickUp Task ID wajib diisi";
    else if (tasks.some(
      (t) => t.clickup_task_id.toLowerCase() === taskForm.clickupTaskId.trim().toLowerCase()
    ))
      errs.clickupTaskId = "Task ID sudah ada di daftar";
    if (!taskForm.phase) errs.phase = "Pilih phase";
    if (!taskForm.status) errs.status = "Pilih status";
    return errs;
  };
  const handleAddTask = () => {
    const errs = validateTaskForm();
    setRowErrors(errs);
    setFormErrors({ employeeId: errs.employeeId, date: errs.date });
    if (Object.keys(errs).length > 0) return;
    setTasks(
      (prev) => [
        ...prev,
        {
          uid: ++taskSeq,
          title: taskForm.title.trim(),
          clickup_url: taskForm.clickupUrl.trim(),
          clickup_task_id: taskForm.clickupTaskId.trim(),
          phase: taskForm.phase,
          status: taskForm.status
        }
      ]
    );
    setTaskForm(EMPTY_TASK_FORM);
  };
  const handleRemoveTask = (uid) => {
    setTasks((prev) => prev.filter((t) => t.uid !== uid));
  };
  const handleSave = async () => {
    const errs = {};
    if (!employeeId) errs.employeeId = "Pilih karyawan";
    if (!date) errs.date = "Pilih tanggal";
    if (tasks.length === 0) errs.tasks = "Tambahkan minimal satu task sebelum menyimpan";
    setFormErrors(errs);
    if (Object.keys(errs).length > 0) {
      showToast({
        type: "error",
        title: "Form belum lengkap",
        message: "Lengkapi karyawan, tanggal, dan tambahkan minimal satu task."
      });
      return;
    }
    const payload = {
      employee_id: Number(employeeId),
      date,
      tasks: tasks.map(({ title, clickup_url, clickup_task_id, phase, status }) => ({
        title,
        clickup_url,
        clickup_task_id,
        phase,
        status
      }))
    };
    setSaving(true);
    try {
      const res = await saveLsppt(payload);
      showToast({
        type: "success",
        title: "Berhasil",
        message: res.message || "LSPPT saved successfully"
      });
      setTasks([]);
      setTaskForm(EMPTY_TASK_FORM);
    } catch (err) {
      const message = err.response?.data?.message || err.message;
      showToast({
        type: "error",
        title: err.status === 409 ? "Task duplikat" : "Gagal menyimpan LSPPT",
        message
      });
    } finally {
      setSaving(false);
    }
  };
  if (metaLoading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen items-center justify-center bg-slate-50", children: /* @__PURE__ */ jsxDEV(Loading, { size: "lg" }, void 0, false, {
      fileName: "/app/src/pages/SubmitPage.jsx",
      lineNumber: 314,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/SubmitPage.jsx",
      lineNumber: 313,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-slate-50 p-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto max-w-7xl space-y-6", children: [
      /* @__PURE__ */ jsxDEV("header", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-slate-800", children: "LSPPT Tracker" }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 324,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-slate-500", children: "Laporan Status Progress Pekerjaan Karyawan" }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 325,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 323,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/history",
            className: "text-sm font-medium text-blue-600 hover:text-blue-700 hover:underline",
            children: "Lihat History →"
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 329,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/pages/SubmitPage.jsx",
        lineNumber: 322,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "rounded-lg border border-slate-200 bg-white p-5 shadow-sm", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "mb-4 text-sm font-semibold uppercase tracking-wide text-slate-600", children: "Informasi Umum" }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 338,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-2", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                label: "Employee",
                placeholder: "Pilih karyawan",
                options: employees.map((emp) => ({ value: emp.id, label: emp.name })),
                value: employeeId,
                onChange: (e) => setEmployeeId(e.target.value),
                error: formErrors.employeeId
              },
              void 0,
              false,
              {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 343,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: openEmpModal,
                className: "mt-1 text-xs text-slate-500 hover:text-blue-600 hover:underline",
                children: "⚙ Kelola Karyawan"
              },
              void 0,
              false,
              {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 351,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 342,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            DatePicker,
            {
              label: "Tanggal",
              value: date,
              onChange: (e) => {
                setDate(e.target.value);
                setFormErrors((prev) => ({ ...prev, date: void 0 }));
              },
              error: formErrors.date
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 359,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 341,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/SubmitPage.jsx",
        lineNumber: 337,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "rounded-lg border border-slate-200 bg-white p-5 shadow-sm", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "mb-4 text-sm font-semibold uppercase tracking-wide text-slate-600", children: "Tambah Task" }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 369,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: "Task Title",
              placeholder: "Contoh: CTMS - Issue List Report",
              value: taskForm.title,
              onChange: handleTaskFormChange("title"),
              error: rowErrors.title
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 374,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 373,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: "ClickUp URL",
              type: "url",
              placeholder: "https://app.clickup.com/t/9003006723/86d41c8ur",
              value: taskForm.clickupUrl,
              onChange: handleTaskFormChange("clickupUrl"),
              error: rowErrors.clickupUrl
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 382,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: "ClickUp Task ID",
              placeholder: "Otomatis terisi dari URL",
              value: taskForm.clickupTaskId,
              onChange: handleTaskFormChange("clickupTaskId"),
              error: rowErrors.clickupTaskId
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 390,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              label: "Phase",
              placeholder: "Pilih phase",
              options: phaseOptions.map((p) => ({ value: p, label: p })),
              value: taskForm.phase,
              onChange: handleTaskFormChange("phase"),
              error: rowErrors.phase
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 397,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              label: "Status",
              placeholder: taskForm.phase ? "Pilih status" : "Pilih phase terlebih dahulu",
              options: statusOptions.map((s) => ({ value: s, label: s })),
              value: taskForm.status,
              onChange: handleTaskFormChange("status"),
              disabled: !taskForm.phase,
              error: rowErrors.status
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 405,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 372,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex justify-end", children: /* @__PURE__ */ jsxDEV(Button, { type: "button", onClick: handleAddTask, children: "+ Add Task" }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 416,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 415,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/SubmitPage.jsx",
        lineNumber: 368,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "rounded-lg border border-slate-200 bg-white shadow-sm", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-5 pt-5 pb-3", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold uppercase tracking-wide text-slate-600", children: [
            "Daftar Task (",
            tasks.length,
            ")"
          ] }, void 0, true, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 424,
            columnNumber: 13
          }, this),
          formErrors.tasks && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-red-600", children: formErrors.tasks }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 427,
            columnNumber: 34
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 423,
          columnNumber: 11
        }, this),
        tasks.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "px-5 pb-5", children: /* @__PURE__ */ jsxDEV(
          EmptyState,
          {
            title: "Belum ada task",
            description: "Isi form di atas lalu klik “+ Add Task” untuk menambahkan task ke daftar.",
            className: "border-0 py-8"
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 432,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 431,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Table, { children: [
          /* @__PURE__ */ jsxDEV(THead, { children: /* @__PURE__ */ jsxDEV(Tr, { children: [
            /* @__PURE__ */ jsxDEV(Th, { className: "w-12", children: "No" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 442,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Task" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 443,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "ClickUp ID" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 444,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Phase" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 445,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Status" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 446,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { className: "w-24 text-right", children: "Aksi" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 447,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 441,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 440,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TBody, { children: tasks.map(
            (task, index) => /* @__PURE__ */ jsxDEV(Tr, { children: [
              /* @__PURE__ */ jsxDEV(Td, { children: index + 1 }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 453,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "font-medium text-slate-800", children: task.title }, void 0, false, {
                  fileName: "/app/src/pages/SubmitPage.jsx",
                  lineNumber: 455,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "a",
                  {
                    href: task.clickup_url,
                    target: "_blank",
                    rel: "noreferrer",
                    className: "text-xs text-blue-600 hover:underline",
                    children: task.clickup_url
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/pages/SubmitPage.jsx",
                    lineNumber: 456,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 454,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV("code", { className: "rounded bg-slate-100 px-1.5 py-0.5 text-xs", children: task.clickup_task_id }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 466,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 465,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: task.phase }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 470,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV(Badge, { variant: statusBadgeVariant(task.status), children: task.status }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 472,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 471,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { className: "text-right", children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "button",
                  variant: "outline",
                  size: "sm",
                  onClick: () => handleRemoveTask(task.uid),
                  children: "Hapus"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/pages/SubmitPage.jsx",
                  lineNumber: 475,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 474,
                columnNumber: 21
              }, this)
            ] }, task.uid, true, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 452,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 450,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 439,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-t border-slate-100 px-5 py-4", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: tasks.length > 0 ? `${tasks.length} task siap disimpan untuk ${date || "tanggal terpilih"}` : "Belum ada task yang ditambahkan." }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 491,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { type: "button", size: "lg", loading: saving, onClick: handleSave, children: "Save LSPPT" }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 496,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 490,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/SubmitPage.jsx",
        lineNumber: 422,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/SubmitPage.jsx",
      lineNumber: 321,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: empModalOpen,
        onClose: () => setEmpModalOpen(false),
        title: empView === "list" ? "Kelola Karyawan" : empView === "add" ? "Tambah Karyawan" : "Edit Karyawan",
        size: "sm",
        footer: empView === "list" ? /* @__PURE__ */ jsxDEV(Button, { type: "button", onClick: () => {
          setEmpView("add");
          setEmpName("");
        }, children: "+ Tambah Karyawan" }, void 0, false, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 516,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          empView === "edit" && /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              variant: "danger",
              loading: empSaving,
              onClick: handleEmpDelete,
              children: "Hapus Karyawan"
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 522,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              variant: "outline",
              onClick: () => setEmpView("list"),
              children: "Batal"
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 531,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              loading: empSaving,
              onClick: empView === "add" ? handleEmpCreate : handleEmpUpdate,
              children: "Simpan"
            },
            void 0,
            false,
            {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 538,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 520,
          columnNumber: 9
        }, this),
        children: empView === "list" ? /* @__PURE__ */ jsxDEV(Table, { children: [
          /* @__PURE__ */ jsxDEV(THead, { children: /* @__PURE__ */ jsxDEV(Tr, { children: [
            /* @__PURE__ */ jsxDEV(Th, { className: "w-10", children: "#" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 553,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { children: "Nama" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 554,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Th, { className: "w-20" }, void 0, false, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 555,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 552,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 551,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(TBody, { children: employees.map(
            (emp, i) => /* @__PURE__ */ jsxDEV(Tr, { children: [
              /* @__PURE__ */ jsxDEV(Td, { children: i + 1 }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 561,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: emp.name }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 562,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "button",
                  variant: "outline",
                  size: "sm",
                  onClick: () => {
                    setEmpView("edit");
                    setEmpEditId(emp.id);
                    setEmpName(emp.name);
                  },
                  children: "Edit"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/pages/SubmitPage.jsx",
                  lineNumber: 564,
                  columnNumber: 21
                },
                this
              ) }, void 0, false, {
                fileName: "/app/src/pages/SubmitPage.jsx",
                lineNumber: 563,
                columnNumber: 19
              }, this)
            ] }, emp.id, true, {
              fileName: "/app/src/pages/SubmitPage.jsx",
              lineNumber: 560,
              columnNumber: 13
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 558,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/pages/SubmitPage.jsx",
          lineNumber: 550,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(
          Input,
          {
            label: "Nama Karyawan",
            placeholder: "Masukkan nama",
            value: empName,
            onChange: (e) => setEmpName(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/SubmitPage.jsx",
            lineNumber: 582,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "/app/src/pages/SubmitPage.jsx",
        lineNumber: 503,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/pages/SubmitPage.jsx",
    lineNumber: 320,
    columnNumber: 5
  }, this);
}
_s(SubmitPage, "vsGM88arvTDcXRksbdWY/fIom1Y=", false, function() {
  return [useToast];
});
_c = SubmitPage;
var _c;
$RefreshReg$(_c, "SubmitPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/pages/SubmitPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/pages/SubmitPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc1NRLFNBOE1JLFVBOU1KOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRTUixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsWUFBWTtBQUNyQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxNQUFNQyxxQkFBcUI7QUFFM0IsTUFBTUMsa0JBQWtCO0FBQUEsRUFDdEJDLE9BQU87QUFBQSxFQUNQQyxZQUFZO0FBQUEsRUFDWkMsZUFBZTtBQUFBLEVBQ2ZDLE9BQU87QUFBQSxFQUNQQyxRQUFRO0FBQ1Y7QUFFQSxJQUFJQyxVQUFVO0FBRWQsU0FBU0MsaUJBQWlCQyxLQUFLO0FBQzdCLFFBQU1DLFFBQVFELElBQUlDLE1BQU1WLGtCQUFrQjtBQUMxQyxTQUFPVSxRQUFRQSxNQUFNLENBQUMsSUFBSTtBQUM1QjtBQUVBLFNBQVNDLG1CQUFtQkwsUUFBUTtBQUNsQyxRQUFNTSxJQUFJTixPQUFPTyxZQUFZO0FBQzdCLE1BQUlELEVBQUVFLFdBQVcsV0FBVyxFQUFHLFFBQU87QUFDdEMsTUFBSUYsRUFBRUcsU0FBUyxVQUFVLEtBQUtILEVBQUVHLFNBQVMsU0FBUyxLQUFLSCxFQUFFRyxTQUFTLGVBQWUsRUFBRyxRQUFPO0FBQzNGLE1BQUlILEVBQUVHLFNBQVMsTUFBTSxLQUFLSCxFQUFFRyxTQUFTLFVBQVUsRUFBRyxRQUFPO0FBQ3pELFNBQU87QUFDVDtBQUVBLHdCQUF3QkMsYUFBYTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sRUFBRUMsVUFBVSxJQUFJekIsU0FBUztBQUUvQixRQUFNLENBQUMwQixXQUFXQyxZQUFZLElBQUkzQyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDNEMsUUFBUUMsU0FBUyxJQUFJN0MsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDOEMsYUFBYUMsY0FBYyxJQUFJL0MsU0FBUyxJQUFJO0FBRW5ELFFBQU0sQ0FBQ2dELFlBQVlDLGFBQWEsSUFBSWpELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNrRCxNQUFNQyxPQUFPLElBQUluRCxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDb0QsWUFBWUMsYUFBYSxJQUFJckQsU0FBUyxDQUFDLENBQUM7QUFFL0MsUUFBTSxDQUFDc0QsVUFBVUMsV0FBVyxJQUFJdkQsU0FBU3dCLGVBQWU7QUFDeEQsUUFBTSxDQUFDZ0MsV0FBV0MsWUFBWSxJQUFJekQsU0FBUyxDQUFDLENBQUM7QUFDN0MsUUFBTSxDQUFDMEQsT0FBT0MsUUFBUSxJQUFJM0QsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzRELFFBQVFDLFNBQVMsSUFBSTdELFNBQVMsS0FBSztBQUUxQyxRQUFNLENBQUM4RCxjQUFjQyxlQUFlLElBQUkvRCxTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDZ0UsU0FBU0MsVUFBVSxJQUFJakUsU0FBUyxNQUFNO0FBQzdDLFFBQU0sQ0FBQ2tFLFdBQVdDLFlBQVksSUFBSW5FLFNBQVMsSUFBSTtBQUMvQyxRQUFNLENBQUNvRSxTQUFTQyxVQUFVLElBQUlyRSxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDc0UsV0FBV0MsWUFBWSxJQUFJdkUsU0FBUyxLQUFLO0FBRWhERCxZQUFVLE1BQU07QUFDZCxRQUFJeUUsWUFBWTtBQUNoQkMsWUFBUUMsSUFBSSxDQUFDekQsYUFBYSxHQUFHQyxVQUFVLENBQUMsQ0FBQyxFQUN0Q3lELEtBQUssQ0FBQyxDQUFDQyxRQUFRQyxRQUFRLE1BQU07QUFDNUIsVUFBSUwsVUFBVztBQUNmN0IsbUJBQWFpQyxPQUFPRSxJQUFJO0FBQ3hCakMsZ0JBQVVnQyxTQUFTQyxJQUFJO0FBQUEsSUFDekIsQ0FBQyxFQUNBQyxNQUFNLENBQUNDLFFBQVE7QUFDZCxVQUFJUixVQUFXO0FBQ2YvQixnQkFBVTtBQUFBLFFBQ1J3QyxNQUFNO0FBQUEsUUFDTnhELE9BQU87QUFBQSxRQUNQeUQsU0FBU0YsSUFBSUcsVUFBVUwsTUFBTUksV0FBV0YsSUFBSUU7QUFBQUEsTUFDOUMsQ0FBQztBQUFBLElBQ0gsQ0FBQyxFQUNBRSxRQUFRLE1BQU07QUFDYixVQUFJLENBQUNaLFVBQVd6QixnQkFBZSxLQUFLO0FBQUEsSUFDdEMsQ0FBQztBQUNILFdBQU8sTUFBTTtBQUNYeUIsa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRixHQUFHLENBQUMvQixTQUFTLENBQUM7QUFFZCxRQUFNNEMsZ0JBQWdCQSxNQUFNO0FBQzFCcEUsaUJBQWEsRUFDVjBELEtBQUssQ0FBQ1csUUFBUTNDLGFBQWEyQyxJQUFJUixJQUFJLENBQUMsRUFDcENDLE1BQU0sTUFBTTtBQUFBLElBQUMsQ0FBQztBQUFBLEVBQ25CO0FBRUEsUUFBTVEsZUFBZUEsTUFBTTtBQUN6QnRCLGVBQVcsTUFBTTtBQUNqQkUsaUJBQWEsSUFBSTtBQUNqQkUsZUFBVyxFQUFFO0FBQ2JOLG9CQUFnQixJQUFJO0FBQUEsRUFDdEI7QUFFQSxRQUFNeUIsa0JBQWtCLFlBQVk7QUFDbEMsUUFBSSxDQUFDcEIsUUFBUXFCLEtBQUssRUFBRztBQUNyQmxCLGlCQUFhLElBQUk7QUFDakIsUUFBSTtBQUNGLFlBQU1uRCxlQUFlZ0QsUUFBUXFCLEtBQUssQ0FBQztBQUNuQ2hELGdCQUFVLEVBQUV3QyxNQUFNLFdBQVd4RCxPQUFPLFlBQVl5RCxTQUFTLHVCQUF1QixDQUFDO0FBQ2pGRyxvQkFBYztBQUNkcEIsaUJBQVcsTUFBTTtBQUNqQkksaUJBQVcsRUFBRTtBQUFBLElBQ2YsU0FBU1csS0FBSztBQUNadkMsZ0JBQVUsRUFBRXdDLE1BQU0sU0FBU3hELE9BQU8sU0FBU3lELFNBQVNGLElBQUlFLFFBQVEsQ0FBQztBQUFBLElBQ25FLFVBQUM7QUFDQ1gsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU1tQixrQkFBa0IsWUFBWTtBQUNsQyxRQUFJLENBQUN0QixRQUFRcUIsS0FBSyxLQUFLLENBQUN2QixVQUFXO0FBQ25DSyxpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDRixZQUFNbEQsZUFBZTZDLFdBQVdFLFFBQVFxQixLQUFLLENBQUM7QUFDOUNoRCxnQkFBVSxFQUFFd0MsTUFBTSxXQUFXeEQsT0FBTyxZQUFZeUQsU0FBUyxzQkFBc0IsQ0FBQztBQUNoRkcsb0JBQWM7QUFDZHBCLGlCQUFXLE1BQU07QUFDakJFLG1CQUFhLElBQUk7QUFDakJFLGlCQUFXLEVBQUU7QUFBQSxJQUNmLFNBQVNXLEtBQUs7QUFDWnZDLGdCQUFVLEVBQUV3QyxNQUFNLFNBQVN4RCxPQUFPLFNBQVN5RCxTQUFTRixJQUFJRSxRQUFRLENBQUM7QUFBQSxJQUNuRSxVQUFDO0FBQ0NYLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0Isa0JBQWtCLFlBQVk7QUFDbEMsUUFBSSxDQUFDekIsVUFBVztBQUNoQkssaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTWpELGVBQWU0QyxTQUFTO0FBQzlCekIsZ0JBQVUsRUFBRXdDLE1BQU0sV0FBV3hELE9BQU8sWUFBWXlELFNBQVMsbUJBQW1CLENBQUM7QUFDN0VHLG9CQUFjO0FBQ2RwQixpQkFBVyxNQUFNO0FBQ2pCRSxtQkFBYSxJQUFJO0FBQ2pCRSxpQkFBVyxFQUFFO0FBQUEsSUFDZixTQUFTVyxLQUFLO0FBQ1p2QyxnQkFBVSxFQUFFd0MsTUFBTSxTQUFTeEQsT0FBTyxtQkFBbUJ5RCxTQUFTRixJQUFJRSxRQUFRLENBQUM7QUFBQSxJQUM3RSxVQUFDO0FBQ0NYLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNcUIsZUFBZUMsT0FBT0MsS0FBS2xELE1BQU07QUFDdkMsUUFBTW1ELGdCQUFnQnpDLFNBQVMxQixRQUFRZ0IsT0FBT1UsU0FBUzFCLEtBQUssS0FBSyxLQUFLO0FBRXRFLFFBQU1vRSx1QkFBdUJBLENBQUNDLFVBQVUsQ0FBQ0MsTUFBTTtBQUM3QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFFcEIsUUFBSUgsVUFBVSxTQUFTO0FBQ3JCMUMsa0JBQVksQ0FBQzhDLFVBQVUsRUFBRSxHQUFHQSxNQUFNekUsT0FBT3VFLE9BQU90RSxRQUFRLEdBQUcsRUFBRTtBQUM3RDRCLG1CQUFhLENBQUM0QyxVQUFVLEVBQUUsR0FBR0EsTUFBTXpFLE9BQU8wRSxRQUFXekUsUUFBUXlFLE9BQVUsRUFBRTtBQUN6RTtBQUFBLElBQ0Y7QUFFQSxRQUFJTCxVQUFVLGNBQWM7QUFDMUIsWUFBTU0sWUFBWXhFLGlCQUFpQm9FLEtBQUs7QUFDeEM1QyxrQkFBWSxDQUFDOEMsVUFBVTtBQUFBLFFBQ3JCLEdBQUdBO0FBQUFBLFFBQ0gzRSxZQUFZeUU7QUFBQUEsUUFDWixHQUFJSSxZQUFZLEVBQUU1RSxlQUFlNEUsVUFBVSxJQUFJLENBQUM7QUFBQSxNQUNsRCxFQUFFO0FBQ0Y5QztBQUFBQSxRQUFhLENBQUM0QyxTQUNaRSxZQUNJLEVBQUUsR0FBR0YsTUFBTTNFLFlBQVk0RSxRQUFXM0UsZUFBZTJFLE9BQVUsSUFDM0QsRUFBRSxHQUFHRCxNQUFNM0UsWUFBWTRFLE9BQVU7QUFBQSxNQUN2QztBQUNBO0FBQUEsSUFDRjtBQUVBL0MsZ0JBQVksQ0FBQzhDLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNKLEtBQUssR0FBR0UsTUFBTSxFQUFFO0FBQ25EMUMsaUJBQWEsQ0FBQzRDLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNKLEtBQUssR0FBR0ssT0FBVSxFQUFFO0FBQUEsRUFDMUQ7QUFFQSxRQUFNRSxtQkFBbUJBLE1BQU07QUFDN0IsVUFBTUMsT0FBTyxDQUFDO0FBQ2QsUUFBSSxDQUFDekQsV0FBWXlELE1BQUt6RCxhQUFhO0FBQ25DLFFBQUksQ0FBQ0UsS0FBTXVELE1BQUt2RCxPQUFPO0FBQ3ZCLFFBQUksQ0FBQ0ksU0FBUzdCLE1BQU1nRSxLQUFLLEVBQUdnQixNQUFLaEYsUUFBUTtBQUV6QyxRQUFJLENBQUM2QixTQUFTNUIsV0FBVytELEtBQUssRUFBR2dCLE1BQUsvRSxhQUFhO0FBQUEsYUFDMUMsQ0FBQ0ssaUJBQWlCdUIsU0FBUzVCLFdBQVcrRCxLQUFLLENBQUM7QUFDbkRnQixXQUFLL0UsYUFBYTtBQUVwQixRQUFJLENBQUM0QixTQUFTM0IsY0FBYzhELEtBQUssRUFBR2dCLE1BQUs5RSxnQkFBZ0I7QUFBQSxhQUV2RCtCLE1BQU1nRDtBQUFBQSxNQUNKLENBQUNDLE1BQU1BLEVBQUVDLGdCQUFnQnhFLFlBQVksTUFBTWtCLFNBQVMzQixjQUFjOEQsS0FBSyxFQUFFckQsWUFBWTtBQUFBLElBQ3ZGO0FBRUFxRSxXQUFLOUUsZ0JBQWdCO0FBRXZCLFFBQUksQ0FBQzJCLFNBQVMxQixNQUFPNkUsTUFBSzdFLFFBQVE7QUFDbEMsUUFBSSxDQUFDMEIsU0FBU3pCLE9BQVE0RSxNQUFLNUUsU0FBUztBQUVwQyxXQUFPNEU7QUFBQUEsRUFDVDtBQUVBLFFBQU1JLGdCQUFnQkEsTUFBTTtBQUMxQixVQUFNSixPQUFPRCxpQkFBaUI7QUFDOUIvQyxpQkFBYWdELElBQUk7QUFDakJwRCxrQkFBYyxFQUFFTCxZQUFZeUQsS0FBS3pELFlBQVlFLE1BQU11RCxLQUFLdkQsS0FBSyxDQUFDO0FBQzlELFFBQUkyQyxPQUFPQyxLQUFLVyxJQUFJLEVBQUVLLFNBQVMsRUFBRztBQUVsQ25EO0FBQUFBLE1BQVMsQ0FBQzBDLFNBQVM7QUFBQSxRQUNqQixHQUFHQTtBQUFBQSxRQUNIO0FBQUEsVUFDRVUsS0FBSyxFQUFFakY7QUFBQUEsVUFDUEwsT0FBTzZCLFNBQVM3QixNQUFNZ0UsS0FBSztBQUFBLFVBQzNCdUIsYUFBYTFELFNBQVM1QixXQUFXK0QsS0FBSztBQUFBLFVBQ3RDbUIsaUJBQWlCdEQsU0FBUzNCLGNBQWM4RCxLQUFLO0FBQUEsVUFDN0M3RCxPQUFPMEIsU0FBUzFCO0FBQUFBLFVBQ2hCQyxRQUFReUIsU0FBU3pCO0FBQUFBLFFBQ25CO0FBQUEsTUFBQztBQUFBLElBQ0Y7QUFDRDBCLGdCQUFZL0IsZUFBZTtBQUFBLEVBQzdCO0FBRUEsUUFBTXlGLG1CQUFtQkEsQ0FBQ0YsUUFBUTtBQUNoQ3BELGFBQVMsQ0FBQzBDLFNBQVNBLEtBQUthLE9BQU8sQ0FBQ1AsTUFBTUEsRUFBRUksUUFBUUEsR0FBRyxDQUFDO0FBQUEsRUFDdEQ7QUFFQSxRQUFNSSxhQUFhLFlBQVk7QUFDN0IsVUFBTVYsT0FBTyxDQUFDO0FBQ2QsUUFBSSxDQUFDekQsV0FBWXlELE1BQUt6RCxhQUFhO0FBQ25DLFFBQUksQ0FBQ0UsS0FBTXVELE1BQUt2RCxPQUFPO0FBQ3ZCLFFBQUlRLE1BQU1vRCxXQUFXLEVBQUdMLE1BQUsvQyxRQUFRO0FBQ3JDTCxrQkFBY29ELElBQUk7QUFFbEIsUUFBSVosT0FBT0MsS0FBS1csSUFBSSxFQUFFSyxTQUFTLEdBQUc7QUFDaENyRSxnQkFBVTtBQUFBLFFBQ1J3QyxNQUFNO0FBQUEsUUFDTnhELE9BQU87QUFBQSxRQUNQeUQsU0FBUztBQUFBLE1BQ1gsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUVBLFVBQU1rQyxVQUFVO0FBQUEsTUFDZEMsYUFBYUMsT0FBT3RFLFVBQVU7QUFBQSxNQUM5QkU7QUFBQUEsTUFDQVEsT0FBT0EsTUFBTTZELElBQUksQ0FBQyxFQUFFOUYsT0FBT3VGLGFBQWFKLGlCQUFpQmhGLE9BQU9DLE9BQU8sT0FBTztBQUFBLFFBQzVFSjtBQUFBQSxRQUNBdUY7QUFBQUEsUUFDQUo7QUFBQUEsUUFDQWhGO0FBQUFBLFFBQ0FDO0FBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0o7QUFFQWdDLGNBQVUsSUFBSTtBQUNkLFFBQUk7QUFDRixZQUFNeUIsTUFBTSxNQUFNbkUsVUFBVWlHLE9BQU87QUFDbkMzRSxnQkFBVTtBQUFBLFFBQ1J3QyxNQUFNO0FBQUEsUUFDTnhELE9BQU87QUFBQSxRQUNQeUQsU0FBU0ksSUFBSUosV0FBVztBQUFBLE1BQzFCLENBQUM7QUFDRHZCLGVBQVMsRUFBRTtBQUNYSixrQkFBWS9CLGVBQWU7QUFBQSxJQUM3QixTQUFTd0QsS0FBSztBQUNaLFlBQU1FLFVBQVVGLElBQUlHLFVBQVVMLE1BQU1JLFdBQVdGLElBQUlFO0FBQ25EekMsZ0JBQVU7QUFBQSxRQUNSd0MsTUFBTTtBQUFBLFFBQ054RCxPQUFPdUQsSUFBSW5ELFdBQVcsTUFBTSxrQkFBa0I7QUFBQSxRQUM5Q3FEO0FBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDckIsZ0JBQVUsS0FBSztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLE1BQUlmLGFBQWE7QUFDZixXQUNFLHVCQUFDLFNBQUksV0FBVSw2REFDYixpQ0FBQyxXQUFRLE1BQUssUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFlBQU8sV0FBVSxxQ0FDaEI7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHFDQUFvQyw2QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Q7QUFBQSxVQUMvRCx1QkFBQyxPQUFFLFdBQVUsK0JBQThCLDBEQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFHO0FBQUEsWUFDSCxXQUFVO0FBQUEsWUFBdUU7QUFBQTtBQUFBLFVBRm5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUVBLHVCQUFDLGFBQVEsV0FBVSw2REFDakI7QUFBQSwrQkFBQyxRQUFHLFdBQVUscUVBQW9FLDhCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU07QUFBQSxnQkFDTixhQUFZO0FBQUEsZ0JBQ1osU0FBU0osVUFBVTZFLElBQUksQ0FBQ0MsU0FBUyxFQUFFckIsT0FBT3FCLElBQUlDLElBQUlDLE9BQU9GLElBQUlHLEtBQUssRUFBRTtBQUFBLGdCQUNwRSxPQUFPM0U7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDa0QsTUFBTWpELGNBQWNpRCxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsZ0JBQzdDLE9BQU8vQyxXQUFXSjtBQUFBQTtBQUFBQSxjQU5wQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNK0I7QUFBQSxZQUUvQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTdUM7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUFpRTtBQUFBO0FBQUEsY0FIN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sT0FBT3JDO0FBQUFBLGNBQ1AsVUFBVSxDQUFDZ0QsTUFBTTtBQUFFL0Msd0JBQVErQyxFQUFFRSxPQUFPRCxLQUFLO0FBQUc5Qyw4QkFBYyxDQUFDZ0QsVUFBVSxFQUFFLEdBQUdBLE1BQU1uRCxNQUFNb0QsT0FBVSxFQUFFO0FBQUEsY0FBRztBQUFBLGNBQ3JHLE9BQU9sRCxXQUFXRjtBQUFBQTtBQUFBQSxZQUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJeUI7QUFBQSxhQXRCM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFdBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2QkE7QUFBQSxNQUVBLHVCQUFDLGFBQVEsV0FBVSw2REFDakI7QUFBQSwrQkFBQyxRQUFHLFdBQVUscUVBQW9FLDJCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sYUFBWTtBQUFBLGNBQ1osT0FBT0ksU0FBUzdCO0FBQUFBLGNBQ2hCLFVBQVV1RSxxQkFBcUIsT0FBTztBQUFBLGNBQ3RDLE9BQU94QyxVQUFVL0I7QUFBQUE7QUFBQUEsWUFMbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3lCLEtBTjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixNQUFLO0FBQUEsY0FDTCxhQUFZO0FBQUEsY0FDWixPQUFPNkIsU0FBUzVCO0FBQUFBLGNBQ2hCLFVBQVVzRSxxQkFBcUIsWUFBWTtBQUFBLGNBQzNDLE9BQU94QyxVQUFVOUI7QUFBQUE7QUFBQUEsWUFObkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTThCO0FBQUEsVUFFOUI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLGFBQVk7QUFBQSxjQUNaLE9BQU80QixTQUFTM0I7QUFBQUEsY0FDaEIsVUFBVXFFLHFCQUFxQixlQUFlO0FBQUEsY0FDOUMsT0FBT3hDLFVBQVU3QjtBQUFBQTtBQUFBQSxZQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLaUM7QUFBQSxVQUVqQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sYUFBWTtBQUFBLGNBQ1osU0FBU2lFLGFBQWEyQixJQUFJLENBQUNLLE9BQU8sRUFBRXpCLE9BQU95QixHQUFHRixPQUFPRSxFQUFFLEVBQUU7QUFBQSxjQUN6RCxPQUFPdEUsU0FBUzFCO0FBQUFBLGNBQ2hCLFVBQVVvRSxxQkFBcUIsT0FBTztBQUFBLGNBQ3RDLE9BQU94QyxVQUFVNUI7QUFBQUE7QUFBQUEsWUFObkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXlCO0FBQUEsVUFFekI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLGFBQWEwQixTQUFTMUIsUUFBUSxpQkFBaUI7QUFBQSxjQUMvQyxTQUFTbUUsY0FBY3dCLElBQUksQ0FBQ3BGLE9BQU8sRUFBRWdFLE9BQU9oRSxHQUFHdUYsT0FBT3ZGLEVBQUUsRUFBRTtBQUFBLGNBQzFELE9BQU9tQixTQUFTekI7QUFBQUEsY0FDaEIsVUFBVW1FLHFCQUFxQixRQUFRO0FBQUEsY0FDdkMsVUFBVSxDQUFDMUMsU0FBUzFCO0FBQUFBLGNBQ3BCLE9BQU80QixVQUFVM0I7QUFBQUE7QUFBQUEsWUFQbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTzBCO0FBQUEsYUF4QzVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQ0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFDYixpQ0FBQyxVQUFPLE1BQUssVUFBUyxTQUFTZ0YsZUFBZSwwQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9EQTtBQUFBLE1BRUEsdUJBQUMsYUFBUSxXQUFVLHlEQUNqQjtBQUFBLCtCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxnRUFBK0Q7QUFBQTtBQUFBLFlBQzdEbkQsTUFBTW9EO0FBQUFBLFlBQU87QUFBQSxlQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQzFELFdBQVdNLFNBQVMsdUJBQUMsT0FBRSxXQUFVLHdCQUF3Qk4scUJBQVdNLFNBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNEO0FBQUEsYUFKN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQ0EsTUFBTW9ELFdBQVcsSUFDaEIsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQTtBQUFBLFVBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRzJCLEtBSjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQSxJQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUNDLGlDQUFDLE1BQ0M7QUFBQSxtQ0FBQyxNQUFHLFdBQVUsUUFBTyxrQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUI7QUFBQSxZQUN2Qix1QkFBQyxNQUFHLG9CQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVE7QUFBQSxZQUNSLHVCQUFDLE1BQUcsMEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYztBQUFBLFlBQ2QsdUJBQUMsTUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFTO0FBQUEsWUFDVCx1QkFBQyxNQUFHLHNCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVU7QUFBQSxZQUNWLHVCQUFDLE1BQUcsV0FBVSxtQkFBa0Isb0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DO0FBQUEsZUFOdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0VwRCxnQkFBTTZEO0FBQUFBLFlBQUksQ0FBQ00sTUFBTUMsVUFDaEIsdUJBQUMsTUFDQztBQUFBLHFDQUFDLE1BQUlBLGtCQUFRLEtBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZTtBQUFBLGNBQ2YsdUJBQUMsTUFDQztBQUFBLHVDQUFDLE9BQUUsV0FBVSw4QkFBOEJELGVBQUtwRyxTQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRDtBQUFBLGdCQUN0RDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFNb0csS0FBS2I7QUFBQUEsb0JBQ1gsUUFBTztBQUFBLG9CQUNQLEtBQUk7QUFBQSxvQkFDSixXQUFVO0FBQUEsb0JBRVRhLGVBQUtiO0FBQUFBO0FBQUFBLGtCQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUNBLHVCQUFDLE1BQ0MsaUNBQUMsVUFBSyxXQUFVLDhDQUNiYSxlQUFLakIsbUJBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxjQUNBLHVCQUFDLE1BQUlpQixlQUFLakcsU0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQjtBQUFBLGNBQ2hCLHVCQUFDLE1BQ0MsaUNBQUMsU0FBTSxTQUFTTSxtQkFBbUIyRixLQUFLaEcsTUFBTSxHQUFJZ0csZUFBS2hHLFVBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThELEtBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE1BQUcsV0FBVSxjQUNaO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFRO0FBQUEsa0JBQ1IsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTW9GLGlCQUFpQlksS0FBS2QsR0FBRztBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsaUJBL0JPYyxLQUFLZCxLQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0NBO0FBQUEsVUFDRCxLQW5DSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9DQTtBQUFBLGFBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnREE7QUFBQSxRQUdGLHVCQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSwwQkFDVnJELGdCQUFNb0QsU0FBUyxJQUNaLEdBQUdwRCxNQUFNb0QsTUFBTSw2QkFBNkI1RCxRQUFRLGtCQUFrQixLQUN0RSxzQ0FITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLE1BQUssVUFBUyxNQUFLLE1BQUssU0FBU1UsUUFBUSxTQUFTdUQsWUFBWSwwQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0E3RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThFQTtBQUFBLFNBbkxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvTEE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNckQ7QUFBQUEsUUFDTixTQUFTLE1BQU1DLGdCQUFnQixLQUFLO0FBQUEsUUFDcEMsT0FDRUMsWUFBWSxTQUNSLG9CQUNBQSxZQUFZLFFBQ1Ysb0JBQ0E7QUFBQSxRQUVSLE1BQUs7QUFBQSxRQUNMLFFBQ0VBLFlBQVksU0FDVix1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFTLE1BQU07QUFBRUMscUJBQVcsS0FBSztBQUFHSSxxQkFBVyxFQUFFO0FBQUEsUUFBRyxHQUFHLGlDQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQSxtQ0FDR0w7QUFBQUEsc0JBQVksVUFDWDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUTtBQUFBLGNBQ1IsU0FBU007QUFBQUEsY0FDVCxTQUFTcUI7QUFBQUEsY0FBZ0I7QUFBQTtBQUFBLFlBSjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFFRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUTtBQUFBLGNBQ1IsU0FBUyxNQUFNMUIsV0FBVyxNQUFNO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFIcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTSztBQUFBQSxjQUNULFNBQVNOLFlBQVksUUFBUXdCLGtCQUFrQkU7QUFBQUEsY0FBZ0I7QUFBQTtBQUFBLFlBSGpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFFBSUgxQixzQkFBWSxTQUNYLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUNDLGlDQUFDLE1BQ0M7QUFBQSxtQ0FBQyxNQUFHLFdBQVUsUUFBTyxpQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0I7QUFBQSxZQUN0Qix1QkFBQyxNQUFHLG9CQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVE7QUFBQSxZQUNSLHVCQUFDLE1BQUcsV0FBVSxVQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFCO0FBQUEsZUFIdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0V0QixvQkFBVTZFO0FBQUFBLFlBQUksQ0FBQ0MsS0FBS08sTUFDbkIsdUJBQUMsTUFDQztBQUFBLHFDQUFDLE1BQUlBLGNBQUksS0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFXO0FBQUEsY0FDWCx1QkFBQyxNQUFJUCxjQUFJRyxRQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWM7QUFBQSxjQUNkLHVCQUFDLE1BQ0M7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVE7QUFBQSxrQkFDUixNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNO0FBQ2IxRCwrQkFBVyxNQUFNO0FBQ2pCRSxpQ0FBYXFELElBQUlDLEVBQUU7QUFDbkJwRCwrQkFBV21ELElBQUlHLElBQUk7QUFBQSxrQkFDckI7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsaUJBaEJPSCxJQUFJQyxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsVUFDRCxLQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLGFBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4QkEsSUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sYUFBWTtBQUFBLFlBQ1osT0FBT3JEO0FBQUFBLFlBQ1AsVUFBVSxDQUFDOEIsTUFBTTdCLFdBQVc2QixFQUFFRSxPQUFPRCxLQUFLO0FBQUE7QUFBQSxVQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJOEM7QUFBQTtBQUFBLE1BbkZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFzRkE7QUFBQSxPQTdRRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOFFBO0FBRUo7QUFBQzNELEdBdmdCdUJELFlBQVU7QUFBQSxVQUNWdkIsUUFBUTtBQUFBO0FBQUEsS0FEUnVCO0FBQVUsSUFBQXlGO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiTGluayIsIkJhZGdlIiwiQnV0dG9uIiwiRGF0ZVBpY2tlciIsIkVtcHR5U3RhdGUiLCJJbnB1dCIsIkxvYWRpbmciLCJNb2RhbCIsIlNlbGVjdCIsIlRhYmxlIiwiVEJvZHkiLCJUZCIsIlRoIiwiVEhlYWQiLCJUciIsInVzZVRvYXN0IiwiZ2V0RW1wbG95ZWVzIiwiZ2V0UGhhc2VzIiwic2F2ZUxzcHB0IiwiY3JlYXRlRW1wbG95ZWUiLCJ1cGRhdGVFbXBsb3llZSIsImRlbGV0ZUVtcGxveWVlIiwiQ0xJQ0tVUF9JRF9QQVRURVJOIiwiRU1QVFlfVEFTS19GT1JNIiwidGl0bGUiLCJjbGlja3VwVXJsIiwiY2xpY2t1cFRhc2tJZCIsInBoYXNlIiwic3RhdHVzIiwidGFza1NlcSIsImV4dHJhY3RDbGlja1VwSWQiLCJ1cmwiLCJtYXRjaCIsInN0YXR1c0JhZGdlVmFyaWFudCIsInMiLCJ0b0xvd2VyQ2FzZSIsInN0YXJ0c1dpdGgiLCJpbmNsdWRlcyIsIlN1Ym1pdFBhZ2UiLCJfcyIsInNob3dUb2FzdCIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsInBoYXNlcyIsInNldFBoYXNlcyIsIm1ldGFMb2FkaW5nIiwic2V0TWV0YUxvYWRpbmciLCJlbXBsb3llZUlkIiwic2V0RW1wbG95ZWVJZCIsImRhdGUiLCJzZXREYXRlIiwiZm9ybUVycm9ycyIsInNldEZvcm1FcnJvcnMiLCJ0YXNrRm9ybSIsInNldFRhc2tGb3JtIiwicm93RXJyb3JzIiwic2V0Um93RXJyb3JzIiwidGFza3MiLCJzZXRUYXNrcyIsInNhdmluZyIsInNldFNhdmluZyIsImVtcE1vZGFsT3BlbiIsInNldEVtcE1vZGFsT3BlbiIsImVtcFZpZXciLCJzZXRFbXBWaWV3IiwiZW1wRWRpdElkIiwic2V0RW1wRWRpdElkIiwiZW1wTmFtZSIsInNldEVtcE5hbWUiLCJlbXBTYXZpbmciLCJzZXRFbXBTYXZpbmciLCJjYW5jZWxsZWQiLCJQcm9taXNlIiwiYWxsIiwidGhlbiIsImVtcFJlcyIsInBoYXNlUmVzIiwiZGF0YSIsImNhdGNoIiwiZXJyIiwidHlwZSIsIm1lc3NhZ2UiLCJyZXNwb25zZSIsImZpbmFsbHkiLCJsb2FkRW1wbG95ZWVzIiwicmVzIiwib3BlbkVtcE1vZGFsIiwiaGFuZGxlRW1wQ3JlYXRlIiwidHJpbSIsImhhbmRsZUVtcFVwZGF0ZSIsImhhbmRsZUVtcERlbGV0ZSIsInBoYXNlT3B0aW9ucyIsIk9iamVjdCIsImtleXMiLCJzdGF0dXNPcHRpb25zIiwiaGFuZGxlVGFza0Zvcm1DaGFuZ2UiLCJmaWVsZCIsImUiLCJ2YWx1ZSIsInRhcmdldCIsInByZXYiLCJ1bmRlZmluZWQiLCJleHRyYWN0ZWQiLCJ2YWxpZGF0ZVRhc2tGb3JtIiwiZXJycyIsInNvbWUiLCJ0IiwiY2xpY2t1cF90YXNrX2lkIiwiaGFuZGxlQWRkVGFzayIsImxlbmd0aCIsInVpZCIsImNsaWNrdXBfdXJsIiwiaGFuZGxlUmVtb3ZlVGFzayIsImZpbHRlciIsImhhbmRsZVNhdmUiLCJwYXlsb2FkIiwiZW1wbG95ZWVfaWQiLCJOdW1iZXIiLCJtYXAiLCJlbXAiLCJpZCIsImxhYmVsIiwibmFtZSIsInAiLCJ0YXNrIiwiaW5kZXgiLCJpIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU3VibWl0UGFnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQge1xyXG4gIEJhZGdlLFxyXG4gIEJ1dHRvbixcclxuICBEYXRlUGlja2VyLFxyXG4gIEVtcHR5U3RhdGUsXHJcbiAgSW5wdXQsXHJcbiAgTG9hZGluZyxcclxuICBNb2RhbCxcclxuICBTZWxlY3QsXHJcbiAgVGFibGUsXHJcbiAgVEJvZHksXHJcbiAgVGQsXHJcbiAgVGgsXHJcbiAgVEhlYWQsXHJcbiAgVHIsXHJcbiAgdXNlVG9hc3QsXHJcbn0gZnJvbSAnLi4vY29tcG9uZW50cy91aSc7XHJcbmltcG9ydCB7XHJcbiAgZ2V0RW1wbG95ZWVzLFxyXG4gIGdldFBoYXNlcyxcclxuICBzYXZlTHNwcHQsXHJcbiAgY3JlYXRlRW1wbG95ZWUsXHJcbiAgdXBkYXRlRW1wbG95ZWUsXHJcbiAgZGVsZXRlRW1wbG95ZWUsXHJcbn0gZnJvbSAnLi4vYXBpL2xzcHB0LmpzJztcclxuXHJcbmNvbnN0IENMSUNLVVBfSURfUEFUVEVSTiA9IC9cXC8oW2EtejAtOV0rKVxcLz8kL2k7XHJcblxyXG5jb25zdCBFTVBUWV9UQVNLX0ZPUk0gPSB7XHJcbiAgdGl0bGU6ICcnLFxyXG4gIGNsaWNrdXBVcmw6ICcnLFxyXG4gIGNsaWNrdXBUYXNrSWQ6ICcnLFxyXG4gIHBoYXNlOiAnJyxcclxuICBzdGF0dXM6ICcnLFxyXG59O1xyXG5cclxubGV0IHRhc2tTZXEgPSAwO1xyXG5cclxuZnVuY3Rpb24gZXh0cmFjdENsaWNrVXBJZCh1cmwpIHtcclxuICBjb25zdCBtYXRjaCA9IHVybC5tYXRjaChDTElDS1VQX0lEX1BBVFRFUk4pO1xyXG4gIHJldHVybiBtYXRjaCA/IG1hdGNoWzFdIDogbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gc3RhdHVzQmFkZ2VWYXJpYW50KHN0YXR1cykge1xyXG4gIGNvbnN0IHMgPSBzdGF0dXMudG9Mb3dlckNhc2UoKTtcclxuICBpZiAocy5zdGFydHNXaXRoKCdjb21wbGV0ZWQnKSkgcmV0dXJuICdzdWNjZXNzJztcclxuICBpZiAocy5pbmNsdWRlcygncHJvZ3Jlc3MnKSB8fCBzLmluY2x1ZGVzKCd0ZXN0aW5nJykgfHwgcy5pbmNsdWRlcygnZG9jdW1lbnRhdGlvbicpKSByZXR1cm4gJ2luZm8nO1xyXG4gIGlmIChzLmluY2x1ZGVzKCdob2xkJykgfHwgcy5pbmNsdWRlcygnZmVlZGJhY2snKSkgcmV0dXJuICd3YXJuaW5nJztcclxuICByZXR1cm4gJ25ldXRyYWwnO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTdWJtaXRQYWdlKCkge1xyXG4gIGNvbnN0IHsgc2hvd1RvYXN0IH0gPSB1c2VUb2FzdCgpO1xyXG5cclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwaGFzZXMsIHNldFBoYXNlc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW21ldGFMb2FkaW5nLCBzZXRNZXRhTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuXHJcbiAgY29uc3QgW2VtcGxveWVlSWQsIHNldEVtcGxveWVlSWRdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtkYXRlLCBzZXREYXRlXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbZm9ybUVycm9ycywgc2V0Rm9ybUVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcblxyXG4gIGNvbnN0IFt0YXNrRm9ybSwgc2V0VGFza0Zvcm1dID0gdXNlU3RhdGUoRU1QVFlfVEFTS19GT1JNKTtcclxuICBjb25zdCBbcm93RXJyb3JzLCBzZXRSb3dFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFt0YXNrcywgc2V0VGFza3NdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFtlbXBNb2RhbE9wZW4sIHNldEVtcE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2VtcFZpZXcsIHNldEVtcFZpZXddID0gdXNlU3RhdGUoJ2xpc3QnKTtcclxuICBjb25zdCBbZW1wRWRpdElkLCBzZXRFbXBFZGl0SWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2VtcE5hbWUsIHNldEVtcE5hbWVdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtlbXBTYXZpbmcsIHNldEVtcFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XHJcbiAgICBQcm9taXNlLmFsbChbZ2V0RW1wbG95ZWVzKCksIGdldFBoYXNlcygpXSlcclxuICAgICAgLnRoZW4oKFtlbXBSZXMsIHBoYXNlUmVzXSkgPT4ge1xyXG4gICAgICAgIGlmIChjYW5jZWxsZWQpIHJldHVybjtcclxuICAgICAgICBzZXRFbXBsb3llZXMoZW1wUmVzLmRhdGEpO1xyXG4gICAgICAgIHNldFBoYXNlcyhwaGFzZVJlcy5kYXRhKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm47XHJcbiAgICAgICAgc2hvd1RvYXN0KHtcclxuICAgICAgICAgIHR5cGU6ICdlcnJvcicsXHJcbiAgICAgICAgICB0aXRsZTogJ0dhZ2FsIG1lbXVhdCBkYXRhJyxcclxuICAgICAgICAgIG1lc3NhZ2U6IGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBlcnIubWVzc2FnZSxcclxuICAgICAgICB9KTtcclxuICAgICAgfSlcclxuICAgICAgLmZpbmFsbHkoKCkgPT4ge1xyXG4gICAgICAgIGlmICghY2FuY2VsbGVkKSBzZXRNZXRhTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH0pO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgY2FuY2VsbGVkID0gdHJ1ZTtcclxuICAgIH07XHJcbiAgfSwgW3Nob3dUb2FzdF0pO1xyXG5cclxuICBjb25zdCBsb2FkRW1wbG95ZWVzID0gKCkgPT4ge1xyXG4gICAgZ2V0RW1wbG95ZWVzKClcclxuICAgICAgLnRoZW4oKHJlcykgPT4gc2V0RW1wbG95ZWVzKHJlcy5kYXRhKSlcclxuICAgICAgLmNhdGNoKCgpID0+IHt9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBvcGVuRW1wTW9kYWwgPSAoKSA9PiB7XHJcbiAgICBzZXRFbXBWaWV3KCdsaXN0Jyk7XHJcbiAgICBzZXRFbXBFZGl0SWQobnVsbCk7XHJcbiAgICBzZXRFbXBOYW1lKCcnKTtcclxuICAgIHNldEVtcE1vZGFsT3Blbih0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFbXBDcmVhdGUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWVtcE5hbWUudHJpbSgpKSByZXR1cm47XHJcbiAgICBzZXRFbXBTYXZpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBjcmVhdGVFbXBsb3llZShlbXBOYW1lLnRyaW0oKSk7XHJcbiAgICAgIHNob3dUb2FzdCh7IHR5cGU6ICdzdWNjZXNzJywgdGl0bGU6ICdCZXJoYXNpbCcsIG1lc3NhZ2U6ICdLYXJ5YXdhbiBkaXRhbWJhaGthbicgfSk7XHJcbiAgICAgIGxvYWRFbXBsb3llZXMoKTtcclxuICAgICAgc2V0RW1wVmlldygnbGlzdCcpO1xyXG4gICAgICBzZXRFbXBOYW1lKCcnKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzaG93VG9hc3QoeyB0eXBlOiAnZXJyb3InLCB0aXRsZTogJ0dhZ2FsJywgbWVzc2FnZTogZXJyLm1lc3NhZ2UgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRFbXBTYXZpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUVtcFVwZGF0ZSA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghZW1wTmFtZS50cmltKCkgfHwgIWVtcEVkaXRJZCkgcmV0dXJuO1xyXG4gICAgc2V0RW1wU2F2aW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgdXBkYXRlRW1wbG95ZWUoZW1wRWRpdElkLCBlbXBOYW1lLnRyaW0oKSk7XHJcbiAgICAgIHNob3dUb2FzdCh7IHR5cGU6ICdzdWNjZXNzJywgdGl0bGU6ICdCZXJoYXNpbCcsIG1lc3NhZ2U6ICdLYXJ5YXdhbiBkaXBlcmJhcnVpJyB9KTtcclxuICAgICAgbG9hZEVtcGxveWVlcygpO1xyXG4gICAgICBzZXRFbXBWaWV3KCdsaXN0Jyk7XHJcbiAgICAgIHNldEVtcEVkaXRJZChudWxsKTtcclxuICAgICAgc2V0RW1wTmFtZSgnJyk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2hvd1RvYXN0KHsgdHlwZTogJ2Vycm9yJywgdGl0bGU6ICdHYWdhbCcsIG1lc3NhZ2U6IGVyci5tZXNzYWdlIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0RW1wU2F2aW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFbXBEZWxldGUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWVtcEVkaXRJZCkgcmV0dXJuO1xyXG4gICAgc2V0RW1wU2F2aW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgZGVsZXRlRW1wbG95ZWUoZW1wRWRpdElkKTtcclxuICAgICAgc2hvd1RvYXN0KHsgdHlwZTogJ3N1Y2Nlc3MnLCB0aXRsZTogJ0Jlcmhhc2lsJywgbWVzc2FnZTogJ0thcnlhd2FuIGRpaGFwdXMnIH0pO1xyXG4gICAgICBsb2FkRW1wbG95ZWVzKCk7XHJcbiAgICAgIHNldEVtcFZpZXcoJ2xpc3QnKTtcclxuICAgICAgc2V0RW1wRWRpdElkKG51bGwpO1xyXG4gICAgICBzZXRFbXBOYW1lKCcnKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzaG93VG9hc3QoeyB0eXBlOiAnZXJyb3InLCB0aXRsZTogJ0dhZ2FsIG1lbmdoYXB1cycsIG1lc3NhZ2U6IGVyci5tZXNzYWdlIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0RW1wU2F2aW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBwaGFzZU9wdGlvbnMgPSBPYmplY3Qua2V5cyhwaGFzZXMpO1xyXG4gIGNvbnN0IHN0YXR1c09wdGlvbnMgPSB0YXNrRm9ybS5waGFzZSA/IHBoYXNlc1t0YXNrRm9ybS5waGFzZV0gPz8gW10gOiBbXTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVGFza0Zvcm1DaGFuZ2UgPSAoZmllbGQpID0+IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuXHJcbiAgICBpZiAoZmllbGQgPT09ICdwaGFzZScpIHtcclxuICAgICAgc2V0VGFza0Zvcm0oKHByZXYpID0+ICh7IC4uLnByZXYsIHBoYXNlOiB2YWx1ZSwgc3RhdHVzOiAnJyB9KSk7XHJcbiAgICAgIHNldFJvd0Vycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgcGhhc2U6IHVuZGVmaW5lZCwgc3RhdHVzOiB1bmRlZmluZWQgfSkpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGZpZWxkID09PSAnY2xpY2t1cFVybCcpIHtcclxuICAgICAgY29uc3QgZXh0cmFjdGVkID0gZXh0cmFjdENsaWNrVXBJZCh2YWx1ZSk7XHJcbiAgICAgIHNldFRhc2tGb3JtKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgY2xpY2t1cFVybDogdmFsdWUsXHJcbiAgICAgICAgLi4uKGV4dHJhY3RlZCA/IHsgY2xpY2t1cFRhc2tJZDogZXh0cmFjdGVkIH0gOiB7fSksXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0Um93RXJyb3JzKChwcmV2KSA9PlxyXG4gICAgICAgIGV4dHJhY3RlZFxyXG4gICAgICAgICAgPyB7IC4uLnByZXYsIGNsaWNrdXBVcmw6IHVuZGVmaW5lZCwgY2xpY2t1cFRhc2tJZDogdW5kZWZpbmVkIH1cclxuICAgICAgICAgIDogeyAuLi5wcmV2LCBjbGlja3VwVXJsOiB1bmRlZmluZWQgfVxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0VGFza0Zvcm0oKHByZXYpID0+ICh7IC4uLnByZXYsIFtmaWVsZF06IHZhbHVlIH0pKTtcclxuICAgIHNldFJvd0Vycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdW5kZWZpbmVkIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZVRhc2tGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgZXJycyA9IHt9O1xyXG4gICAgaWYgKCFlbXBsb3llZUlkKSBlcnJzLmVtcGxveWVlSWQgPSAnUGlsaWgga2FyeWF3YW4nO1xyXG4gICAgaWYgKCFkYXRlKSBlcnJzLmRhdGUgPSAnUGlsaWggdGFuZ2dhbCc7XHJcbiAgICBpZiAoIXRhc2tGb3JtLnRpdGxlLnRyaW0oKSkgZXJycy50aXRsZSA9ICdKdWR1bCB0dWdhcyB3YWppYiBkaWlzaSc7XHJcblxyXG4gICAgaWYgKCF0YXNrRm9ybS5jbGlja3VwVXJsLnRyaW0oKSkgZXJycy5jbGlja3VwVXJsID0gJ0NsaWNrVXAgVVJMIHdhamliIGRpaXNpJztcclxuICAgIGVsc2UgaWYgKCFleHRyYWN0Q2xpY2tVcElkKHRhc2tGb3JtLmNsaWNrdXBVcmwudHJpbSgpKSlcclxuICAgICAgZXJycy5jbGlja3VwVXJsID0gJ0Zvcm1hdCBVUkwgdGlkYWsgdmFsaWQgKGNvbnRvaDogaHR0cHM6Ly9hcHAuY2xpY2t1cC5jb20vdC85MDAzMDA2NzIzLzg2ZDQxYzh1ciknO1xyXG5cclxuICAgIGlmICghdGFza0Zvcm0uY2xpY2t1cFRhc2tJZC50cmltKCkpIGVycnMuY2xpY2t1cFRhc2tJZCA9ICdDbGlja1VwIFRhc2sgSUQgd2FqaWIgZGlpc2knO1xyXG4gICAgZWxzZSBpZiAoXHJcbiAgICAgIHRhc2tzLnNvbWUoXHJcbiAgICAgICAgKHQpID0+IHQuY2xpY2t1cF90YXNrX2lkLnRvTG93ZXJDYXNlKCkgPT09IHRhc2tGb3JtLmNsaWNrdXBUYXNrSWQudHJpbSgpLnRvTG93ZXJDYXNlKClcclxuICAgICAgKVxyXG4gICAgKVxyXG4gICAgICBlcnJzLmNsaWNrdXBUYXNrSWQgPSAnVGFzayBJRCBzdWRhaCBhZGEgZGkgZGFmdGFyJztcclxuXHJcbiAgICBpZiAoIXRhc2tGb3JtLnBoYXNlKSBlcnJzLnBoYXNlID0gJ1BpbGloIHBoYXNlJztcclxuICAgIGlmICghdGFza0Zvcm0uc3RhdHVzKSBlcnJzLnN0YXR1cyA9ICdQaWxpaCBzdGF0dXMnO1xyXG5cclxuICAgIHJldHVybiBlcnJzO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFkZFRhc2sgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBlcnJzID0gdmFsaWRhdGVUYXNrRm9ybSgpO1xyXG4gICAgc2V0Um93RXJyb3JzKGVycnMpO1xyXG4gICAgc2V0Rm9ybUVycm9ycyh7IGVtcGxveWVlSWQ6IGVycnMuZW1wbG95ZWVJZCwgZGF0ZTogZXJycy5kYXRlIH0pO1xyXG4gICAgaWYgKE9iamVjdC5rZXlzKGVycnMpLmxlbmd0aCA+IDApIHJldHVybjtcclxuXHJcbiAgICBzZXRUYXNrcygocHJldikgPT4gW1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICB7XHJcbiAgICAgICAgdWlkOiArK3Rhc2tTZXEsXHJcbiAgICAgICAgdGl0bGU6IHRhc2tGb3JtLnRpdGxlLnRyaW0oKSxcclxuICAgICAgICBjbGlja3VwX3VybDogdGFza0Zvcm0uY2xpY2t1cFVybC50cmltKCksXHJcbiAgICAgICAgY2xpY2t1cF90YXNrX2lkOiB0YXNrRm9ybS5jbGlja3VwVGFza0lkLnRyaW0oKSxcclxuICAgICAgICBwaGFzZTogdGFza0Zvcm0ucGhhc2UsXHJcbiAgICAgICAgc3RhdHVzOiB0YXNrRm9ybS5zdGF0dXMsXHJcbiAgICAgIH0sXHJcbiAgICBdKTtcclxuICAgIHNldFRhc2tGb3JtKEVNUFRZX1RBU0tfRk9STSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVtb3ZlVGFzayA9ICh1aWQpID0+IHtcclxuICAgIHNldFRhc2tzKChwcmV2KSA9PiBwcmV2LmZpbHRlcigodCkgPT4gdC51aWQgIT09IHVpZCkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBlcnJzID0ge307XHJcbiAgICBpZiAoIWVtcGxveWVlSWQpIGVycnMuZW1wbG95ZWVJZCA9ICdQaWxpaCBrYXJ5YXdhbic7XHJcbiAgICBpZiAoIWRhdGUpIGVycnMuZGF0ZSA9ICdQaWxpaCB0YW5nZ2FsJztcclxuICAgIGlmICh0YXNrcy5sZW5ndGggPT09IDApIGVycnMudGFza3MgPSAnVGFtYmFoa2FuIG1pbmltYWwgc2F0dSB0YXNrIHNlYmVsdW0gbWVueWltcGFuJztcclxuICAgIHNldEZvcm1FcnJvcnMoZXJycyk7XHJcblxyXG4gICAgaWYgKE9iamVjdC5rZXlzKGVycnMpLmxlbmd0aCA+IDApIHtcclxuICAgICAgc2hvd1RvYXN0KHtcclxuICAgICAgICB0eXBlOiAnZXJyb3InLFxyXG4gICAgICAgIHRpdGxlOiAnRm9ybSBiZWx1bSBsZW5na2FwJyxcclxuICAgICAgICBtZXNzYWdlOiAnTGVuZ2thcGkga2FyeWF3YW4sIHRhbmdnYWwsIGRhbiB0YW1iYWhrYW4gbWluaW1hbCBzYXR1IHRhc2suJyxcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICBlbXBsb3llZV9pZDogTnVtYmVyKGVtcGxveWVlSWQpLFxyXG4gICAgICBkYXRlLFxyXG4gICAgICB0YXNrczogdGFza3MubWFwKCh7IHRpdGxlLCBjbGlja3VwX3VybCwgY2xpY2t1cF90YXNrX2lkLCBwaGFzZSwgc3RhdHVzIH0pID0+ICh7XHJcbiAgICAgICAgdGl0bGUsXHJcbiAgICAgICAgY2xpY2t1cF91cmwsXHJcbiAgICAgICAgY2xpY2t1cF90YXNrX2lkLFxyXG4gICAgICAgIHBoYXNlLFxyXG4gICAgICAgIHN0YXR1cyxcclxuICAgICAgfSkpLFxyXG4gICAgfTtcclxuXHJcbiAgICBzZXRTYXZpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBzYXZlTHNwcHQocGF5bG9hZCk7XHJcbiAgICAgIHNob3dUb2FzdCh7XHJcbiAgICAgICAgdHlwZTogJ3N1Y2Nlc3MnLFxyXG4gICAgICAgIHRpdGxlOiAnQmVyaGFzaWwnLFxyXG4gICAgICAgIG1lc3NhZ2U6IHJlcy5tZXNzYWdlIHx8ICdMU1BQVCBzYXZlZCBzdWNjZXNzZnVsbHknLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0VGFza3MoW10pO1xyXG4gICAgICBzZXRUYXNrRm9ybShFTVBUWV9UQVNLX0ZPUk0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgZXJyLm1lc3NhZ2U7XHJcbiAgICAgIHNob3dUb2FzdCh7XHJcbiAgICAgICAgdHlwZTogJ2Vycm9yJyxcclxuICAgICAgICB0aXRsZTogZXJyLnN0YXR1cyA9PT0gNDA5ID8gJ1Rhc2sgZHVwbGlrYXQnIDogJ0dhZ2FsIG1lbnlpbXBhbiBMU1BQVCcsXHJcbiAgICAgICAgbWVzc2FnZSxcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRTYXZpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGlmIChtZXRhTG9hZGluZykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtNTBcIj5cclxuICAgICAgICA8TG9hZGluZyBzaXplPVwibGdcIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtNTAgcC04XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy03eGwgc3BhY2UteS02XCI+XHJcbiAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5MU1BQVCBUcmFja2VyPC9oMT5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgTGFwb3JhbiBTdGF0dXMgUHJvZ3Jlc3MgUGVrZXJqYWFuIEthcnlhd2FuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89XCIvaGlzdG9yeVwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ibHVlLTYwMCBob3Zlcjp0ZXh0LWJsdWUtNzAwIGhvdmVyOnVuZGVybGluZVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIExpaGF0IEhpc3Rvcnkg4oaSXHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9oZWFkZXI+XHJcblxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1zbSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtc2xhdGUtNjAwXCI+XHJcbiAgICAgICAgICAgIEluZm9ybWFzaSBVbXVtXHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC00IG1kOmdyaWQtY29scy0yXCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlBpbGloIGthcnlhd2FuXCJcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKHsgdmFsdWU6IGVtcC5pZCwgbGFiZWw6IGVtcC5uYW1lIH0pKX1cclxuICAgICAgICAgICAgICAgIHZhbHVlPXtlbXBsb3llZUlkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbXBsb3llZUlkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIGVycm9yPXtmb3JtRXJyb3JzLmVtcGxveWVlSWR9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29wZW5FbXBNb2RhbH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LWJsdWUtNjAwIGhvdmVyOnVuZGVybGluZVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAg4pqZIEtlbG9sYSBLYXJ5YXdhblxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgICAgICBsYWJlbD1cIlRhbmdnYWxcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtkYXRlfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4geyBzZXREYXRlKGUudGFyZ2V0LnZhbHVlKTsgc2V0Rm9ybUVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgZGF0ZTogdW5kZWZpbmVkIH0pKTsgfX1cclxuICAgICAgICAgICAgICBlcnJvcj17Zm9ybUVycm9ycy5kYXRlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHAtNSBzaGFkb3ctc21cIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJtYi00IHRleHQtc20gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LXNsYXRlLTYwMFwiPlxyXG4gICAgICAgICAgICBUYW1iYWggVGFza1xyXG4gICAgICAgICAgPC9oMj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNCBtZDpncmlkLWNvbHMtMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiVGFzayBUaXRsZVwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNvbnRvaDogQ1RNUyAtIElzc3VlIExpc3QgUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXt0YXNrRm9ybS50aXRsZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVUYXNrRm9ybUNoYW5nZSgndGl0bGUnKX1cclxuICAgICAgICAgICAgICAgIGVycm9yPXtyb3dFcnJvcnMudGl0bGV9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiQ2xpY2tVcCBVUkxcIlxyXG4gICAgICAgICAgICAgIHR5cGU9XCJ1cmxcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiaHR0cHM6Ly9hcHAuY2xpY2t1cC5jb20vdC85MDAzMDA2NzIzLzg2ZDQxYzh1clwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3Rhc2tGb3JtLmNsaWNrdXBVcmx9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVRhc2tGb3JtQ2hhbmdlKCdjbGlja3VwVXJsJyl9XHJcbiAgICAgICAgICAgICAgZXJyb3I9e3Jvd0Vycm9ycy5jbGlja3VwVXJsfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICBsYWJlbD1cIkNsaWNrVXAgVGFzayBJRFwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJPdG9tYXRpcyB0ZXJpc2kgZGFyaSBVUkxcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXt0YXNrRm9ybS5jbGlja3VwVGFza0lkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVUYXNrRm9ybUNoYW5nZSgnY2xpY2t1cFRhc2tJZCcpfVxyXG4gICAgICAgICAgICAgIGVycm9yPXtyb3dFcnJvcnMuY2xpY2t1cFRhc2tJZH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiUGhhc2VcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUGlsaWggcGhhc2VcIlxyXG4gICAgICAgICAgICAgIG9wdGlvbnM9e3BoYXNlT3B0aW9ucy5tYXAoKHApID0+ICh7IHZhbHVlOiBwLCBsYWJlbDogcCB9KSl9XHJcbiAgICAgICAgICAgICAgdmFsdWU9e3Rhc2tGb3JtLnBoYXNlfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVUYXNrRm9ybUNoYW5nZSgncGhhc2UnKX1cclxuICAgICAgICAgICAgICBlcnJvcj17cm93RXJyb3JzLnBoYXNlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJTdGF0dXNcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0YXNrRm9ybS5waGFzZSA/ICdQaWxpaCBzdGF0dXMnIDogJ1BpbGloIHBoYXNlIHRlcmxlYmloIGRhaHVsdSd9XHJcbiAgICAgICAgICAgICAgb3B0aW9ucz17c3RhdHVzT3B0aW9ucy5tYXAoKHMpID0+ICh7IHZhbHVlOiBzLCBsYWJlbDogcyB9KSl9XHJcbiAgICAgICAgICAgICAgdmFsdWU9e3Rhc2tGb3JtLnN0YXR1c31cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVGFza0Zvcm1DaGFuZ2UoJ3N0YXR1cycpfVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXshdGFza0Zvcm0ucGhhc2V9XHJcbiAgICAgICAgICAgICAgZXJyb3I9e3Jvd0Vycm9ycy5zdGF0dXN9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZUFkZFRhc2t9PlxyXG4gICAgICAgICAgICAgICsgQWRkIFRhc2tcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC01IHB0LTUgcGItM1wiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtc2xhdGUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgRGFmdGFyIFRhc2sgKHt0YXNrcy5sZW5ndGh9KVxyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICB7Zm9ybUVycm9ycy50YXNrcyAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcmVkLTYwMFwiPntmb3JtRXJyb3JzLnRhc2tzfTwvcD59XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7dGFza3MubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcGItNVwiPlxyXG4gICAgICAgICAgICAgIDxFbXB0eVN0YXRlXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkJlbHVtIGFkYSB0YXNrXCJcclxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPVwiSXNpIGZvcm0gZGkgYXRhcyBsYWx1IGtsaWsg4oCcKyBBZGQgVGFza+KAnSB1bnR1ayBtZW5hbWJhaGthbiB0YXNrIGtlIGRhZnRhci5cIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLTAgcHktOFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8VGFibGU+XHJcbiAgICAgICAgICAgICAgPFRIZWFkPlxyXG4gICAgICAgICAgICAgICAgPFRyPlxyXG4gICAgICAgICAgICAgICAgICA8VGggY2xhc3NOYW1lPVwidy0xMlwiPk5vPC9UaD5cclxuICAgICAgICAgICAgICAgICAgPFRoPlRhc2s8L1RoPlxyXG4gICAgICAgICAgICAgICAgICA8VGg+Q2xpY2tVcCBJRDwvVGg+XHJcbiAgICAgICAgICAgICAgICAgIDxUaD5QaGFzZTwvVGg+XHJcbiAgICAgICAgICAgICAgICAgIDxUaD5TdGF0dXM8L1RoPlxyXG4gICAgICAgICAgICAgICAgICA8VGggY2xhc3NOYW1lPVwidy0yNCB0ZXh0LXJpZ2h0XCI+QWtzaTwvVGg+XHJcbiAgICAgICAgICAgICAgICA8L1RyPlxyXG4gICAgICAgICAgICAgIDwvVEhlYWQ+XHJcbiAgICAgICAgICAgICAgPFRCb2R5PlxyXG4gICAgICAgICAgICAgICAge3Rhc2tzLm1hcCgodGFzaywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFRyIGtleT17dGFzay51aWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZD57aW5kZXggKyAxfTwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS04MDBcIj57dGFzay50aXRsZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBocmVmPXt0YXNrLmNsaWNrdXBfdXJsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub3JlZmVycmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWJsdWUtNjAwIGhvdmVyOnVuZGVybGluZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0YXNrLmNsaWNrdXBfdXJsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvVGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGNvZGUgY2xhc3NOYW1lPVwicm91bmRlZCBiZy1zbGF0ZS0xMDAgcHgtMS41IHB5LTAuNSB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0YXNrLmNsaWNrdXBfdGFza19pZH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvY29kZT5cclxuICAgICAgICAgICAgICAgICAgICA8L1RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZD57dGFzay5waGFzZX08L1RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PXtzdGF0dXNCYWRnZVZhcmlhbnQodGFzay5zdGF0dXMpfT57dGFzay5zdGF0dXN9PC9CYWRnZT5cclxuICAgICAgICAgICAgICAgICAgICA8L1RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlbW92ZVRhc2sodGFzay51aWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBIYXB1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9UZD5cclxuICAgICAgICAgICAgICAgICAgPC9Ucj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvVEJvZHk+XHJcbiAgICAgICAgICAgIDwvVGFibGU+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgcHgtNSBweS00XCI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICB7dGFza3MubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgPyBgJHt0YXNrcy5sZW5ndGh9IHRhc2sgc2lhcCBkaXNpbXBhbiB1bnR1ayAke2RhdGUgfHwgJ3RhbmdnYWwgdGVycGlsaWgnfWBcclxuICAgICAgICAgICAgICAgIDogJ0JlbHVtIGFkYSB0YXNrIHlhbmcgZGl0YW1iYWhrYW4uJ31cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiBzaXplPVwibGdcIiBsb2FkaW5nPXtzYXZpbmd9IG9uQ2xpY2s9e2hhbmRsZVNhdmV9PlxyXG4gICAgICAgICAgICAgIFNhdmUgTFNQUFRcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgb3Blbj17ZW1wTW9kYWxPcGVufVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEVtcE1vZGFsT3BlbihmYWxzZSl9XHJcbiAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgZW1wVmlldyA9PT0gJ2xpc3QnXHJcbiAgICAgICAgICAgID8gJ0tlbG9sYSBLYXJ5YXdhbidcclxuICAgICAgICAgICAgOiBlbXBWaWV3ID09PSAnYWRkJ1xyXG4gICAgICAgICAgICAgID8gJ1RhbWJhaCBLYXJ5YXdhbidcclxuICAgICAgICAgICAgICA6ICdFZGl0IEthcnlhd2FuJ1xyXG4gICAgICAgIH1cclxuICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgIGZvb3Rlcj17XHJcbiAgICAgICAgICBlbXBWaWV3ID09PSAnbGlzdCcgPyAoXHJcbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgc2V0RW1wVmlldygnYWRkJyk7IHNldEVtcE5hbWUoJycpOyB9fT5cclxuICAgICAgICAgICAgICArIFRhbWJhaCBLYXJ5YXdhblxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAge2VtcFZpZXcgPT09ICdlZGl0JyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgbG9hZGluZz17ZW1wU2F2aW5nfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFbXBEZWxldGV9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEhhcHVzIEthcnlhd2FuXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RW1wVmlldygnbGlzdCcpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEJhdGFsXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBsb2FkaW5nPXtlbXBTYXZpbmd9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtlbXBWaWV3ID09PSAnYWRkJyA/IGhhbmRsZUVtcENyZWF0ZSA6IGhhbmRsZUVtcFVwZGF0ZX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBTaW1wYW5cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG4gICAgICA+XHJcbiAgICAgICAge2VtcFZpZXcgPT09ICdsaXN0JyA/IChcclxuICAgICAgICAgIDxUYWJsZT5cclxuICAgICAgICAgICAgPFRIZWFkPlxyXG4gICAgICAgICAgICAgIDxUcj5cclxuICAgICAgICAgICAgICAgIDxUaCBjbGFzc05hbWU9XCJ3LTEwXCI+IzwvVGg+XHJcbiAgICAgICAgICAgICAgICA8VGg+TmFtYTwvVGg+XHJcbiAgICAgICAgICAgICAgICA8VGggY2xhc3NOYW1lPVwidy0yMFwiPjwvVGg+XHJcbiAgICAgICAgICAgICAgPC9Ucj5cclxuICAgICAgICAgICAgPC9USGVhZD5cclxuICAgICAgICAgICAgPFRCb2R5PlxyXG4gICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXAsIGkpID0+IChcclxuICAgICAgICAgICAgICAgIDxUciBrZXk9e2VtcC5pZH0+XHJcbiAgICAgICAgICAgICAgICAgIDxUZD57aSArIDF9PC9UZD5cclxuICAgICAgICAgICAgICAgICAgPFRkPntlbXAubmFtZX08L1RkPlxyXG4gICAgICAgICAgICAgICAgICA8VGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRFbXBWaWV3KCdlZGl0Jyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVtcEVkaXRJZChlbXAuaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRFbXBOYW1lKGVtcC5uYW1lKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L1RkPlxyXG4gICAgICAgICAgICAgICAgPC9Ucj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9UQm9keT5cclxuICAgICAgICAgIDwvVGFibGU+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICBsYWJlbD1cIk5hbWEgS2FyeWF3YW5cIlxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1hc3Vra2FuIG5hbWFcIlxyXG4gICAgICAgICAgICB2YWx1ZT17ZW1wTmFtZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbXBOYW1lKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9Nb2RhbD5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiIvYXBwL3NyYy9wYWdlcy9TdWJtaXRQYWdlLmpzeCJ9