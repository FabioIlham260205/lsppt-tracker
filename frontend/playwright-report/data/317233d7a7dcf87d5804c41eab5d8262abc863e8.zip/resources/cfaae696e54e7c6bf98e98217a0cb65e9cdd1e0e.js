import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Button.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6eb1056b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/Button.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export default function Button({
  variant = "primary",
  size = "md",
  loading = false,
  disabled = false,
  className = "",
  children,
  ...props
}) {
  const VARIANTS = {
    primary: "bg-blue-600 text-white hover:bg-blue-700 focus-visible:outline-blue-600",
    secondary: "bg-slate-200 text-slate-800 hover:bg-slate-300 focus-visible:outline-slate-400",
    danger: "bg-red-600 text-white hover:bg-red-700 focus-visible:outline-red-600",
    outline: "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 focus-visible:outline-blue-600"
  };
  const SIZES = {
    sm: "px-3 py-1.5 text-xs",
    md: "px-4 py-2 text-sm",
    lg: "px-5 py-2.5 text-base"
  };
  const isDisabled = disabled || loading;
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      disabled: isDisabled,
      className: `inline-flex items-center justify-center gap-2 rounded-md font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 disabled:pointer-events-none disabled:opacity-60 ${VARIANTS[variant]} ${SIZES[size]} ${className}`,
      ...props,
      children: [
        loading && /* @__PURE__ */ jsxDEV("span", { className: "h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" }, void 0, false, {
          fileName: "/app/src/components/ui/Button.jsx",
          lineNumber: 52,
          columnNumber: 7
        }, this),
        children
      ]
    },
    void 0,
    true,
    {
      fileName: "/app/src/components/ui/Button.jsx",
      lineNumber: 46,
      columnNumber: 5
    },
    this
  );
}
_c = Button;
var _c;
$RefreshReg$(_c, "Button");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/Button.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/Button.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NROzs7Ozs7Ozs7Ozs7Ozs7O0FBaENSLHdCQUF3QkEsT0FBTztBQUFBLEVBQzdCQyxVQUFVO0FBQUEsRUFDVkMsT0FBTztBQUFBLEVBQ1BDLFVBQVU7QUFBQSxFQUNWQyxXQUFXO0FBQUEsRUFDWEMsWUFBWTtBQUFBLEVBQ1pDO0FBQUFBLEVBQ0EsR0FBR0M7QUFDTCxHQUFHO0FBQ0QsUUFBTUMsV0FBVztBQUFBLElBQ2ZDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsUUFBUTtBQUFBLElBQ1JDLFNBQ0U7QUFBQSxFQUNKO0FBRUEsUUFBTUMsUUFBUTtBQUFBLElBQ1pDLElBQUk7QUFBQSxJQUNKQyxJQUFJO0FBQUEsSUFDSkMsSUFBSTtBQUFBLEVBQ047QUFFQSxRQUFNQyxhQUFhYixZQUFZRDtBQUUvQixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxVQUFVYztBQUFBQSxNQUNWLFdBQVcsa01BQWtNVCxTQUFTUCxPQUFPLENBQUMsSUFBSVksTUFBTVgsSUFBSSxDQUFDLElBQUlHLFNBQVM7QUFBQSxNQUMxUCxHQUFJRTtBQUFBQSxNQUVISjtBQUFBQSxtQkFDQyx1QkFBQyxVQUFLLFdBQVUsb0ZBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0c7QUFBQSxRQUVqR0c7QUFBQUE7QUFBQUE7QUFBQUEsSUFSSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQTtBQUVKO0FBQUNZLEtBckN1QmxCO0FBQU0sSUFBQWtCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkJ1dHRvbiIsInZhcmlhbnQiLCJzaXplIiwibG9hZGluZyIsImRpc2FibGVkIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJwcm9wcyIsIlZBUklBTlRTIiwicHJpbWFyeSIsInNlY29uZGFyeSIsImRhbmdlciIsIm91dGxpbmUiLCJTSVpFUyIsInNtIiwibWQiLCJsZyIsImlzRGlzYWJsZWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCdXR0b24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEJ1dHRvbih7XG4gIHZhcmlhbnQgPSAncHJpbWFyeScsXG4gIHNpemUgPSAnbWQnLFxuICBsb2FkaW5nID0gZmFsc2UsXG4gIGRpc2FibGVkID0gZmFsc2UsXG4gIGNsYXNzTmFtZSA9ICcnLFxuICBjaGlsZHJlbixcbiAgLi4ucHJvcHNcbn0pIHtcbiAgY29uc3QgVkFSSUFOVFMgPSB7XG4gICAgcHJpbWFyeTogJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgaG92ZXI6YmctYmx1ZS03MDAgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLWJsdWUtNjAwJyxcbiAgICBzZWNvbmRhcnk6ICdiZy1zbGF0ZS0yMDAgdGV4dC1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtMzAwIGZvY3VzLXZpc2libGU6b3V0bGluZS1zbGF0ZS00MDAnLFxuICAgIGRhbmdlcjogJ2JnLXJlZC02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1yZWQtNzAwIGZvY3VzLXZpc2libGU6b3V0bGluZS1yZWQtNjAwJyxcbiAgICBvdXRsaW5lOlxuICAgICAgJ2JvcmRlciBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlIHRleHQtc2xhdGUtNzAwIGhvdmVyOmJnLXNsYXRlLTUwIGZvY3VzLXZpc2libGU6b3V0bGluZS1ibHVlLTYwMCcsXG4gIH07XG5cbiAgY29uc3QgU0laRVMgPSB7XG4gICAgc206ICdweC0zIHB5LTEuNSB0ZXh0LXhzJyxcbiAgICBtZDogJ3B4LTQgcHktMiB0ZXh0LXNtJyxcbiAgICBsZzogJ3B4LTUgcHktMi41IHRleHQtYmFzZScsXG4gIH07XG5cbiAgY29uc3QgaXNEaXNhYmxlZCA9IGRpc2FibGVkIHx8IGxvYWRpbmc7XG5cbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICBkaXNhYmxlZD17aXNEaXNhYmxlZH1cbiAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiByb3VuZGVkLW1kIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzIGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1vZmZzZXQtMiBkaXNhYmxlZDpwb2ludGVyLWV2ZW50cy1ub25lIGRpc2FibGVkOm9wYWNpdHktNjAgJHtWQVJJQU5UU1t2YXJpYW50XX0gJHtTSVpFU1tzaXplXX0gJHtjbGFzc05hbWV9YH1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7bG9hZGluZyAmJiAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImgtNCB3LTQgYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItY3VycmVudCBib3JkZXItdC10cmFuc3BhcmVudFwiIC8+XG4gICAgICApfVxuICAgICAge2NoaWxkcmVufVxuICAgIDwvYnV0dG9uPlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL3VpL0J1dHRvbi5qc3gifQ==