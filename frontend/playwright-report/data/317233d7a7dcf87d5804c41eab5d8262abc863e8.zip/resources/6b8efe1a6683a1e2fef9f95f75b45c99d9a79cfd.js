import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ComponentsPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6eb1056b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/pages/ComponentsPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6eb1056b"; const useState = __vite__cjsImport3_react["useState"];
import {
  Button,
  Input,
  Select,
  DatePicker,
  Modal,
  Table,
  THead,
  TBody,
  Tr,
  Th,
  Td,
  Badge,
  ToastProvider,
  useToast,
  Loading,
  EmptyState
} from "/src/components/ui/index.js";
const PHASES = ["TS", "QA"];
const STATUSES = {
  TS: ["Completed", "Documentation", "On Hold", "In Progress", "Plan"],
  QA: [
    "Completed",
    "Completed Testing",
    "Completed with Feedback",
    "Testing",
    "On Queue Testing",
    "Plan"
  ]
};
function Section({ title, children }) {
  return /* @__PURE__ */ jsxDEV("section", { className: "rounded-xl border border-slate-200 bg-white p-6 shadow-sm", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "mb-4 text-lg font-semibold text-slate-800", children: title }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 56,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "/app/src/pages/ComponentsPage.jsx",
    lineNumber: 55,
    columnNumber: 5
  }, this);
}
_c = Section;
function DemoContent() {
  _s();
  const { showToast } = useToast();
  const [modalOpen, setModalOpen] = useState(false);
  const [phase, setPhase] = useState("");
  const [form, setForm] = useState({ title: "", url: "", date: "" });
  const [saving, setSaving] = useState(false);
  const statusVariant = {
    Completed: "success",
    "In Progress": "info",
    Testing: "warning",
    "On Hold": "danger",
    Plan: "neutral"
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-slate-100 p-8", children: /* @__PURE__ */ jsxDEV("div", { className: "mx-auto max-w-5xl space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-slate-800", children: "UI Components" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 82,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500", children: "Live preview semua komponen untuk tim (Fabio & Bagas)." }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 83,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 81,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("a", { href: "/submit", className: "text-sm text-blue-600 hover:underline", children: "← Back to /submit" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 87,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 80,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Button", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(Button, { children: "Primary" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 94,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", children: "Secondary" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 95,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "danger", children: "Danger" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 96,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "outline", children: "Outline" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 97,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { size: "sm", children: "Small" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 98,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { size: "lg", children: "Large" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 99,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { loading: true, children: "Loading" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 100,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { disabled: true, children: "Disabled" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 101,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 93,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 92,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Input / Select / DatePicker", children: /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 sm:grid-cols-3", children: [
      /* @__PURE__ */ jsxDEV(
        Input,
        {
          label: "Task Title",
          placeholder: "e.g. Fix login bug",
          value: form.title,
          onChange: (e) => setForm({ ...form, title: e.target.value })
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 107,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Select,
        {
          label: "Phase",
          placeholder: "Select phase",
          options: PHASES,
          value: phase,
          onChange: (e) => setPhase(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 113,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        DatePicker,
        {
          label: "Date",
          value: form.date,
          onChange: (e) => setForm({ ...form, date: e.target.value })
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 120,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Input,
        {
          label: "ClickUp URL",
          type: "url",
          placeholder: "https://app.clickup.com/t/...",
          error: "Invalid URL format"
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 125,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 106,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 105,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Modal", children: [
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => setModalOpen(true), children: "Open Modal" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 135,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          open: modalOpen,
          onClose: () => setModalOpen(false),
          title: "Confirm Save LSPPT",
          footer: /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: () => setModalOpen(false), children: "Cancel" }, void 0, false, {
              fileName: "/app/src/pages/ComponentsPage.jsx",
              lineNumber: 142,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { onClick: () => setModalOpen(false), children: "Save" }, void 0, false, {
              fileName: "/app/src/pages/ComponentsPage.jsx",
              lineNumber: 145,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 141,
            columnNumber: 13
          }, this),
          children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-600", children: "Are you sure you want to save this LSPPT entry? This action cannot be undone. Press ESC or click the overlay to close." }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 149,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 136,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 134,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Table", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-lg border border-slate-200", children: /* @__PURE__ */ jsxDEV(Table, { children: [
      /* @__PURE__ */ jsxDEV(THead, { children: /* @__PURE__ */ jsxDEV(Tr, { children: [
        /* @__PURE__ */ jsxDEV(Th, { children: "Task" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 161,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(Th, { children: "Phase" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 162,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(Th, { children: "Status" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 163,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(Th, { children: "Date" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 164,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 160,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 159,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(TBody, { children: [
        { task: "Fix login redirect", phase: "TS", status: "Completed", date: "2026-08-20" },
        { task: "Write API docs", phase: "TS", status: "Documentation", date: "2026-08-21" },
        { task: "Regression testing", phase: "QA", status: "Testing", date: "2026-08-22" }
      ].map(
        (row) => /* @__PURE__ */ jsxDEV(Tr, { children: [
          /* @__PURE__ */ jsxDEV(Td, { className: "font-medium", children: row.task }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 174,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Td, { children: row.phase }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 175,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Td, { children: /* @__PURE__ */ jsxDEV(Badge, { variant: statusVariant[row.status] || "neutral", children: row.status }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 177,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 176,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Td, { children: row.date }, void 0, false, {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 179,
            columnNumber: 21
          }, this)
        ] }, row.task, true, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 173,
          columnNumber: 17
        }, this)
      ) }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 167,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 158,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 157,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 156,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Badge", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
      /* @__PURE__ */ jsxDEV(Badge, { variant: "success", children: "Completed" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 189,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Badge, { variant: "info", children: "In Progress" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 190,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Badge, { variant: "warning", children: "Testing" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 191,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Badge, { variant: "danger", children: "On Hold" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 192,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Badge, { variant: "neutral", children: "Plan" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 193,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 188,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 187,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Toast", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outline",
          onClick: () => showToast({ type: "success", title: "Success", message: "LSPPT saved successfully." }),
          children: "Success toast"
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 199,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outline",
          onClick: () => showToast({ type: "error", title: "Error", message: "Failed to save. Try again." }),
          children: "Error toast"
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 207,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outline",
          onClick: () => showToast({ type: "info", message: "Auto-dismiss in 4 seconds." }),
          children: "Info toast"
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 215,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 198,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 197,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Loading", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
      /* @__PURE__ */ jsxDEV(Loading, { size: "sm" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 226,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Loading, { size: "md" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 227,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Loading, { size: "lg" }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 228,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 225,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 224,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Empty State", children: /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        title: "No history found",
        description: "Try adjusting the employee filter or date range.",
        action: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", children: "Reset filter" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 236,
          columnNumber: 21
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 233,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 232,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Mini Form Demo (Button + Toast)", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex max-w-md items-end gap-3", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 space-y-3", children: [
        /* @__PURE__ */ jsxDEV(Input, { label: "Task Title", placeholder: "e.g. Fix login bug" }, void 0, false, {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 243,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            label: "Status (dynamic per Phase)",
            placeholder: phase ? "Select status" : "Pick a Phase first",
            options: phase ? STATUSES[phase] : [],
            disabled: !phase
          },
          void 0,
          false,
          {
            fileName: "/app/src/pages/ComponentsPage.jsx",
            lineNumber: 244,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 242,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 241,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex gap-2", children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          loading: saving,
          onClick: () => {
            setSaving(true);
            setTimeout(() => {
              setSaving(false);
              showToast({ type: "success", message: "Form submitted!" });
            }, 1200);
          },
          children: "Submit"
        },
        void 0,
        false,
        {
          fileName: "/app/src/pages/ComponentsPage.jsx",
          lineNumber: 253,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "/app/src/pages/ComponentsPage.jsx",
        lineNumber: 252,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/pages/ComponentsPage.jsx",
      lineNumber: 240,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/pages/ComponentsPage.jsx",
    lineNumber: 79,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/app/src/pages/ComponentsPage.jsx",
    lineNumber: 78,
    columnNumber: 5
  }, this);
}
_s(DemoContent, "4cmHjlGK970TmV425qDyIWkO+EE=", false, function() {
  return [useToast];
});
_c2 = DemoContent;
export default function ComponentsPage() {
  return /* @__PURE__ */ jsxDEV(ToastProvider, { children: /* @__PURE__ */ jsxDEV(DemoContent, {}, void 0, false, {
    fileName: "/app/src/pages/ComponentsPage.jsx",
    lineNumber: 275,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/app/src/pages/ComponentsPage.jsx",
    lineNumber: 274,
    columnNumber: 5
  }, this);
}
_c3 = ComponentsPage;
var _c, _c2, _c3;
$RefreshReg$(_c, "Section");
$RefreshReg$(_c2, "DemoContent");
$RefreshReg$(_c3, "ComponentsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/pages/ComponentsPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/pages/ComponentsPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NNLFNBcUZRLFVBckZSOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBDTixTQUFTQSxnQkFBZ0I7QUFDekI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBRVAsTUFBTUMsU0FBUyxDQUFDLE1BQU0sSUFBSTtBQUMxQixNQUFNQyxXQUFXO0FBQUEsRUFDZkMsSUFBSSxDQUFDLGFBQWEsaUJBQWlCLFdBQVcsZUFBZSxNQUFNO0FBQUEsRUFDbkVDLElBQUk7QUFBQSxJQUNGO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUFNO0FBRVY7QUFFQSxTQUFTQyxRQUFRLEVBQUVDLE9BQU9DLFNBQVMsR0FBRztBQUNwQyxTQUNFLHVCQUFDLGFBQVEsV0FBVSw2REFDakI7QUFBQSwyQkFBQyxRQUFHLFdBQVUsNkNBQTZDRCxtQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRTtBQUFBLElBQ2hFQztBQUFBQSxPQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNDLEtBUFFIO0FBU1QsU0FBU0ksY0FBYztBQUFBQyxLQUFBO0FBQ3JCLFFBQU0sRUFBRUMsVUFBVSxJQUFJYixTQUFTO0FBQy9CLFFBQU0sQ0FBQ2MsV0FBV0MsWUFBWSxJQUFJN0IsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzhCLE9BQU9DLFFBQVEsSUFBSS9CLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNnQyxNQUFNQyxPQUFPLElBQUlqQyxTQUFTLEVBQUVzQixPQUFPLElBQUlZLEtBQUssSUFBSUMsTUFBTSxHQUFHLENBQUM7QUFDakUsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlyQyxTQUFTLEtBQUs7QUFFMUMsUUFBTXNDLGdCQUFnQjtBQUFBLElBQ3BCQyxXQUFXO0FBQUEsSUFDWCxlQUFlO0FBQUEsSUFDZkMsU0FBUztBQUFBLElBQ1QsV0FBVztBQUFBLElBQ1hDLE1BQU07QUFBQSxFQUNSO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUNBQ2IsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsNkJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxRQUMvRCx1QkFBQyxPQUFFLFdBQVUsMEJBQXdCLHNFQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxNQUFLLFdBQVUsV0FBVSx5Q0FBdUMsaUNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQSx1QkFBQyxXQUFRLE9BQU0sVUFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSw2QkFBQyxVQUFPLHVCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsVUFBTyxTQUFRLGFBQVkseUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxNQUNyQyx1QkFBQyxVQUFPLFNBQVEsVUFBUyxzQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLE1BQy9CLHVCQUFDLFVBQU8sU0FBUSxXQUFVLHVCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsVUFBTyxNQUFLLE1BQUsscUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUI7QUFBQSxNQUN2Qix1QkFBQyxVQUFPLE1BQUssTUFBSyxxQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QjtBQUFBLE1BQ3ZCLHVCQUFDLFVBQU8sU0FBTyxNQUFDLHVCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVCO0FBQUEsTUFDdkIsdUJBQUMsVUFBTyxVQUFRLE1BQUMsd0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxTQVIzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUVBLHVCQUFDLFdBQVEsT0FBTSwrQkFDYixpQ0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sYUFBWTtBQUFBLFVBQ1osT0FBT1QsS0FBS1Y7QUFBQUEsVUFDWixVQUFVLENBQUNvQixNQUFNVCxRQUFRLEVBQUUsR0FBR0QsTUFBTVYsT0FBT29CLEVBQUVDLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsUUFKN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSStEO0FBQUEsTUFFL0Q7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLGFBQVk7QUFBQSxVQUNaLFNBQVMzQjtBQUFBQSxVQUNULE9BQU9hO0FBQUFBLFVBQ1AsVUFBVSxDQUFDWSxNQUFNWCxTQUFTVyxFQUFFQyxPQUFPQyxLQUFLO0FBQUE7QUFBQSxRQUwxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLNEM7QUFBQSxNQUU1QztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sT0FBT1osS0FBS0c7QUFBQUEsVUFDWixVQUFVLENBQUNPLE1BQU1ULFFBQVEsRUFBRSxHQUFHRCxNQUFNRyxNQUFNTyxFQUFFQyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLFFBSDVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUc4RDtBQUFBLE1BRTlEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixNQUFLO0FBQUEsVUFDTCxhQUFZO0FBQUEsVUFDWixPQUFNO0FBQUE7QUFBQSxRQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUk0QjtBQUFBLFNBdkI5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBLEtBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxJQUVBLHVCQUFDLFdBQVEsT0FBTSxTQUNiO0FBQUEsNkJBQUMsVUFBTyxTQUFTLE1BQU1mLGFBQWEsSUFBSSxHQUFHLDBCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFEO0FBQUEsTUFDckQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1EO0FBQUFBLFVBQ04sU0FBUyxNQUFNQyxhQUFhLEtBQUs7QUFBQSxVQUNqQyxPQUFNO0FBQUEsVUFDTixRQUNFLG1DQUNFO0FBQUEsbUNBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUyxNQUFNQSxhQUFhLEtBQUssR0FBRSxzQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBTyxTQUFTLE1BQU1BLGFBQWEsS0FBSyxHQUFHLG9CQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBLGVBSmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUdGLGlDQUFDLE9BQUUsV0FBVSwwQkFBd0Isc0lBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQTtBQUFBLFFBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWlCQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUVBLHVCQUFDLFdBQVEsT0FBTSxTQUNiLGlDQUFDLFNBQUksV0FBVSxzREFDYixpQ0FBQyxTQUNDO0FBQUEsNkJBQUMsU0FDQyxpQ0FBQyxNQUNDO0FBQUEsK0JBQUMsTUFBRyxvQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVE7QUFBQSxRQUNSLHVCQUFDLE1BQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTO0FBQUEsUUFDVCx1QkFBQyxNQUFHLHNCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVTtBQUFBLFFBQ1YsdUJBQUMsTUFBRyxvQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVE7QUFBQSxXQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FDRTtBQUFBLFFBQ0MsRUFBRWdCLE1BQU0sc0JBQXNCZixPQUFPLE1BQU1nQixRQUFRLGFBQWFYLE1BQU0sYUFBYTtBQUFBLFFBQ25GLEVBQUVVLE1BQU0sa0JBQWtCZixPQUFPLE1BQU1nQixRQUFRLGlCQUFpQlgsTUFBTSxhQUFhO0FBQUEsUUFDbkYsRUFBRVUsTUFBTSxzQkFBc0JmLE9BQU8sTUFBTWdCLFFBQVEsV0FBV1gsTUFBTSxhQUFhO0FBQUEsTUFBQyxFQUNsRlk7QUFBQUEsUUFBSSxDQUFDQyxRQUNMLHVCQUFDLE1BQ0M7QUFBQSxpQ0FBQyxNQUFHLFdBQVUsZUFBZUEsY0FBSUgsUUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxVQUN0Qyx1QkFBQyxNQUFJRyxjQUFJbEIsU0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlO0FBQUEsVUFDZix1QkFBQyxNQUNDLGlDQUFDLFNBQU0sU0FBU1EsY0FBY1UsSUFBSUYsTUFBTSxLQUFLLFdBQVlFLGNBQUlGLFVBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FLEtBRHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE1BQUlFLGNBQUliLFFBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYztBQUFBLGFBTlBhLElBQUlILE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsTUFDRCxLQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLFNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkEsS0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkJBO0FBQUEsSUFFQSx1QkFBQyxXQUFRLE9BQU0sU0FDYixpQ0FBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSw2QkFBQyxTQUFNLFNBQVEsV0FBVSx5QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQ2xDLHVCQUFDLFNBQU0sU0FBUSxRQUFPLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsU0FBTSxTQUFRLFdBQVUsdUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0M7QUFBQSxNQUNoQyx1QkFBQyxTQUFNLFNBQVEsVUFBUyx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLE1BQy9CLHVCQUFDLFNBQU0sU0FBUSxXQUFVLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUEsU0FML0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFFQSx1QkFBQyxXQUFRLE9BQU0sU0FDYixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixTQUFTLE1BQ1BsQixVQUFVLEVBQUVzQixNQUFNLFdBQVczQixPQUFPLFdBQVc0QixTQUFTLDRCQUE0QixDQUFDO0FBQUEsVUFDdEY7QUFBQTtBQUFBLFFBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixTQUFTLE1BQ1B2QixVQUFVLEVBQUVzQixNQUFNLFNBQVMzQixPQUFPLFNBQVM0QixTQUFTLDZCQUE2QixDQUFDO0FBQUEsVUFDbkY7QUFBQTtBQUFBLFFBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixTQUFTLE1BQU12QixVQUFVLEVBQUVzQixNQUFNLFFBQVFDLFNBQVMsNkJBQTZCLENBQUM7QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLFNBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkEsS0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBRUEsdUJBQUMsV0FBUSxPQUFNLFdBQ2IsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkJBQUMsV0FBUSxNQUFLLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQjtBQUFBLE1BQ2xCLHVCQUFDLFdBQVEsTUFBSyxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0I7QUFBQSxNQUNsQix1QkFBQyxXQUFRLE1BQUssUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCO0FBQUEsU0FIcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQSx1QkFBQyxXQUFRLE9BQU0sZUFDYjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sYUFBWTtBQUFBLFFBQ1osUUFBUSx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFdBQVUsNEJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQTtBQUFBLE1BSDFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUdvRSxLQUp0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUVBLHVCQUFDLFdBQVEsT0FBTSxtQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQ0FDYixpQ0FBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSwrQkFBQyxTQUFNLE9BQU0sY0FBYSxhQUFZLHdCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLGFBQWFwQixRQUFRLGtCQUFrQjtBQUFBLFlBQ3ZDLFNBQVNBLFFBQVFaLFNBQVNZLEtBQUssSUFBSTtBQUFBLFlBQ25DLFVBQVUsQ0FBQ0E7QUFBQUE7QUFBQUEsVUFKYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJbUI7QUFBQSxXQU5yQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBU007QUFBQUEsVUFDVCxTQUFTLE1BQU07QUFDYkMsc0JBQVUsSUFBSTtBQUNkYyx1QkFBVyxNQUFNO0FBQ2ZkLHdCQUFVLEtBQUs7QUFDZlYsd0JBQVUsRUFBRXNCLE1BQU0sV0FBV0MsU0FBUyxrQkFBa0IsQ0FBQztBQUFBLFlBQzNELEdBQUcsSUFBSTtBQUFBLFVBQ1Q7QUFBQSxVQUFFO0FBQUE7QUFBQSxRQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLE9BM0xGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0TEEsS0E3TEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThMQTtBQUVKO0FBQUN4QixHQWhOUUQsYUFBVztBQUFBLFVBQ0lYLFFBQVE7QUFBQTtBQUFBLE1BRHZCVztBQWtOVCx3QkFBd0IyQixpQkFBaUI7QUFDdkMsU0FDRSx1QkFBQyxpQkFDQyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVksS0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDQyxNQU51QkQ7QUFBYyxJQUFBNUIsSUFBQThCLEtBQUFEO0FBQUEsYUFBQTdCLElBQUE7QUFBQSxhQUFBOEIsS0FBQTtBQUFBLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkJ1dHRvbiIsIklucHV0IiwiU2VsZWN0IiwiRGF0ZVBpY2tlciIsIk1vZGFsIiwiVGFibGUiLCJUSGVhZCIsIlRCb2R5IiwiVHIiLCJUaCIsIlRkIiwiQmFkZ2UiLCJUb2FzdFByb3ZpZGVyIiwidXNlVG9hc3QiLCJMb2FkaW5nIiwiRW1wdHlTdGF0ZSIsIlBIQVNFUyIsIlNUQVRVU0VTIiwiVFMiLCJRQSIsIlNlY3Rpb24iLCJ0aXRsZSIsImNoaWxkcmVuIiwiX2MiLCJEZW1vQ29udGVudCIsIl9zIiwic2hvd1RvYXN0IiwibW9kYWxPcGVuIiwic2V0TW9kYWxPcGVuIiwicGhhc2UiLCJzZXRQaGFzZSIsImZvcm0iLCJzZXRGb3JtIiwidXJsIiwiZGF0ZSIsInNhdmluZyIsInNldFNhdmluZyIsInN0YXR1c1ZhcmlhbnQiLCJDb21wbGV0ZWQiLCJUZXN0aW5nIiwiUGxhbiIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsInRhc2siLCJzdGF0dXMiLCJtYXAiLCJyb3ciLCJ0eXBlIiwibWVzc2FnZSIsInNldFRpbWVvdXQiLCJDb21wb25lbnRzUGFnZSIsIl9jMyIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb21wb25lbnRzUGFnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQge1xuICBCdXR0b24sXG4gIElucHV0LFxuICBTZWxlY3QsXG4gIERhdGVQaWNrZXIsXG4gIE1vZGFsLFxuICBUYWJsZSxcbiAgVEhlYWQsXG4gIFRCb2R5LFxuICBUcixcbiAgVGgsXG4gIFRkLFxuICBCYWRnZSxcbiAgVG9hc3RQcm92aWRlcixcbiAgdXNlVG9hc3QsXG4gIExvYWRpbmcsXG4gIEVtcHR5U3RhdGUsXG59IGZyb20gJy4uL2NvbXBvbmVudHMvdWknO1xuXG5jb25zdCBQSEFTRVMgPSBbJ1RTJywgJ1FBJ107XG5jb25zdCBTVEFUVVNFUyA9IHtcbiAgVFM6IFsnQ29tcGxldGVkJywgJ0RvY3VtZW50YXRpb24nLCAnT24gSG9sZCcsICdJbiBQcm9ncmVzcycsICdQbGFuJ10sXG4gIFFBOiBbXG4gICAgJ0NvbXBsZXRlZCcsXG4gICAgJ0NvbXBsZXRlZCBUZXN0aW5nJyxcbiAgICAnQ29tcGxldGVkIHdpdGggRmVlZGJhY2snLFxuICAgICdUZXN0aW5nJyxcbiAgICAnT24gUXVldWUgVGVzdGluZycsXG4gICAgJ1BsYW4nLFxuICBdLFxufTtcblxuZnVuY3Rpb24gU2VjdGlvbih7IHRpdGxlLCBjaGlsZHJlbiB9KSB7XG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSBwLTYgc2hhZG93LXNtXCI+XG4gICAgICA8aDIgY2xhc3NOYW1lPVwibWItNCB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDBcIj57dGl0bGV9PC9oMj5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbmZ1bmN0aW9uIERlbW9Db250ZW50KCkge1xuICBjb25zdCB7IHNob3dUb2FzdCB9ID0gdXNlVG9hc3QoKTtcbiAgY29uc3QgW21vZGFsT3Blbiwgc2V0TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3BoYXNlLCBzZXRQaGFzZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlKHsgdGl0bGU6ICcnLCB1cmw6ICcnLCBkYXRlOiAnJyB9KTtcbiAgY29uc3QgW3NhdmluZywgc2V0U2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBzdGF0dXNWYXJpYW50ID0ge1xuICAgIENvbXBsZXRlZDogJ3N1Y2Nlc3MnLFxuICAgICdJbiBQcm9ncmVzcyc6ICdpbmZvJyxcbiAgICBUZXN0aW5nOiAnd2FybmluZycsXG4gICAgJ09uIEhvbGQnOiAnZGFuZ2VyJyxcbiAgICBQbGFuOiAnbmV1dHJhbCcsXG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS0xMDAgcC04XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctNXhsIHNwYWNlLXktNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+VUkgQ29tcG9uZW50czwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgIExpdmUgcHJldmlldyBzZW11YSBrb21wb25lbiB1bnR1ayB0aW0gKEZhYmlvICZhbXA7IEJhZ2FzKS5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YSBocmVmPVwiL3N1Ym1pdFwiIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ibHVlLTYwMCBob3Zlcjp1bmRlcmxpbmVcIj5cbiAgICAgICAgICAgIOKGkCBCYWNrIHRvIC9zdWJtaXRcbiAgICAgICAgICA8L2E+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxTZWN0aW9uIHRpdGxlPVwiQnV0dG9uXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxCdXR0b24+UHJpbWFyeTwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCI+U2Vjb25kYXJ5PC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJkYW5nZXJcIj5EYW5nZXI8L0J1dHRvbj5cbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIj5PdXRsaW5lPC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiPlNtYWxsPC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJsZ1wiPkxhcmdlPC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uIGxvYWRpbmc+TG9hZGluZzwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD5EaXNhYmxlZDwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJJbnB1dCAvIFNlbGVjdCAvIERhdGVQaWNrZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTQgc206Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICBsYWJlbD1cIlRhc2sgVGl0bGVcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gRml4IGxvZ2luIGJ1Z1wiXG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnRpdGxlfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCB0aXRsZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICBsYWJlbD1cIlBoYXNlXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgcGhhc2VcIlxuICAgICAgICAgICAgICBvcHRpb25zPXtQSEFTRVN9XG4gICAgICAgICAgICAgIHZhbHVlPXtwaGFzZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQaGFzZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPERhdGVQaWNrZXJcbiAgICAgICAgICAgICAgbGFiZWw9XCJEYXRlXCJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uZGF0ZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgZGF0ZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgIGxhYmVsPVwiQ2xpY2tVcCBVUkxcIlxuICAgICAgICAgICAgICB0eXBlPVwidXJsXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL2FwcC5jbGlja3VwLmNvbS90Ly4uLlwiXG4gICAgICAgICAgICAgIGVycm9yPVwiSW52YWxpZCBVUkwgZm9ybWF0XCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIk1vZGFsXCI+XG4gICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRNb2RhbE9wZW4odHJ1ZSl9Pk9wZW4gTW9kYWw8L0J1dHRvbj5cbiAgICAgICAgICA8TW9kYWxcbiAgICAgICAgICAgIG9wZW49e21vZGFsT3Blbn1cbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldE1vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICB0aXRsZT1cIkNvbmZpcm0gU2F2ZSBMU1BQVFwiXG4gICAgICAgICAgICBmb290ZXI9e1xuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXsoKSA9PiBzZXRNb2RhbE9wZW4oZmFsc2UpfT5cbiAgICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0TW9kYWxPcGVuKGZhbHNlKX0+U2F2ZTwvQnV0dG9uPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgICAgIEFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBzYXZlIHRoaXMgTFNQUFQgZW50cnk/IFRoaXMgYWN0aW9uIGNhbm5vdCBiZSB1bmRvbmUuXG4gICAgICAgICAgICAgIFByZXNzIEVTQyBvciBjbGljayB0aGUgb3ZlcmxheSB0byBjbG9zZS5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L01vZGFsPlxuICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJUYWJsZVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgIDxUYWJsZT5cbiAgICAgICAgICAgICAgPFRIZWFkPlxuICAgICAgICAgICAgICAgIDxUcj5cbiAgICAgICAgICAgICAgICAgIDxUaD5UYXNrPC9UaD5cbiAgICAgICAgICAgICAgICAgIDxUaD5QaGFzZTwvVGg+XG4gICAgICAgICAgICAgICAgICA8VGg+U3RhdHVzPC9UaD5cbiAgICAgICAgICAgICAgICAgIDxUaD5EYXRlPC9UaD5cbiAgICAgICAgICAgICAgICA8L1RyPlxuICAgICAgICAgICAgICA8L1RIZWFkPlxuICAgICAgICAgICAgICA8VEJvZHk+XG4gICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgIHsgdGFzazogJ0ZpeCBsb2dpbiByZWRpcmVjdCcsIHBoYXNlOiAnVFMnLCBzdGF0dXM6ICdDb21wbGV0ZWQnLCBkYXRlOiAnMjAyNi0wOC0yMCcgfSxcbiAgICAgICAgICAgICAgICAgIHsgdGFzazogJ1dyaXRlIEFQSSBkb2NzJywgcGhhc2U6ICdUUycsIHN0YXR1czogJ0RvY3VtZW50YXRpb24nLCBkYXRlOiAnMjAyNi0wOC0yMScgfSxcbiAgICAgICAgICAgICAgICAgIHsgdGFzazogJ1JlZ3Jlc3Npb24gdGVzdGluZycsIHBoYXNlOiAnUUEnLCBzdGF0dXM6ICdUZXN0aW5nJywgZGF0ZTogJzIwMjYtMDgtMjInIH0sXG4gICAgICAgICAgICAgICAgXS5tYXAoKHJvdykgPT4gKFxuICAgICAgICAgICAgICAgICAgPFRyIGtleT17cm93LnRhc2t9PlxuICAgICAgICAgICAgICAgICAgICA8VGQgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57cm93LnRhc2t9PC9UZD5cbiAgICAgICAgICAgICAgICAgICAgPFRkPntyb3cucGhhc2V9PC9UZD5cbiAgICAgICAgICAgICAgICAgICAgPFRkPlxuICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PXtzdGF0dXNWYXJpYW50W3Jvdy5zdGF0dXNdIHx8ICduZXV0cmFsJ30+e3Jvdy5zdGF0dXN9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgPC9UZD5cbiAgICAgICAgICAgICAgICAgICAgPFRkPntyb3cuZGF0ZX08L1RkPlxuICAgICAgICAgICAgICAgICAgPC9Ucj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9UQm9keT5cbiAgICAgICAgICAgIDwvVGFibGU+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIkJhZGdlXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJzdWNjZXNzXCI+Q29tcGxldGVkPC9CYWRnZT5cbiAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwiaW5mb1wiPkluIFByb2dyZXNzPC9CYWRnZT5cbiAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwid2FybmluZ1wiPlRlc3Rpbmc8L0JhZGdlPlxuICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJkYW5nZXJcIj5PbiBIb2xkPC9CYWRnZT5cbiAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwibmV1dHJhbFwiPlBsYW48L0JhZGdlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJUb2FzdFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgc2hvd1RvYXN0KHsgdHlwZTogJ3N1Y2Nlc3MnLCB0aXRsZTogJ1N1Y2Nlc3MnLCBtZXNzYWdlOiAnTFNQUFQgc2F2ZWQgc3VjY2Vzc2Z1bGx5LicgfSlcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBTdWNjZXNzIHRvYXN0XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxuICAgICAgICAgICAgICAgIHNob3dUb2FzdCh7IHR5cGU6ICdlcnJvcicsIHRpdGxlOiAnRXJyb3InLCBtZXNzYWdlOiAnRmFpbGVkIHRvIHNhdmUuIFRyeSBhZ2Fpbi4nIH0pXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgRXJyb3IgdG9hc3RcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNob3dUb2FzdCh7IHR5cGU6ICdpbmZvJywgbWVzc2FnZTogJ0F1dG8tZGlzbWlzcyBpbiA0IHNlY29uZHMuJyB9KX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgSW5mbyB0b2FzdFxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIkxvYWRpbmdcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XG4gICAgICAgICAgICA8TG9hZGluZyBzaXplPVwic21cIiAvPlxuICAgICAgICAgICAgPExvYWRpbmcgc2l6ZT1cIm1kXCIgLz5cbiAgICAgICAgICAgIDxMb2FkaW5nIHNpemU9XCJsZ1wiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIkVtcHR5IFN0YXRlXCI+XG4gICAgICAgICAgPEVtcHR5U3RhdGVcbiAgICAgICAgICAgIHRpdGxlPVwiTm8gaGlzdG9yeSBmb3VuZFwiXG4gICAgICAgICAgICBkZXNjcmlwdGlvbj1cIlRyeSBhZGp1c3RpbmcgdGhlIGVtcGxveWVlIGZpbHRlciBvciBkYXRlIHJhbmdlLlwiXG4gICAgICAgICAgICBhY3Rpb249ezxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cIm91dGxpbmVcIj5SZXNldCBmaWx0ZXI8L0J1dHRvbj59XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9TZWN0aW9uPlxuXG4gICAgICAgIDxTZWN0aW9uIHRpdGxlPVwiTWluaSBGb3JtIERlbW8gKEJ1dHRvbiArIFRvYXN0KVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYXgtdy1tZCBpdGVtcy1lbmQgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8SW5wdXQgbGFiZWw9XCJUYXNrIFRpdGxlXCIgcGxhY2Vob2xkZXI9XCJlLmcuIEZpeCBsb2dpbiBidWdcIiAvPlxuICAgICAgICAgICAgICA8U2VsZWN0XG4gICAgICAgICAgICAgICAgbGFiZWw9XCJTdGF0dXMgKGR5bmFtaWMgcGVyIFBoYXNlKVwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3BoYXNlID8gJ1NlbGVjdCBzdGF0dXMnIDogJ1BpY2sgYSBQaGFzZSBmaXJzdCd9XG4gICAgICAgICAgICAgICAgb3B0aW9ucz17cGhhc2UgPyBTVEFUVVNFU1twaGFzZV0gOiBbXX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXBoYXNlfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgbG9hZGluZz17c2F2aW5nfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0U2F2aW5nKHRydWUpO1xuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0U2F2aW5nKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgIHNob3dUb2FzdCh7IHR5cGU6ICdzdWNjZXNzJywgbWVzc2FnZTogJ0Zvcm0gc3VibWl0dGVkIScgfSk7XG4gICAgICAgICAgICAgICAgfSwgMTIwMCk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFN1Ym1pdFxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvU2VjdGlvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb21wb25lbnRzUGFnZSgpIHtcbiAgcmV0dXJuIChcbiAgICA8VG9hc3RQcm92aWRlcj5cbiAgICAgIDxEZW1vQ29udGVudCAvPlxuICAgIDwvVG9hc3RQcm92aWRlcj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL2FwcC9zcmMvcGFnZXMvQ29tcG9uZW50c1BhZ2UuanN4In0=