import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Toast.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6eb1056b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/Toast.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6eb1056b"; const createContext = __vite__cjsImport3_react["createContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
const ToastContext = createContext(null);
const TYPES = {
  success: {
    icon: /* @__PURE__ */ jsxDEV("svg", { className: "h-5 w-5 text-green-500", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
      fileName: "/app/src/components/ui/Toast.jsx",
      lineNumber: 28,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/src/components/ui/Toast.jsx",
      lineNumber: 27,
      columnNumber: 5
    }, this),
    accent: "border-l-green-500"
  },
  error: {
    icon: /* @__PURE__ */ jsxDEV("svg", { className: "h-5 w-5 text-red-500", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M12 8v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" }, void 0, false, {
      fileName: "/app/src/components/ui/Toast.jsx",
      lineNumber: 36,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/src/components/ui/Toast.jsx",
      lineNumber: 35,
      columnNumber: 5
    }, this),
    accent: "border-l-red-500"
  },
  info: {
    icon: /* @__PURE__ */ jsxDEV("svg", { className: "h-5 w-5 text-blue-500", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
      fileName: "/app/src/components/ui/Toast.jsx",
      lineNumber: 44,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/src/components/ui/Toast.jsx",
      lineNumber: 43,
      columnNumber: 5
    }, this),
    accent: "border-l-blue-500"
  }
};
function ToastItem({ toast, onDismiss }) {
  _s();
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const raf = requestAnimationFrame(() => setVisible(true));
    return () => cancelAnimationFrame(raf);
  }, []);
  const meta = TYPES[toast.type] || TYPES.info;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      role: "alert",
      className: `flex w-80 items-start gap-3 rounded-md border border-slate-200 border-l-4 bg-white px-4 py-3 shadow-lg transition-all duration-200 ${meta.accent} ${visible ? "translate-y-0 opacity-100" : "translate-y-2 opacity-0"}`,
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "mt-0.5 shrink-0", children: meta.icon }, void 0, false, {
          fileName: "/app/src/components/ui/Toast.jsx",
          lineNumber: 68,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
          toast.title && /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-slate-800", children: toast.title }, void 0, false, {
            fileName: "/app/src/components/ui/Toast.jsx",
            lineNumber: 70,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-600", children: toast.message }, void 0, false, {
            fileName: "/app/src/components/ui/Toast.jsx",
            lineNumber: 71,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/components/ui/Toast.jsx",
          lineNumber: 69,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => onDismiss(toast.id),
            "aria-label": "Dismiss",
            className: "shrink-0 rounded p-0.5 text-slate-400 hover:text-slate-600",
            children: /* @__PURE__ */ jsxDEV("svg", { className: "h-4 w-4", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M6 18L18 6M6 6l12 12" }, void 0, false, {
              fileName: "/app/src/components/ui/Toast.jsx",
              lineNumber: 80,
              columnNumber: 11
            }, this) }, void 0, false, {
              fileName: "/app/src/components/ui/Toast.jsx",
              lineNumber: 79,
              columnNumber: 9
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/ui/Toast.jsx",
            lineNumber: 73,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/app/src/components/ui/Toast.jsx",
      lineNumber: 62,
      columnNumber: 5
    },
    this
  );
}
_s(ToastItem, "cz/DzCD06IMMsoBJ0A1IgCy1P5M=");
_c = ToastItem;
export function ToastProvider({ children }) {
  _s2();
  const [toasts, setToasts] = useState([]);
  const dismiss = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);
  const showToast = useCallback(
    ({ type = "info", title, message, duration = 4e3 }) => {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      setToasts((prev) => [...prev, { id, type, title, message }]);
      setTimeout(() => dismiss(id), duration);
    },
    [dismiss]
  );
  const value = useMemo(() => ({ showToast }), [showToast]);
  return /* @__PURE__ */ jsxDEV(ToastContext.Provider, { value, children: [
    children,
    /* @__PURE__ */ jsxDEV("div", { className: "fixed bottom-4 right-4 z-[100] flex flex-col gap-2", children: toasts.map(
      (toast) => /* @__PURE__ */ jsxDEV(ToastItem, { toast, onDismiss: dismiss }, toast.id, false, {
        fileName: "/app/src/components/ui/Toast.jsx",
        lineNumber: 110,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/app/src/components/ui/Toast.jsx",
      lineNumber: 108,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/ui/Toast.jsx",
    lineNumber: 106,
    columnNumber: 5
  }, this);
}
_s2(ToastProvider, "sl2bKfvbH+E4eAXyJVjHbjPQlJY=");
_c2 = ToastProvider;
export function useToast() {
  _s3();
  const ctx = useContext(ToastContext);
  if (!ctx) {
    throw new Error("useToast must be used within a ToastProvider");
  }
  return ctx;
}
_s3(useToast, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c, _c2;
$RefreshReg$(_c, "ToastItem");
$RefreshReg$(_c2, "ToastProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/Toast.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/Toast.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBUlIsU0FBU0EsZUFBZUMsYUFBYUMsWUFBWUMsV0FBV0MsU0FBU0MsZ0JBQWdCO0FBRXJGLE1BQU1DLGVBQWVOLGNBQWMsSUFBSTtBQUV2QyxNQUFNTyxRQUFRO0FBQUEsRUFDWkMsU0FBUztBQUFBLElBQ1BDLE1BQ0UsdUJBQUMsU0FBSSxXQUFVLDBCQUF5QixNQUFLLFFBQU8sU0FBUSxhQUFZLFFBQU8sZ0JBQWUsYUFBWSxLQUN4RyxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLEdBQUUsbURBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0csS0FEdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFRkMsUUFBUTtBQUFBLEVBQ1Y7QUFBQSxFQUNBQyxPQUFPO0FBQUEsSUFDTEYsTUFDRSx1QkFBQyxTQUFJLFdBQVUsd0JBQXVCLE1BQUssUUFBTyxTQUFRLGFBQVksUUFBTyxnQkFBZSxhQUFZLEtBQ3RHLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsR0FBRSx3R0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5SixLQUQzSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVGQyxRQUFRO0FBQUEsRUFDVjtBQUFBLEVBQ0FFLE1BQU07QUFBQSxJQUNKSCxNQUNFLHVCQUFDLFNBQUksV0FBVSx5QkFBd0IsTUFBSyxRQUFPLFNBQVEsYUFBWSxRQUFPLGdCQUFlLGFBQVksS0FDdkcsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxHQUFFLCtEQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdILEtBRGxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUZDLFFBQVE7QUFBQSxFQUNWO0FBQ0Y7QUFFQSxTQUFTRyxVQUFVLEVBQUVDLE9BQU9DLFVBQVUsR0FBRztBQUFBQyxLQUFBO0FBQ3ZDLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJYixTQUFTLEtBQUs7QUFFNUNGLFlBQVUsTUFBTTtBQUNkLFVBQU1nQixNQUFNQyxzQkFBc0IsTUFBTUYsV0FBVyxJQUFJLENBQUM7QUFDeEQsV0FBTyxNQUFNRyxxQkFBcUJGLEdBQUc7QUFBQSxFQUN2QyxHQUFHLEVBQUU7QUFFTCxRQUFNRyxPQUFPZixNQUFNTyxNQUFNUyxJQUFJLEtBQUtoQixNQUFNSztBQUV4QyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxNQUFLO0FBQUEsTUFDTCxXQUFXLHNJQUFzSVUsS0FBS1osTUFBTSxJQUMxSk8sVUFBVSw4QkFBOEIseUJBQXlCO0FBQUEsTUFHbkU7QUFBQSwrQkFBQyxVQUFLLFdBQVUsbUJBQW1CSyxlQUFLYixRQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFDN0MsdUJBQUMsU0FBSSxXQUFVLGtCQUNaSztBQUFBQSxnQkFBTVUsU0FBUyx1QkFBQyxPQUFFLFdBQVUsd0NBQXdDVixnQkFBTVUsU0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxVQUNqRix1QkFBQyxPQUFFLFdBQVUsMEJBQTBCVixnQkFBTVcsV0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQSxhQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU1WLFVBQVVELE1BQU1ZLEVBQUU7QUFBQSxZQUNqQyxjQUFXO0FBQUEsWUFDWCxXQUFVO0FBQUEsWUFFVixpQ0FBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sU0FBUSxhQUFZLFFBQU8sZ0JBQWUsYUFBWSxLQUN6RixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLEdBQUUsMEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFLEtBRDdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQTtBQUFBLFVBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0E7QUFBQTtBQUFBO0FBQUEsSUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBcUJBO0FBRUo7QUFBQ1YsR0FsQ1FILFdBQVM7QUFBQSxLQUFUQTtBQW9DRixnQkFBU2MsY0FBYyxFQUFFQyxTQUFTLEdBQUc7QUFBQUMsTUFBQTtBQUMxQyxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSTFCLFNBQVMsRUFBRTtBQUV2QyxRQUFNMkIsVUFBVS9CLFlBQVksQ0FBQ3lCLE9BQU87QUFDbENLLGNBQVUsQ0FBQ0UsU0FBU0EsS0FBS0MsT0FBTyxDQUFDQyxNQUFNQSxFQUFFVCxPQUFPQSxFQUFFLENBQUM7QUFBQSxFQUNyRCxHQUFHLEVBQUU7QUFFTCxRQUFNVSxZQUFZbkM7QUFBQUEsSUFDaEIsQ0FBQyxFQUFFc0IsT0FBTyxRQUFRQyxPQUFPQyxTQUFTWSxXQUFXLElBQUssTUFBTTtBQUN0RCxZQUFNWCxLQUFLLEdBQUdZLEtBQUtDLElBQUksQ0FBQyxJQUFJQyxLQUFLQyxPQUFPLEVBQUVDLFNBQVMsRUFBRSxFQUFFQyxNQUFNLENBQUMsQ0FBQztBQUMvRFosZ0JBQVUsQ0FBQ0UsU0FBUyxDQUFDLEdBQUdBLE1BQU0sRUFBRVAsSUFBSUgsTUFBTUMsT0FBT0MsUUFBUSxDQUFDLENBQUM7QUFDM0RtQixpQkFBVyxNQUFNWixRQUFRTixFQUFFLEdBQUdXLFFBQVE7QUFBQSxJQUN4QztBQUFBLElBQ0EsQ0FBQ0wsT0FBTztBQUFBLEVBQ1Y7QUFFQSxRQUFNYSxRQUFRekMsUUFBUSxPQUFPLEVBQUVnQyxVQUFVLElBQUksQ0FBQ0EsU0FBUyxDQUFDO0FBRXhELFNBQ0UsdUJBQUMsYUFBYSxVQUFiLEVBQXNCLE9BQ3BCUjtBQUFBQTtBQUFBQSxJQUNELHVCQUFDLFNBQUksV0FBVSxzREFDWkUsaUJBQU9nQjtBQUFBQSxNQUFJLENBQUNoQyxVQUNYLHVCQUFDLGFBQXlCLE9BQWMsV0FBV2tCLFdBQW5DbEIsTUFBTVksSUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLElBQzVELEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFSjtBQUFDRyxJQTVCZUYsZUFBYTtBQUFBLE1BQWJBO0FBOEJULGdCQUFTb0IsV0FBVztBQUFBQyxNQUFBO0FBQ3pCLFFBQU1DLE1BQU0vQyxXQUFXSSxZQUFZO0FBQ25DLE1BQUksQ0FBQzJDLEtBQUs7QUFDUixVQUFNLElBQUlDLE1BQU0sOENBQThDO0FBQUEsRUFDaEU7QUFDQSxTQUFPRDtBQUNUO0FBQUNELElBTmVELFVBQVE7QUFBQSxJQUFBSSxJQUFBQztBQUFBLGFBQUFELElBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUNhbGxiYWNrIiwidXNlQ29udGV4dCIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsIlRvYXN0Q29udGV4dCIsIlRZUEVTIiwic3VjY2VzcyIsImljb24iLCJhY2NlbnQiLCJlcnJvciIsImluZm8iLCJUb2FzdEl0ZW0iLCJ0b2FzdCIsIm9uRGlzbWlzcyIsIl9zIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJyYWYiLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJjYW5jZWxBbmltYXRpb25GcmFtZSIsIm1ldGEiLCJ0eXBlIiwidGl0bGUiLCJtZXNzYWdlIiwiaWQiLCJUb2FzdFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfczIiLCJ0b2FzdHMiLCJzZXRUb2FzdHMiLCJkaXNtaXNzIiwicHJldiIsImZpbHRlciIsInQiLCJzaG93VG9hc3QiLCJkdXJhdGlvbiIsIkRhdGUiLCJub3ciLCJNYXRoIiwicmFuZG9tIiwidG9TdHJpbmciLCJzbGljZSIsInNldFRpbWVvdXQiLCJ2YWx1ZSIsIm1hcCIsInVzZVRvYXN0IiwiX3MzIiwiY3R4IiwiRXJyb3IiLCJfYyIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUb2FzdC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ2FsbGJhY2ssIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbmNvbnN0IFRvYXN0Q29udGV4dCA9IGNyZWF0ZUNvbnRleHQobnVsbCk7XG5cbmNvbnN0IFRZUEVTID0ge1xuICBzdWNjZXNzOiB7XG4gICAgaWNvbjogKFxuICAgICAgPHN2ZyBjbGFzc05hbWU9XCJoLTUgdy01IHRleHQtZ3JlZW4tNTAwXCIgZmlsbD1cIm5vbmVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCI+XG4gICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBkPVwiTTkgMTJsMiAyIDQtNG02IDJhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCIgLz5cbiAgICAgIDwvc3ZnPlxuICAgICksXG4gICAgYWNjZW50OiAnYm9yZGVyLWwtZ3JlZW4tNTAwJyxcbiAgfSxcbiAgZXJyb3I6IHtcbiAgICBpY29uOiAoXG4gICAgICA8c3ZnIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC1yZWQtNTAwXCIgZmlsbD1cIm5vbmVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCI+XG4gICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBkPVwiTTEyIDh2NG0wIDRoLjAxTTEwLjI5IDMuODZMMS44MiAxOGEyIDIgMCAwMDEuNzEgM2gxNi45NGEyIDIgMCAwMDEuNzEtM0wxMy43MSAzLjg2YTIgMiAwIDAwLTMuNDIgMHpcIiAvPlxuICAgICAgPC9zdmc+XG4gICAgKSxcbiAgICBhY2NlbnQ6ICdib3JkZXItbC1yZWQtNTAwJyxcbiAgfSxcbiAgaW5mbzoge1xuICAgIGljb246IChcbiAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LWJsdWUtNTAwXCIgZmlsbD1cIm5vbmVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCI+XG4gICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBkPVwiTTEzIDE2aC0xdi00aC0xbTEtNGguMDFNMjEgMTJhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCIgLz5cbiAgICAgIDwvc3ZnPlxuICAgICksXG4gICAgYWNjZW50OiAnYm9yZGVyLWwtYmx1ZS01MDAnLFxuICB9LFxufTtcblxuZnVuY3Rpb24gVG9hc3RJdGVtKHsgdG9hc3QsIG9uRGlzbWlzcyB9KSB7XG4gIGNvbnN0IFt2aXNpYmxlLCBzZXRWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHJhZiA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiBzZXRWaXNpYmxlKHRydWUpKTtcbiAgICByZXR1cm4gKCkgPT4gY2FuY2VsQW5pbWF0aW9uRnJhbWUocmFmKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IG1ldGEgPSBUWVBFU1t0b2FzdC50eXBlXSB8fCBUWVBFUy5pbmZvO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgcm9sZT1cImFsZXJ0XCJcbiAgICAgIGNsYXNzTmFtZT17YGZsZXggdy04MCBpdGVtcy1zdGFydCBnYXAtMyByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJvcmRlci1sLTQgYmctd2hpdGUgcHgtNCBweS0zIHNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHttZXRhLmFjY2VudH0gJHtcbiAgICAgICAgdmlzaWJsZSA/ICd0cmFuc2xhdGUteS0wIG9wYWNpdHktMTAwJyA6ICd0cmFuc2xhdGUteS0yIG9wYWNpdHktMCdcbiAgICAgIH1gfVxuICAgID5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTAuNSBzaHJpbmstMFwiPnttZXRhLmljb259PC9zcGFuPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxuICAgICAgICB7dG9hc3QudGl0bGUgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwXCI+e3RvYXN0LnRpdGxlfTwvcD59XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS02MDBcIj57dG9hc3QubWVzc2FnZX08L3A+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b25cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRGlzbWlzcyh0b2FzdC5pZCl9XG4gICAgICAgIGFyaWEtbGFiZWw9XCJEaXNtaXNzXCJcbiAgICAgICAgY2xhc3NOYW1lPVwic2hyaW5rLTAgcm91bmRlZCBwLTAuNSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMFwiXG4gICAgICA+XG4gICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC00IHctNFwiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiPlxuICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBkPVwiTTYgMThMMTggNk02IDZsMTIgMTJcIiAvPlxuICAgICAgICA8L3N2Zz5cbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gVG9hc3RQcm92aWRlcih7IGNoaWxkcmVuIH0pIHtcbiAgY29uc3QgW3RvYXN0cywgc2V0VG9hc3RzXSA9IHVzZVN0YXRlKFtdKTtcblxuICBjb25zdCBkaXNtaXNzID0gdXNlQ2FsbGJhY2soKGlkKSA9PiB7XG4gICAgc2V0VG9hc3RzKChwcmV2KSA9PiBwcmV2LmZpbHRlcigodCkgPT4gdC5pZCAhPT0gaWQpKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHNob3dUb2FzdCA9IHVzZUNhbGxiYWNrKFxuICAgICh7IHR5cGUgPSAnaW5mbycsIHRpdGxlLCBtZXNzYWdlLCBkdXJhdGlvbiA9IDQwMDAgfSkgPT4ge1xuICAgICAgY29uc3QgaWQgPSBgJHtEYXRlLm5vdygpfS0ke01hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnNsaWNlKDIpfWA7XG4gICAgICBzZXRUb2FzdHMoKHByZXYpID0+IFsuLi5wcmV2LCB7IGlkLCB0eXBlLCB0aXRsZSwgbWVzc2FnZSB9XSk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IGRpc21pc3MoaWQpLCBkdXJhdGlvbik7XG4gICAgfSxcbiAgICBbZGlzbWlzc11cbiAgKTtcblxuICBjb25zdCB2YWx1ZSA9IHVzZU1lbW8oKCkgPT4gKHsgc2hvd1RvYXN0IH0pLCBbc2hvd1RvYXN0XSk7XG5cbiAgcmV0dXJuIChcbiAgICA8VG9hc3RDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt2YWx1ZX0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGJvdHRvbS00IHJpZ2h0LTQgei1bMTAwXSBmbGV4IGZsZXgtY29sIGdhcC0yXCI+XG4gICAgICAgIHt0b2FzdHMubWFwKCh0b2FzdCkgPT4gKFxuICAgICAgICAgIDxUb2FzdEl0ZW0ga2V5PXt0b2FzdC5pZH0gdG9hc3Q9e3RvYXN0fSBvbkRpc21pc3M9e2Rpc21pc3N9IC8+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG4gICAgPC9Ub2FzdENvbnRleHQuUHJvdmlkZXI+XG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VUb2FzdCgpIHtcbiAgY29uc3QgY3R4ID0gdXNlQ29udGV4dChUb2FzdENvbnRleHQpO1xuICBpZiAoIWN0eCkge1xuICAgIHRocm93IG5ldyBFcnJvcigndXNlVG9hc3QgbXVzdCBiZSB1c2VkIHdpdGhpbiBhIFRvYXN0UHJvdmlkZXInKTtcbiAgfVxuICByZXR1cm4gY3R4O1xufVxuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL3VpL1RvYXN0LmpzeCJ9