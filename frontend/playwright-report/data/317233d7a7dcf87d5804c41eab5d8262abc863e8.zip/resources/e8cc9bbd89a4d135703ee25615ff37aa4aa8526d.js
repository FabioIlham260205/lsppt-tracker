import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6eb1056b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { BrowserRouter, Routes, Route, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=6eb1056b";
import SubmitPage from "/src/pages/SubmitPage.jsx?t=1787813471073";
import HistoryPage from "/src/pages/HistoryPage.jsx?t=1787813471157";
import ComponentsPage from "/src/pages/ComponentsPage.jsx";
import { ToastProvider } from "/src/components/ui/index.js";
function NotFoundPage() {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen items-center justify-center", children: /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold text-slate-800", children: "404" }, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 30,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-slate-500", children: "Halaman tidak ditemukan" }, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 31,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/App.jsx",
    lineNumber: 29,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/app/src/App.jsx",
    lineNumber: 28,
    columnNumber: 5
  }, this);
}
_c = NotFoundPage;
function App() {
  return /* @__PURE__ */ jsxDEV(ToastProvider, { children: /* @__PURE__ */ jsxDEV(BrowserRouter, { children: /* @__PURE__ */ jsxDEV(Routes, { children: [
    /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/submit", replace: true }, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 42,
      columnNumber: 36
    }, this) }, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 42,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/submit", element: /* @__PURE__ */ jsxDEV(SubmitPage, {}, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 43,
      columnNumber: 42
    }, this) }, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 43,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/history", element: /* @__PURE__ */ jsxDEV(HistoryPage, {}, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 44,
      columnNumber: 43
    }, this) }, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 44,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/components", element: /* @__PURE__ */ jsxDEV(ComponentsPage, {}, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 45,
      columnNumber: 46
    }, this) }, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 45,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(NotFoundPage, {}, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 46,
      columnNumber: 36
    }, this) }, void 0, false, {
      fileName: "/app/src/App.jsx",
      lineNumber: 46,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/App.jsx",
    lineNumber: 41,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/app/src/App.jsx",
    lineNumber: 40,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/app/src/App.jsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
}
_c2 = App;
export default App;
var _c, _c2;
$RefreshReg$(_c, "NotFoundPage");
$RefreshReg$(_c2, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFWUixTQUFTQSxlQUFlQyxRQUFRQyxPQUFPQyxnQkFBZ0I7QUFDdkQsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MscUJBQXFCO0FBRTlCLFNBQVNDLGVBQWU7QUFDdEIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaURBQ2IsaUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSwyQkFBQyxRQUFHLFdBQVUscUNBQW9DLG1CQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFEO0FBQUEsSUFDckQsdUJBQUMsT0FBRSxXQUFVLHVCQUFzQix1Q0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRDtBQUFBLE9BRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQTtBQUVKO0FBQUNDLEtBVFFEO0FBV1QsU0FBU0UsTUFBTTtBQUNiLFNBQ0UsdUJBQUMsaUJBQ0MsaUNBQUMsaUJBQ0MsaUNBQUMsVUFDQztBQUFBLDJCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsWUFBUyxJQUFHLFdBQVUsU0FBTyxRQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThCLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkQ7QUFBQSxJQUMzRCx1QkFBQyxTQUFNLE1BQUssV0FBVSxTQUFTLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVyxLQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsSUFDOUMsdUJBQUMsU0FBTSxNQUFLLFlBQVcsU0FBUyx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVksS0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRDtBQUFBLElBQ2hELHVCQUFDLFNBQU0sTUFBSyxlQUFjLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0Q7QUFBQSxJQUN0RCx1QkFBQyxTQUFNLE1BQUssS0FBSSxTQUFTLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYSxLQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBDO0FBQUEsT0FMNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBO0FBRUo7QUFBQ0MsTUFkUUQ7QUFnQlQsZUFBZUE7QUFBSSxJQUFBRCxJQUFBRTtBQUFBLGFBQUFGLElBQUE7QUFBQSxhQUFBRSxLQUFBIiwibmFtZXMiOlsiQnJvd3NlclJvdXRlciIsIlJvdXRlcyIsIlJvdXRlIiwiTmF2aWdhdGUiLCJTdWJtaXRQYWdlIiwiSGlzdG9yeVBhZ2UiLCJDb21wb25lbnRzUGFnZSIsIlRvYXN0UHJvdmlkZXIiLCJOb3RGb3VuZFBhZ2UiLCJfYyIsIkFwcCIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJyb3dzZXJSb3V0ZXIsIFJvdXRlcywgUm91dGUsIE5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgU3VibWl0UGFnZSBmcm9tICcuL3BhZ2VzL1N1Ym1pdFBhZ2UuanN4JztcbmltcG9ydCBIaXN0b3J5UGFnZSBmcm9tICcuL3BhZ2VzL0hpc3RvcnlQYWdlLmpzeCc7XG5pbXBvcnQgQ29tcG9uZW50c1BhZ2UgZnJvbSAnLi9wYWdlcy9Db21wb25lbnRzUGFnZS5qc3gnO1xuaW1wb3J0IHsgVG9hc3RQcm92aWRlciB9IGZyb20gJy4vY29tcG9uZW50cy91aSc7XG5cbmZ1bmN0aW9uIE5vdEZvdW5kUGFnZSgpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+NDA0PC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNsYXRlLTUwMFwiPkhhbGFtYW4gdGlkYWsgZGl0ZW11a2FuPC9wPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIChcbiAgICA8VG9hc3RQcm92aWRlcj5cbiAgICAgIDxCcm93c2VyUm91dGVyPlxuICAgICAgICA8Um91dGVzPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL1wiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9zdWJtaXRcIiByZXBsYWNlIC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3N1Ym1pdFwiIGVsZW1lbnQ9ezxTdWJtaXRQYWdlIC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2hpc3RvcnlcIiBlbGVtZW50PXs8SGlzdG9yeVBhZ2UgLz59IC8+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvY29tcG9uZW50c1wiIGVsZW1lbnQ9ezxDb21wb25lbnRzUGFnZSAvPn0gLz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIipcIiBlbGVtZW50PXs8Tm90Rm91bmRQYWdlIC8+fSAvPlxuICAgICAgICA8L1JvdXRlcz5cbiAgICAgIDwvQnJvd3NlclJvdXRlcj5cbiAgICA8L1RvYXN0UHJvdmlkZXI+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvQXBwLmpzeCJ9